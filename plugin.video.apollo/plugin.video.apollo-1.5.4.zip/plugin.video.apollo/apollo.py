# -*- coding: utf-8 -*-
import urllib
import urllib2
import datetime
import re
import os
import base64
import codecs
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
import time
import xbmcgui
import xbmc
import xbmcplugin
import webbrowser
import os
import xbmcaddon
from BeautifulSoup import BeautifulStoneSoup , BeautifulSoup , BeautifulSOAP
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = None
try :
 from xml . sax . saxutils import escape
except : traceback . print_exc ( )
if 78 - 78: i11i . oOooOoO0Oo0O
try :
 import json
except :
 import simplejson as json
import SimpleDownloader as downloader
import time
import requests
iI1 = False
if 43 - 43: I11i11Ii
if 65 - 65: i1iIi11iIIi1I
Oo = "03.10.20"
if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
if 97 - 97: Ii1I - ii1IiI1i . I1Ii111 - OoooooooOO
oO0o = 'aHR0cHM6Ly9kZXVzYXBvbGxvLmNvbS9BUE9MTE8vQkFTRS1QUklOQ0lQQUwvQmFzZS1QcmluY2lwYWwuaHRtbA=='
IIII = base64 . b64decode ( oO0o )
if 59 - 59: i1IIi * i1IIi % I11i + i11i
if 32 - 32: o0 . o00O0oo * i1IIi . ooOoO0o / I1Ii111
o00 = '[COLOR orange][B]->[/COLOR][/B][COLOR deepskyblue][B] BEM-VINDOS[/COLOR][/B]'
if 62 - 62: i11iIiiIii - i11i % ooOoO0o - iIii1I11I1II1 . ii1IiI1i . i11i
if 61 - 61: OOooOOo / o0 / IiII * i1iIi11iIIi1I . i11i
if 1 - 1: i11i - ii1IiI1i % i11iIiiIii + I1Ii111 . ooOoO0o
Oooo0000 = '-> BAIXE E INSTALE!'
if 22 - 22: iII111i . I1Ii111
if 41 - 41: ooOoO0o . o00O0oo * I1Ii111 % i11iIiiIii
if 74 - 74: IiII * I1Ii111
if 82 - 82: iIii1I11I1II1 % I1Ii111
oOo0oooo00o = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzJQTk4xUGpL'
oO0o0o0ooO0oO = base64 . b64decode ( oOo0oooo00o )
if 52 - 52: i11i - i11iIiiIii % ooOoO0o
if 54 - 54: I11i % O0 + oOooOoO0Oo0O - IiII / Ii1I
if 31 - 31: i1iIi11iIIi1I + i11i
if 13 - 13: I11i * OOooOOo * oOooOoO0Oo0O
if 55 - 55: i11i
IIIiI11ii = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BYR2gyckVu'
O000oo = base64 . b64decode ( IIIiI11ii )
if 3 - 3: IiII + O0
if 42 - 42: I11i / i1IIi + i11iIiiIii - iII111i
if 78 - 78: i1iIi11iIIi1I
Iii1I111 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1hDdDl6clRm'
OO0O0O00OooO = base64 . b64decode ( Iii1I111 )
if 77 - 77: i11i - i11i . oOooOoO0Oo0O / i1
if 14 - 14: Ii1I % O0
IiI1I1 = 3000
if 86 - 86: i11iIiiIii + iII111i + o00O0oo * Ii1I + i1
if 61 - 61: i1iIi11iIIi1I / i11iIiiIii
if 34 - 34: OoooooooOO + iIii1I11I1II1 + i11iIiiIii - ii1IiI1i + i11iIiiIii
if 65 - 65: o0
if 6 - 6: oOooOoO0Oo0O / I11i11Ii % iII111i
oo = 'aHR0cHM6Ly91cmxwbGF5LmNvbS9OMHJkTEI='
OO0O00 = base64 . b64decode ( oo )
if 20 - 20: OoooooooOO
if 13 - 13: i1IIi - iII111i % OOooOOo / iIii1I11I1II1 % IiII
if 97 - 97: i11iIiiIii
if 32 - 32: I11i11Ii * O0 % OOooOOo % iII111i . I1Ii111
o0OOOOO00o0O0 = 'ǭq�{���}���w���'
if 71 - 71: o00O0oo % IiII / i1
if 49 - 49: i11i % IiII * O0
if 89 - 89: OOooOOo + I11i11Ii
Ii1IOo0o0 = 'TORRENT'
III1ii1iII = 'https://i.imgur.com/OKPqt3k.png'
oo0oooooO0 = 'https://i.imgur.com/By1pLrx.jpg'
if 19 - 19: Ii1I + o00O0oo
ooo = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JVYk5CWlFB'
ii1I1i1I = base64 . b64decode ( ooo )
if 88 - 88: i1iIi11iIIi1I + O0 / o0 * IiII
iiiIi1i1I = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JVYk5CWlFB'
oOO00oOO = base64 . b64decode ( iiiIi1i1I )
if 75 - 75: i1IIi / OoooooooOO - O0 / o0 . i11i - i1IIi
if 71 - 71: I11i + iII111i * I11i - i1iIi11iIIi1I * i1
if 65 - 65: O0 % oOooOoO0Oo0O . ii1IiI1i % iIii1I11I1II1 / I11i % ooOoO0o
if 51 - 51: i11iIiiIii . oOooOoO0Oo0O + i11i
II111ii1II1i = '[COLOR white]Selecione um item:[/COLOR]'
if 59 - 59: O0 + oOooOoO0Oo0O + I1Ii111 % oOooOoO0Oo0O
o0OOoo0OO0OOO = '[COLOR white]!!Download em execução!![/COLOR]'
iI1iI1I1i1I = '!!Download [COLOR seablue]Audio!![/COLOR]'
if 24 - 24: ii1IiI1i
o0Oo0O0Oo00oO = '[COLOR deepskyblue][B] CHECAR POR ATUALIZAÇÃO[/COLOR][/B]'
I11i1I1I = 'https://i.imgur.com/22LSvnr.png'
oO0Oo = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2E5dE1DMEh1'
oOOoo0Oo = base64 . b64decode ( oO0Oo )
if 78 - 78: Ii1I
if 71 - 71: I11i + o00O0oo % i11iIiiIii + ii1IiI1i - I1Ii111
if 88 - 88: o0 - i1iIi11iIIi1I % I11i
iI1I111Ii111i = 'BEM-VINDOS'
I11IiI1I11i1i = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0NmhqV0VY'
iI1ii1Ii = 'https://i.imgur.com/fHRcl7O.png'
oooo000 = 'https://i.imgur.com/Y4QXRab.jpg'
iIIIi1 = base64 . b64decode ( I11IiI1I11i1i )
if 20 - 20: i1IIi + ii1IiI1i - o00O0oo
if 30 - 30: i11i - I11i - i11iIiiIii % o0 - i11i * iII111i
if 61 - 61: OOooOOo - Ii1I % I11i
OOoOO0oo0ooO = '$texto='
if 98 - 98: IiII * IiII / IiII + Ii1I
if 34 - 34: o00O0oo
__addon__ = xbmcaddon . Addon ( )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
__icon__ = __addon__ . getAddonInfo ( 'icon' )
if 15 - 15: Ii1I * o00O0oo * I11i11Ii % i11iIiiIii % o0 - I11i
if 68 - 68: ooOoO0o % i1IIi . I1Ii111 . ii1IiI1i
o0oo0oOo = [ '180upload.com' , 'allmyvideos.net' , 'bestreams.net' , 'clicknupload.com' , 'cloudzilla.to' , 'movshare.net' , 'novamov.com' , 'nowvideo.sx' , 'videoweed.es' , 'daclips.in' , 'datemule.com' , 'fastvideo.in' , 'faststream.in' , 'filehoot.com' , 'filenuke.com' , 'sharesix.com' , 'docs.google.com' , 'plus.google.com' , 'picasaweb.google.com' , 'gorillavid.com' , 'gorillavid.in' , 'grifthost.com' , 'hugefiles.net' , 'ipithos.to' , 'ishared.eu' , 'kingfiles.net' , 'mail.ru' , 'my.mail.ru' , 'videoapi.my.mail.ru' , 'mightyupload.com' , 'mooshare.biz' , 'movdivx.com' , 'movpod.net' , 'movpod.in' , 'movreel.com' , 'mrfile.me' , 'nosvideo.com' , 'openload.io' , 'played.to' , 'bitshare.com' , 'filefactory.com' , 'k2s.cc' , 'oboom.com' , 'rapidgator.net' , 'uploaded.net' , 'primeshare.tv' , 'bitshare.com' , 'filefactory.com' , 'k2s.cc' , 'oboom.com' , 'rapidgator.net' , 'uploaded.net' , 'sharerepo.com' , 'stagevu.com' , 'streamcloud.eu' , 'streamin.to' , 'thefile.me' , 'thevideo.me' , 'tusfiles.net' , 'uploadc.com' , 'zalaa.com' , 'uploadrocket.net' , 'uptobox.com' , 'v-vids.com' , 'veehd.com' , 'vidbull.com' , 'videomega.tv' , 'vidplay.net' , 'vidspot.net' , 'vidto.me' , 'vidzi.tv' , 'vimeo.com' , 'vk.com' , 'vodlocker.com' , 'xfileload.com' , 'xvidstage.com' , 'zettahost.tv' ]
o000O0o = [ 'plugin.video.dramasonline' , 'plugin.video.f4mTester' , 'plugin.video.shahidmbcnet' , 'plugin.video.SportsDevil' , 'plugin.stream.vaughnlive.tv' , 'plugin.video.ZemTV-shani' ]
if 42 - 42: o0
class II ( urllib2 . HTTPErrorProcessor ) :
 def http_response ( self , request , response ) :
  return response
 https_response = http_response
 if 45 - 45: O0 * i1 % I11i11Ii * OoooooooOO + IiII . o0
Oo0ooOo0o = False ;
if Oo0ooOo0o :
 if 22 - 22: iIii1I11I1II1 / i11iIiiIii * iIii1I11I1II1 * i11i . I11i / i11iIiiIii
 if 2 - 2: oOooOoO0Oo0O / O0 / i1 % o0 % iII111i
 try :
  import pysrc . pydevd as pydevd
  if 52 - 52: i1
  pydevd . settrace ( 'localhost' , stdoutToServer = True , stderrToServer = True )
 except ImportError :
  sys . stderr . write ( "Error: " +
 "You must add org.python.pydev.debug.pysrc to your PYTHONPATH." )
  sys . exit ( 1 )
  if 95 - 95: iII111i
  if 87 - 87: o00O0oo + o0 . I11i + o0
oO = xbmcaddon . Addon ( )
iIi1IIIi1 = oO . getAddonInfo ( 'version' )
O0oOoOOOoOO = xbmc . translatePath ( oO . getAddonInfo ( 'profile' ) . decode ( 'utf-8' ) )
ii1ii11IIIiiI = xbmc . translatePath ( oO . getAddonInfo ( 'path' ) . decode ( 'utf-8' ) )
O00OOOoOoo0O = os . path . join ( O0oOoOOOoOO , 'favorites' )
O000OOo00oo = os . path . join ( O0oOoOOOoOO , 'history' )
if 71 - 71: i11iIiiIii + I1Ii111
oOo = os . path . join ( O0oOoOOOoOO , 'list_revision' )
oOO00Oo = os . path . join ( ii1ii11IIIiiI , 'icon.png' )
i1iIIIi1i = os . path . join ( ii1ii11IIIiiI , 'icon_config.png' )
iI1iIIiiii = os . path . join ( ii1ii11IIIiiI , 'favorites.png' )
i1iI11i1ii11 = os . path . join ( ii1ii11IIIiiI , 'fanart.jpg' )
OOooo0O00o = os . path . join ( O0oOoOOOoOO , 'source_file' )
oOOoOooOo = O0oOoOOOoOO
if 51 - 51: Ii1I + IiII % iIii1I11I1II1 / OOooOOo / I11i % OoooooooOO
downloader = downloader . SimpleDownloader ( )
o0O0OOO0Ooo = oO . getSetting ( 'debug' )
if os . path . exists ( O00OOOoOoo0O ) == True :
 iiIiI = open ( O00OOOoOoo0O ) . read ( )
else : iiIiI = [ ]
if os . path . exists ( OOooo0O00o ) == True :
 I1 = open ( OOooo0O00o ) . read ( )
else : I1 = [ ]
if 86 - 86: o0 - iII111i - i1iIi11iIIi1I * IiII
if 66 - 66: OoooooooOO + O0
def I1IiiI ( url ) :
 try :
  import urllib . request as urllib2
 except ImportError :
  import urllib2
 IIi = urllib2 . build_opener ( )
 IIi . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0' ) ]
 if 41 - 41: iII111i - O0 - O0
 oO00OOoO00 = IIi . open ( url )
 IiI111111IIII = oO00OOoO00 . read ( ) . decode ( 'utf-8' )
 i1Ii = IiI111111IIII
 return i1Ii
 if 14 - 14: IiII
def I1iI1iIi111i ( string ) :
 if o0O0OOO0Ooo == 'true' :
  if 44 - 44: i1IIi % i11i + Ii1I
  xbmc . log ( "[APOLLO-%s]: %s" % ( iIi1IIIi1 , string ) )
  if 45 - 45: IiII / IiII + ooOoO0o + o00O0oo
  if 47 - 47: i1 + o00O0oo
  if 82 - 82: i11i . I1Ii111 - iIii1I11I1II1 - I1Ii111 * i11i
  if 77 - 77: iIii1I11I1II1 * i1iIi11iIIi1I
def oOooOo0 ( msg ) :
 i1I1ii11i1Iii = oO . getSetting ( 'suporte' )
 if i1I1ii11i1Iii == 'true' :
  I1IiiiiI ( Oooo0000 , OO0O00 , 44 , III1ii1iII , i1iI11i1ii11 , o0O ( O000oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 2 - 2: iIii1I11I1II1 / OOooOOo + i1iIi11iIIi1I / I11i
def IIOOOO0oo0 ( msg ) :
 xbmcgui . Dialog ( ) . ok ( '[COLOR deepskyblue][B]"IMPORTANTE INSTALE" [/COLOR][/B]' , "[COLOR orange][B]PARA VOCÊ ASSISTIR OS EM TODOS OS SERVIDORES DE FILMES E SÉRIES, MUITO SIMPLES VCS DEVEM FAZER O DOWNLOAD DO PLUGIN ELEMENTUM NOS LINKS ASEGUIR!. LOGO APOIS TER FEITO O DOWNLOAD VC VÃO EM SITESMA INSTALA POR ZIP E PROCURAR NA PASTA DA SUA BOX OU PC O ZIP PARA INSTALAR NA BOX![/COLOR][/B]" )
 I11iiI1i1 = xbmcgui . Dialog ( )
 I1i1Iiiii = I11iiI1i1 . select ( '[COLOR orange][B]PARA ASSISTIR FILMES EM 4K LINKS ABAIXO![/COLOR][/B]' , [ '[COLOR deepskyblue][B]BAIXAR[/COLOR][/B][COLOR orange][B] ELEMENTUM[/COLOR][/B]' , '[COLOR deepskyblue][B]BAIXAR[/COLOR][/B][COLOR orange][B] ELEMENTUM BURST[/COLOR][/B]' , '' ] )
 if I1i1Iiiii == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.58/plugin.video.elementum-0.1.58.zip' ) )
  else :
   webbrowser . open ( 'https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.58/plugin.video.elementum-0.1.58.zip' )
 if I1i1Iiiii == 1 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://github.com/elgatito/script.elementum.burst/releases/download/v0.0.49/script.elementum.burst-0.0.49.zip' ) )
  else :
   webbrowser . open ( 'https://github.com/elgatito/script.elementum.burst/releases/download/v0.0.49/script.elementum.burst-0.0.49.zip' )
   if 94 - 94: i1 * iII111i / I11i11Ii / iII111i
 if I1i1Iiiii == 5 :
  xbmcaddon . Addon ( ) . openSettings ( )
  if 87 - 87: I11i11Ii . I1Ii111
  xbmc . executebuiltin ( "XBMC.Container.Refresh(%s?mode=None, replace)" % sys . argv [ 0 ] )
  xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
  if 75 - 75: o00O0oo + o0 + i1 * Ii1I % OOooOOo . IiII
def oOI1Ii1I1 ( ) :
 IiII111iI1ii1 = oO . getSetting ( 'username' )
 iI11I1II = oO . getSetting ( 'password' )
 Ii1IIiI1i = oO . getSetting ( 'servidor' )
 o0Oo00 = oO . getSetting ( 'exibirTORRENT' )
 iI = oO . getSetting ( 'saida' )
 if o0Oo00 == 'true' :
  if Ii1IIiI1i == 'TORRENT' :
   O0O0Oooo0o = 'http://sv1.iptvcasa.online:25461/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % ( IiII111iI1ii1 , iI11I1II , iI )
   I1IiiiiI ( Ii1IOo0o0 , O0O0Oooo0o , 1 , III1ii1iII , oo0oooooO0 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if Ii1IIiI1i == 'Nenhum' :
   I1IiiiiI ( Ii1IOo0o0 , '' , 42 , III1ii1iII , oo0oooooO0 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 IiII111iI1ii1 = oO . getSetting ( 'username2' )
 iI11I1II = oO . getSetting ( 'password2' )
 Ii1IIiI1i = oO . getSetting ( 'servidor2' )
 o0Oo00 = oO . getSetting ( 'exibirTORRENT2' )
 iI = oO . getSetting ( 'saida2' )
 if o0Oo00 == 'true' :
  if Ii1IIiI1i == 'TORRENT' :
   O0O0Oooo0o = 'http://cloudsteam.club:8080/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % ( IiII111iI1ii1 , iI11I1II , iI )
   I1IiiiiI ( titulo_TORRENT2 , O0O0Oooo0o , 1 , thumbnail_TORRENT2 , oo0oooooO0 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if Ii1IIiI1i == 'Nenhum' :
   I1IiiiiI ( titulo_TORRENT2 , '' , 42 , thumbnail_TORRENT2 , fanart_TORRENT2 , o0O ( ii1I1i1I ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
   if 56 - 56: ii1IiI1i % O0 - oOooOoO0Oo0O
def O00o0OO0 ( msg ) :
 IIi1I1iiiii = oO . getSetting ( 'mensagem1' )
 if IIi1I1iiiii == 'true' :
  I11iiI1i1 = xbmcgui . Dialog ( )
  I1i1Iiiii = I11iiI1i1 . select ( '[COLOR orange][B]AJUDE O ADD-ON FAÇA SUA[/COLOR][/B][COLOR deepskyblue][B] DOAÇÃO[/COLOR][/B]' , [ '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] SEJA VIP [/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] SITE OFICIAL![/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR lightcyan][B] PIC[/COLOR][/B][COLOR lime][B]PAY [/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR royalblue][B] PAY[/COLOR][/B][COLOR lightcyan][B]PAL [/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR blueviolet][B] NUBANK[/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR lightcyan][B] MERCADO[/COLOR][/B][COLOR dodgerblue][B]PAGO [/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] GRUPO TELEGRAM[/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] GRUPO FACEBOOK[/COLOR][/B]' , '[COLOR deepskyblue][B]ENTRAR NO[/COLOR][/B][COLOR orange][B] ADD-ON[/COLOR][/B]' ] )
  if 71 - 71: I1Ii111 * i11i * OOooOOo
  if I1i1Iiiii == 0 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://bit.ly/3hHpLCe-PV-APOLLO' ) )
   else :
    webbrowser . open ( 'https://bit.ly/3hHpLCe-PV-APOLLO' )
    if 56 - 56: oOooOoO0Oo0O
    if 54 - 54: ooOoO0o / I11i . OOooOOo % IiII
  if I1i1Iiiii == 1 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://deus-apollo.ml' ) )
   else :
    webbrowser . open ( 'http://deus-apollo.ml' )
    if 57 - 57: i11iIiiIii . ii1IiI1i - iII111i - OOooOOo + o0
    if 63 - 63: o0 * IiII
  if I1i1Iiiii == 2 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://picpay.me/deus.apollo' ) )
   else :
    webbrowser . open ( 'https://picpay.me/deus.apollo' )
    if 69 - 69: O0 . i1iIi11iIIi1I
    if 49 - 49: oOooOoO0Oo0O - Ii1I
  if I1i1Iiiii == 3 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=44A92DUKBAKAN&source=url' ) )
   else :
    webbrowser . open ( 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=44A92DUKBAKAN&source=url' )
    if 74 - 74: iIii1I11I1II1 * ii1IiI1i + o0 / i1IIi / i11i . I11i11Ii
    if 62 - 62: OoooooooOO * oOooOoO0Oo0O
  if I1i1Iiiii == 4 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://nubank.com.br/pagar/1djpv6/FJzleug9nF' ) )
   else :
    webbrowser . open ( 'https://nubank.com.br/pagar/1djpv6/FJzleug9nF' )
    if 58 - 58: o0 % i1
    if 50 - 50: ooOoO0o . i1
  if I1i1Iiiii == 5 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=203668628-f9a8d299-8b36-4cbd-84f4-0eb34ed0be11' ) )
   else :
    webbrowser . open ( 'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=203668628-f9a8d299-8b36-4cbd-84f4-0eb34ed0be11' )
    if 97 - 97: O0 + o0
    if 89 - 89: i1 + i1iIi11iIIi1I * Ii1I * iII111i
    if 37 - 37: OoooooooOO - O0 - i1
  if I1i1Iiiii == 6 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://telegram.me/DeusApollo' ) )
   else :
    webbrowser . open ( 'http://telegram.me/DeusApollo' )
    if 77 - 77: I11i * iIii1I11I1II1
  if I1i1Iiiii == 7 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.facebook.com/groups/Deus.Apollo' ) )
   else :
    webbrowser . open ( 'https://www.facebook.com/groups/Deus.Apollo' )
    if 98 - 98: oOooOoO0Oo0O % iII111i * OoooooooOO
  if I1i1Iiiii == 9 :
   xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
   xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
   if 51 - 51: iIii1I11I1II1 . o0 / OOooOOo + i1
   if 33 - 33: o00O0oo . i11i % IiII + i1
  if I1i1Iiiii == 9 :
   xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
   xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
   if 71 - 71: I11i11Ii % I11i
def O00oO000O0O ( msg ) :
 I1IiiiiI ( o00 , OO0O00 , 1 , oOO00Oo , i1iI11i1ii11 , o0O ( oO0o0o0ooO0oO ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 oOooOo0 ( True )
 oOI1Ii1I1 ( )
 if 18 - 18: IiII - I11i . ooOoO0o . iIii1I11I1II1
 i1I ( IIII , '' )
 I1IiiiiI ( o0Oo0O0Oo00oO , '' , 54 , I11i1I1I , i1iI11i1ii11 , o0O ( oOOoo0Oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 if 78 - 78: Ii1I * iIii1I11I1II1 . oOooOoO0Oo0O / i1 - OoooooooOO / ooOoO0o
 i1I1IiiIi1i ( )
 O00o0OO0 ( True )
 if 29 - 29: oOooOoO0Oo0O % oOooOoO0Oo0O
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 94 - 94: iIii1I11I1II1 / I11i11Ii % IiII * IiII * i11i
 if 29 - 29: i1iIi11iIIi1I + o0 / i1 / I11i * iIii1I11I1II1
def O0OO ( msg ) :
 try :
  ii1iI1I11I = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/version.txt" ) . read ( ) . replace ( '' , '' ) . replace ( '\r' , '' )
  ii1iI1I11I = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( ii1iI1I11I ) [ 0 ]
  if 20 - 20: OOooOOo / O0 * i1 - ooOoO0o % OoooooooOO * I1Ii111
  if ii1iI1I11I != Oo :
   III1111iIi1i1 ( )
   if 55 - 55: I1Ii111 * OoooooooOO + iIii1I11I1II1
  elif msg == True :
   if 17 - 17: OoooooooOO / iII111i % ii1IiI1i
   O00o0OO0 ( True )
   if 76 - 76: I1Ii111 * IiII
 except urllib2 . URLError , ooooooo00o :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( 'Apollo' , "Não foi possível checar" )
   if 73 - 73: I11i
def ooO ( msg ) :
 try :
  ii1iI1I11I = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/version.txt" ) . read ( ) . replace ( '' , '' ) . replace ( '\r' , '' )
  ii1iI1I11I = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( ii1iI1I11I ) [ 0 ]
  if 51 - 51: oOooOoO0Oo0O % ooOoO0o . OOooOOo / iIii1I11I1II1 / Ii1I . OOooOOo
  if ii1iI1I11I != Oo :
   III1111iIi1i1 ( )
   if 42 - 42: i1 + i1IIi - iII111i / I1Ii111
  elif msg == True :
   xbmcgui . Dialog ( ) . ok ( '[COLOR orange][B]APOLLO[/COLOR][/B]' , "[COLOR deepskyblue][B] O ADD-ON JÁ ESTÁ NA ÚLTIMA VERSÃO![/COLOR][/B][COLOR orange][B] 1.5.4[/COLOR][/B] " + Oo + "[COLOR deepskyblue][B] ATUALIZAÇÕES SÃO AUTOMÁTICAS SE NÃO ATUALIZA ENTRE NO SITE[/COLOR][/B][COLOR orange][B] http://deus-apollo.ml[/COLOR][/B]" )
   if 9 - 9: O0 % O0 - i1
 except urllib2 . URLError , ooooooo00o :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( 'Apollo' , "Não foi possível checar" )
   if 51 - 51: oOooOoO0Oo0O . iIii1I11I1II1 - ii1IiI1i / O0
   if 52 - 52: i1 + O0 + IiII + I11i11Ii % IiII
def III1111iIi1i1 ( ) :
 OO = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 try :
  Ii1iI111II1I1 = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/apollo.py" ) . read ( ) . replace ( '' , '' )
  oOOOOoOO0o = re . compile ( 'checkintegrity' ) . findall ( Ii1iI111II1I1 )
  if oOOOOoOO0o :
   i1II1 = os . path . join ( OO , "apollo.py" )
   file = open ( i1II1 , "w" )
   file . write ( Ii1iI111II1I1 )
   file . close ( )
  Ii1iI111II1I1 = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/resources/settings.xml" ) . read ( ) . replace ( '' , '' )
  oOOOOoOO0o = re . compile ( '</settings>' ) . findall ( Ii1iI111II1I1 )
  if oOOOOoOO0o :
   i1II1 = os . path . join ( OO , "resources/settings.xml" )
   file = open ( i1II1 , "w" )
   file . write ( Ii1iI111II1I1 )
   file . close ( )
  Ii1iI111II1I1 = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/addon.xml" ) . read ( ) . replace ( '' , '' )
  oOOOOoOO0o = re . compile ( '</addon>' ) . findall ( Ii1iI111II1I1 )
  if oOOOOoOO0o :
   i1II1 = os . path . join ( OO , "addon.xml" )
   file = open ( i1II1 , "w" )
   file . write ( Ii1iI111II1I1 )
   file . close ( )
  xbmcgui . Dialog ( ) . ok ( '[COLOR deepskyblue][B]APOLLO[/COLOR][/B]' , "OBS: ADD-ON ESTÁ DESATUALIZADO! CLIQUE EM OK PARA ELE SE ALTO ATUALIZAR! CASO O ADD-ON NÃO SE ATUALIZE FAÇA O DOWNLOAD NO SITE OFICIAL! [COLOR deepskyblue][B]->[/COLOR][/B][COLOR orange][COLOR orange][B] https://deus-apollo.ml[/COLOR][/B]" ) . xbmc . executebuiltin
 except :
  xbmc . executebuiltin ( "Notification({0}, {1}, 9000, {2})" . format ( __addonname__ , "[COLOR orange][B]Atualizando o addon. Por favor aguarde 5 segundos e Pode Continuar![/COLOR][/B]" , __icon__ ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 25 - 25: ooOoO0o / iIii1I11I1II1 % IiII
ooO ( False )
if 42 - 42: i11iIiiIii * iIii1I11I1II1 / ii1IiI1i . i11iIiiIii % Ii1I
def i1iI ( ) :
 IiI1iiiIii = {
 "Accept-Language" : "en-US,en;q=0.5" ,
 "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" ,
 "Referer" : "APOLLO 1.5.4" ,
 "Connection" : "keep-alive"
 }
 I1III1111iIi = urllib2 . Request ( "https://whos.amung.us/pingjs/?k=c4302b" , headers = IiI1iiiIii )
 oO00OOoO00 = urllib2 . urlopen ( I1III1111iIi ) . read ( )
 if 38 - 38: IiII + Ii1I / ooOoO0o % o00O0oo - ii1IiI1i
 if 14 - 14: OOooOOo / ooOoO0o
i1iI ( )
if 85 - 85: Ii1I
def iI1i11II1i ( url , headers = None ) :
 try :
  if headers is None :
   if 96 - 96: ooOoO0o
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
   headers = { 'User-agent' : '�}q�|{�\�~1�|{�\�}�ߜ{�\Ǯqߌ{�\�~q߼{�\�~�߬{�\ǭq߼{�\ǭ�ߌ{�\�~�߼{�\�}�ߌ{�\�1ߜ{�\�qߜ{�' }
  oOoOo0O0OOOoO = urllib2 . Request ( url , None , headers )
  oO00OOoO00 = urllib2 . urlopen ( oOoOo0O0OOOoO )
  IiI111111IIII = oO00OOoO00 . read ( )
  oO00OOoO00 . close ( )
  return IiI111111IIII
 except urllib2 . URLError , ooooooo00o :
  I1iI1iIi111i ( 'URL: ' + url )
  if hasattr ( ooooooo00o , 'code' ) :
   I1iI1iIi111i ( 'Falha com o código de erro - %s.' % ooooooo00o . code )
   if 50 - 50: o00O0oo
   if 47 - 47: I11i11Ii * ii1IiI1i + iIii1I11I1II1 / ooOoO0o / i1iIi11iIIi1I - OoooooooOO
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( ooooooo00o . code ) + ",10000," + oOO00Oo + ")" )
  elif hasattr ( ooooooo00o , 'reason' ) :
   I1iI1iIi111i ( 'Falha ao acessar um servidor.' )
   I1iI1iIi111i ( 'Razão: %s' % ooooooo00o . reason )
   if 33 - 33: o0 * I11i - i11i
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( ooooooo00o . reason ) + ",10000," + oOO00Oo + ")" )
   if 83 - 83: o0 - iII111i / Ii1I / ooOoO0o + OOooOOo - O0
def o0O ( url ) :
 IIi = urllib2 . build_opener ( )
 if 4 - 4: I11i * i1iIi11iIIi1I % i1IIi * i11iIiiIii % I11i11Ii - OOooOOo
 IIi . addheaders = [ ( 'User-Agent' , o0OOOOO00o0O0 ) ]
 oO00OOoO00 = IIi . open ( url )
 OOoOoOo = oO00OOoO00 . read ( )
 return OOoOoOo
 if 98 - 98: IiII
 if 68 - 68: iIii1I11I1II1 * iIii1I11I1II1 . i1 / i11i % I11i11Ii
def i1I1IiiIi1i ( ) :
 i1i11I11 = oO . getSetting ( 'mensagem2' )
 if i1i11I11 == 'true' :
  IIi = urllib2 . build_opener ( )
  if 10 - 10: O0 - OoooooooOO . o0
  IIi . addheaders = [ ( 'User-Agent' , o0OOOOO00o0O0 ) ]
  if 44 - 44: I1Ii111 - i1 . i1IIi . I1Ii111 * o0
  oO00OOoO00 = IIi . open ( OO0O0O00OooO )
  i1Ii1i1I11Iii = oO00OOoO00 . read ( )
  if 25 - 25: I1Ii111 + iII111i / o00O0oo . i1 % O0 * i1iIi11iIIi1I
  time = IiI1I1
  xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , i1Ii1i1I11Iii , time , __icon__ ) )
  if 84 - 84: o00O0oo % iII111i + i11iIiiIii
  if 28 - 28: I11i11Ii + i1iIi11iIIi1I * I11i % OOooOOo . Ii1I % O0
def I1iiiiIii ( ) :
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 19 - 19: i1iIi11iIIi1I - I11i11Ii . O0
def ooOo00 ( ) :
 if os . path . exists ( O00OOOoOoo0O ) == True :
  I1IiiiiI ( 'Favorites' , 'url' , 4 , os . path . join ( ii1ii11IIIiiI , 'resources' , 'favorite.png' ) , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "browse_xml_database" ) == "true" :
  I1IiiiiI ( 'XML Database' , 'http://xbmcplus.xb.funpic.de/www-data/filesystem/' , 15 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "browse_community" ) == "true" :
  I1IiiiiI ( 'Community Files' , 'community_files' , 16 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if os . path . exists ( O000OOo00oo ) == True :
  I1IiiiiI ( 'Search History' , 'history' , 25 , os . path . join ( ii1ii11IIIiiI , 'resources' , 'favorite.png' ) , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "searchyt" ) == "true" :
  I1IiiiiI ( 'Search:Youtube' , 'youtube' , 25 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "searchDM" ) == "true" :
  I1IiiiiI ( 'Search:dailymotion' , 'dmotion' , 25 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if oO . getSetting ( "PulsarM" ) == "true" :
  I1IiiiiI ( 'Pulsar:IMDB' , 'IMDBidplay' , 27 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
  if os . path . exists ( OOooo0O00o ) == True :
   OOoo = json . loads ( open ( OOooo0O00o , "r" ) . read ( ) )
   if 50 - 50: i1iIi11iIIi1I
  if len ( OOoo ) > 1 :
   for ii in OOoo :
    if 25 - 25: OoooooooOO - oOooOoO0Oo0O . oOooOoO0Oo0O * OOooOOo
    if isinstance ( ii , list ) :
     I1IiiiiI ( ii [ 0 ] . encode ( 'utf-8' ) , ii [ 1 ] . encode ( 'utf-8' ) , 1 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' , 'source' )
    else :
     o000oo = oOO00Oo
     o00o0 = i1iI11i1ii11
     II1I = ''
     II1I1I1Ii = ''
     credits = ''
     OOOOoO00o0O = ''
     I1I1I1IIi1III = ''
     II11IiiIII = ''
     o0OOOo = ''
     ii1iiIiIII1ii = ''
     oO0o0oooO0oO = ''
     IiIiII1 = ''
     Iii1iiIi1II = ''
     OO0O00oOo = ''
     ii1II = ''
     iI1I = ''
     OooOoOo = ''
     if ii . has_key ( 'thumbnail' ) :
      o000oo = ii [ 'thumbnail' ]
     if ii . has_key ( 'fanart' ) :
      o00o0 = ii [ 'fanart' ]
     if ii . has_key ( 'description' ) :
      II1I = ii [ 'description' ]
     if ii . has_key ( 'date' ) :
      II1I1I1Ii = ii [ 'date' ]
     if ii . has_key ( 'genre' ) :
      III1I1Iii1iiI = ii [ 'genre' ]
     if ii . has_key ( 'credits' ) :
      credits = ii [ 'credits' ]
     if ii . has_key ( 'year' ) :
      OOOOoO00o0O = ii [ 'year' ]
     if ii . has_key ( 'director' ) :
      I1I1I1IIi1III = ii [ 'director' ]
     if ii . has_key ( 'duration' ) :
      II11IiiIII = ii [ 'duration' ]
     if ii . has_key ( 'premiered' ) :
      o0OOOo = ii [ 'premiered' ]
     if ii . has_key ( 'studio' ) :
      ii1iiIiIII1ii = ii [ 'studio' ]
     if ii . has_key ( 'rate' ) :
      oO0o0oooO0oO = ii [ 'rate' ]
     if ii . has_key ( 'originaltitle' ) :
      IiIiII1 = ii [ 'originaltitle' ]
     if ii . has_key ( 'country' ) :
      Iii1iiIi1II = ii [ 'country' ]
     if ii . has_key ( 'rating' ) :
      OO0O00oOo = ii [ 'rating' ]
     if ii . has_key ( 'userrating' ) :
      ii1II = ii [ 'userrating' ]
     if ii . has_key ( 'votes' ) :
      iI1I = ii [ 'votes' ]
     if ii . has_key ( 'aired' ) :
      OooOoOo = ii [ 'aired' ]
     I1IiiiiI ( ii [ 'title' ] . encode ( 'utf-8' ) , ii [ 'url' ] . encode ( 'utf-8' ) , 1 , o000oo , o00o0 , II1I , III1I1Iii1iiI , II1I1I1Ii , credits , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , 'source' )
     if 17 - 17: iII111i % iIii1I11I1II1 - iIii1I11I1II1
  else :
   if len ( OOoo ) == 1 :
    if isinstance ( OOoo [ 0 ] , list ) :
     i1I ( OOoo [ 0 ] [ 1 ] . encode ( 'utf-8' ) , i1iI11i1ii11 )
    else :
     i1I ( OOoo [ 0 ] [ 'url' ] , OOoo [ 0 ] [ 'fanart' ] )
     if 78 - 78: IiII + Ii1I . o00O0oo - IiII . iII111i
     if 30 - 30: oOooOoO0Oo0O + i1iIi11iIIi1I % iII111i * IiII / I11i11Ii - Ii1I
def oooiIi1i ( url = None ) :
 if url is None :
  if not oO . getSetting ( "new_file_source" ) == "" :
   I1i11111i1i11 = oO . getSetting ( 'new_file_source' ) . decode ( 'utf-8' )
  elif not oO . getSetting ( "new_url_source" ) == "" :
   I1i11111i1i11 = oO . getSetting ( 'new_url_source' ) . decode ( 'utf-8' )
 else :
  I1i11111i1i11 = url
 if I1i11111i1i11 == '' or I1i11111i1i11 is None :
  return
 I1iI1iIi111i ( 'Adding New Source: ' + I1i11111i1i11 . encode ( 'utf-8' ) )
 if 77 - 77: ii1IiI1i + i1iIi11iIIi1I / OOooOOo + O0 * i1
 I1ii11 = None
 if 74 - 74: I11i11Ii - i1 . i1IIi
 IiI111111IIII = i1III ( I1i11111i1i11 )
 print 'source_url' , I1i11111i1i11
 if isinstance ( IiI111111IIII , BeautifulSOAP ) :
  if IiI111111IIII . find ( 'channels_info' ) :
   I1ii11 = IiI111111IIII . channels_info
  elif IiI111111IIII . find ( 'items_info' ) :
   I1ii11 = IiI111111IIII . items_info
 if I1ii11 :
  iii1Ii1Ii1 = { }
  iii1Ii1Ii1 [ 'url' ] = I1i11111i1i11
  try : iii1Ii1Ii1 [ 'title' ] = I1ii11 . title . string
  except : pass
  try : iii1Ii1Ii1 [ 'thumbnail' ] = I1ii11 . thumbnail . string
  except : pass
  try : iii1Ii1Ii1 [ 'fanart' ] = I1ii11 . fanart . string
  except : pass
  try : iii1Ii1Ii1 [ 'genre' ] = I1ii11 . genre . string
  except : pass
  try : iii1Ii1Ii1 [ 'description' ] = I1ii11 . description . string
  except : pass
  try : iii1Ii1Ii1 [ 'date' ] = I1ii11 . date . string
  except : pass
  try : iii1Ii1Ii1 [ 'credits' ] = I1ii11 . credits . string
  except : pass
  try : iii1Ii1Ii1 [ 'year' ] = I1ii11 . year . string
  except : pass
  try : iii1Ii1Ii1 [ 'director' ] = I1ii11 . director . string
  except : pass
  try : iii1Ii1Ii1 [ 'premiered' ] = I1ii11 . premiered . string
  except : pass
  try : iii1Ii1Ii1 [ 'studio' ] = I1ii11 . studio . string
  except : pass
  try : iii1Ii1Ii1 [ 'rate' ] = I1ii11 . rate . string
  except : pass
  try : iii1Ii1Ii1 [ 'originaltitle' ] = I1ii11 . originaltitle . string
  except : pass
  try : iii1Ii1Ii1 [ 'country' ] = I1ii11 . country . string
  except : pass
  try : iii1Ii1Ii1 [ 'rating' ] = I1ii11 . rating . string
  except : pass
  try : iii1Ii1Ii1 [ 'userrating' ] = I1ii11 . userrating . string
  except : pass
  try : iii1Ii1Ii1 [ 'votes' ] = I1ii11 . votes . string
  except : pass
  try : iii1Ii1Ii1 [ 'aired' ] = I1ii11 . aired . string
  except : pass
 else :
  if '/' in I1i11111i1i11 :
   IIiooO0oOo0o = I1i11111i1i11 . split ( '/' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '\\' in I1i11111i1i11 :
   IIiooO0oOo0o = I1i11111i1i11 . split ( '\\' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '%' in IIiooO0oOo0o :
   IIiooO0oOo0o = urllib . unquote_plus ( IIiooO0oOo0o )
  OOii111IiiI1 = xbmc . Keyboard ( IIiooO0oOo0o , 'Displayed Name, Rename?' )
  OOii111IiiI1 . doModal ( )
  if ( OOii111IiiI1 . isConfirmed ( ) == False ) :
   return
  ii11i1iIiII1 = OOii111IiiI1 . getText ( )
  if len ( ii11i1iIiII1 ) == 0 :
   return
  iii1Ii1Ii1 = { }
  iii1Ii1Ii1 [ 'title' ] = ii11i1iIiII1
  iii1Ii1Ii1 [ 'url' ] = I1i11111i1i11
  iii1Ii1Ii1 [ 'fanart' ] = o00o0
  if 63 - 63: i1iIi11iIIi1I
 if os . path . exists ( OOooo0O00o ) == False :
  Oo0 = [ ]
  Oo0 . append ( iii1Ii1Ii1 )
  oooooOOO000Oo = open ( OOooo0O00o , "w" )
  oooooOOO000Oo . write ( json . dumps ( Oo0 ) )
  oooooOOO000Oo . close ( )
 else :
  OOoo = json . loads ( open ( OOooo0O00o , "r" ) . read ( ) )
  OOoo . append ( iii1Ii1Ii1 )
  oooooOOO000Oo = open ( OOooo0O00o , "w" )
  oooooOOO000Oo . write ( json . dumps ( OOoo ) )
  oooooOOO000Oo . close ( )
 oO . setSetting ( 'new_url_source' , "" )
 oO . setSetting ( 'new_file_source' , "" )
 if 52 - 52: i11i % I1Ii111 . o0 * iIii1I11I1II1
 xbmc . executebuiltin ( "XBMC.Notification(New source added.,5000," + oOO00Oo + ")" )
 if not url is None :
  if 'xbmcplus.xb.funpic.de' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=14,replace)" % sys . argv [ 0 ] )
  elif 'community-links' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=10,replace)" % sys . argv [ 0 ] )
 else : oO . openSettings ( )
 if 50 - 50: o00O0oo - ooOoO0o * I1Ii111 . ii1IiI1i
 if 37 - 37: o00O0oo % i11iIiiIii % i11i . O0 . iII111i
def OO0oOOoo ( name ) :
 OOoo = json . loads ( open ( OOooo0O00o , "r" ) . read ( ) )
 for oOOO00o000o in range ( len ( OOoo ) ) :
  if isinstance ( OOoo [ oOOO00o000o ] , list ) :
   if OOoo [ oOOO00o000o ] [ 0 ] == name :
    del OOoo [ oOOO00o000o ]
    oooooOOO000Oo = open ( OOooo0O00o , "w" )
    oooooOOO000Oo . write ( json . dumps ( OOoo ) )
    oooooOOO000Oo . close ( )
    break
  else :
   if OOoo [ oOOO00o000o ] [ 'title' ] == name :
    del OOoo [ oOOO00o000o ]
    oooooOOO000Oo = open ( OOooo0O00o , "w" )
    oooooOOO000Oo . write ( json . dumps ( OOoo ) )
    oooooOOO000Oo . close ( )
    break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 9 - 9: OOooOOo + Ii1I / Ii1I
 if 12 - 12: OoooooooOO % i1 * Ii1I % iIii1I11I1II1 / iII111i
 if 27 - 27: i11iIiiIii % i11i % Ii1I . O0 - I11i11Ii + o0
def ooO0o ( url , browse = False ) :
 if url is None :
  url = 'http://xbmcplus.xb.funpic.de/www-data/filesystem/'
 ooOOo00O00Oo = BeautifulSoup ( iI1i11II1i ( url ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 for ii in ooOOo00O00Oo ( 'a' ) :
  IiII1 = ii [ 'href' ]
  if not IiII1 . startswith ( '?' ) :
   I1iIi1iIiiIiI = ii . string
   if I1iIi1iIiiIiI not in [ 'Parent Directory' , 'recycle_bin/' ] :
    if IiII1 . endswith ( '/' ) :
     if browse :
      I1IiiiiI ( I1iIi1iIiiIiI , url + IiII1 , 15 , oOO00Oo , o00o0 , '' , '' , '' )
     else :
      I1IiiiiI ( I1iIi1iIiiIiI , url + IiII1 , 14 , oOO00Oo , o00o0 , '' , '' , '' )
    elif IiII1 . endswith ( '.xml' ) :
     if browse :
      I1IiiiiI ( I1iIi1iIiiIiI , url + IiII1 , 1 , oOO00Oo , o00o0 , '' , '' , '' , '' , 'download' )
     else :
      if os . path . exists ( OOooo0O00o ) == True :
       if I1iIi1iIiiIiI in I1 :
        I1IiiiiI ( I1iIi1iIiiIiI + ' (in use)' , url + IiII1 , 11 , oOO00Oo , o00o0 , '' , '' , '' , '' , 'download' )
       else :
        I1IiiiiI ( I1iIi1iIiiIiI , url + IiII1 , 11 , oOO00Oo , o00o0 , '' , '' , '' , '' , 'download' )
      else :
       I1IiiiiI ( I1iIi1iIiiIiI , url + IiII1 , 11 , oOO00Oo , o00o0 , '' , '' , '' , '' , 'download' )
       if 47 - 47: iII111i + ooOoO0o / i1IIi % i11iIiiIii
       if 42 - 42: IiII + I1Ii111
def o00oOoOo0 ( browse = False ) :
 O0O0Oooo0o = 'http://community-links.googlecode.com/svn/trunk/'
 ooOOo00O00Oo = BeautifulSoup ( iI1i11II1i ( O0O0Oooo0o ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 o0O0O0ooo0oOO = ooOOo00O00Oo ( 'ul' ) [ 0 ] ( 'li' ) [ 1 : ]
 for ii in o0O0O0ooo0oOO :
  I1iIi1iIiiIiI = ii ( 'a' ) [ 0 ] [ 'href' ]
  if browse :
   I1IiiiiI ( I1iIi1iIiiIiI , O0O0Oooo0o + I1iIi1iIiiIiI , 1 , oOO00Oo , o00o0 , '' , '' , '' , '' , 'download' )
  else :
   I1IiiiiI ( I1iIi1iIiiIiI , O0O0Oooo0o + I1iIi1iIiiIiI , 11 , oOO00Oo , o00o0 , '' , '' , '' , '' , 'download' )
   if 97 - 97: oOooOoO0Oo0O / IiII
   if 71 - 71: i11i / i1IIi . ii1IiI1i % OoooooooOO . o0
def i1III ( url , data = None ) :
 global o0OO00 , iI1
 iI1 = False
 if url . startswith ( 'http://' ) or url . startswith ( 'https://' ) :
  Iiiiii111i1ii = False
  if '$$TSDOWNLOADER$$' in url :
   iI1 = True
   url = url . replace ( "$$TSDOWNLOADER$$" , "" )
  if '$$LSProEncKey=' in url :
   Iiiiii111i1ii = url . split ( '$$LSProEncKey=' ) [ 1 ] . split ( '$$' ) [ 0 ]
   i1i1iII1 = '$$LSProEncKey=%s$$' % Iiiiii111i1ii
   url = url . replace ( i1i1iII1 , "" )
  try :
   print 'myRequest' , url , data
   data = iI1i11II1i ( url )
   import gzip , binascii
   from StringIO import StringIO
   if 'tgjds' [ : : - 1 ] in data :
    data = data . split ( 'tgjds' [ : : - 1 ] )
    iii11i1IIII = StringIO ( binascii . unhexlify ( data [ 0 ] ) )
    Ii = gzip . GzipFile ( fileobj = iii11i1IIII )
    data = Ii . read ( )
  except :
   data = iI1i11II1i ( url )
  if Iiiiii111i1ii :
   import pyaes
   Iiiiii111i1ii = Iiiiii111i1ii . encode ( "ascii" )
   print Iiiiii111i1ii
   o00iiI1Ii1 = 16 - len ( Iiiiii111i1ii )
   Iiiiii111i1ii = Iiiiii111i1ii + ( chr ( 0 ) * ( o00iiI1Ii1 ) )
   print repr ( Iiiiii111i1ii )
   data = base64 . b64decode ( data )
   ii1i = pyaes . new ( Iiiiii111i1ii , pyaes . MODE_ECB , IV = None )
   data = ii1i . decrypt ( data ) . split ( '\0' ) [ 0 ]
   if 62 - 62: i1iIi11iIIi1I / ii1IiI1i
  if re . search ( "#EXTM3U" , data ) or 'm3u' in url :
   if 7 - 7: OoooooooOO . I1Ii111
   return data
 elif data == None :
  if not '/' in url or not '\\' in url :
   if 53 - 53: iII111i % iII111i * i1 + o0
   url = os . path . join ( communityfiles , url )
  if xbmcvfs . exists ( url ) :
   if url . startswith ( "smb://" ) or url . startswith ( "nfs://" ) :
    Oooo00 = xbmcvfs . copy ( url , os . path . join ( O0oOoOOOoOO , 'temp' , 'sorce_temp.txt' ) )
    if Oooo00 :
     data = open ( os . path . join ( O0oOoOOOoOO , 'temp' , 'sorce_temp.txt' ) , "r" ) . read ( )
     xbmcvfs . delete ( os . path . join ( O0oOoOOOoOO , 'temp' , 'sorce_temp.txt' ) )
    else :
     I1iI1iIi111i ( "failed to copy from smb:" )
   else :
    data = open ( url , 'r' ) . read ( )
    if re . match ( "#EXTM3U" , data ) or 'm3u' in url :
     if 6 - 6: iII111i - o00O0oo * I11i . IiII / O0 * o00O0oo
     return data
  else :
   I1iI1iIi111i ( "Soup Data not found!" )
   return
 if '<SetViewMode>' in data :
  try :
   o0OO00 = re . findall ( '<SetViewMode>(.*?)<' , data ) [ 0 ]
   xbmc . executebuiltin ( "Container.SetViewMode(%s)" % o0OO00 )
   print 'done setview' , o0OO00
  except : pass
 return BeautifulSOAP ( data , convertEntities = BeautifulStoneSoup . XML_ENTITIES )
 if 22 - 22: I11i11Ii % IiII * ii1IiI1i / I11i % i11iIiiIii * Ii1I
 if 95 - 95: OoooooooOO - I1Ii111 * oOooOoO0Oo0O + o0
def i1I ( url , fanart , data = None ) :
 if 10 - 10: i1 / i11iIiiIii
 o00oO = "List"
 if 92 - 92: I1Ii111 * I11i11Ii * I11i11Ii * oOooOoO0Oo0O . iIii1I11I1II1
 ooOOo00O00Oo = i1III ( url , data )
 if 16 - 16: o00O0oo % OoooooooOO - I11i * iII111i * ii1IiI1i / OoooooooOO
 if isinstance ( ooOOo00O00Oo , BeautifulSOAP ) :
  if len ( ooOOo00O00Oo ( 'layoutype' ) ) > 0 :
   o00oO = "thumbnail"
   if 31 - 31: Ii1I . ooOoO0o * o00O0oo + i11iIiiIii * OOooOOo
  if len ( ooOOo00O00Oo ( 'channels' ) ) > 0 :
   OO0o = ooOOo00O00Oo ( 'channel' )
   for oo0o0O0Oooooo in OO0o :
    if 1 - 1: o00O0oo % o0 * I11i11Ii
    if 55 - 55: o0
    Ooo0oo0ooO = ''
    OoOOOo0o0ooo = 0
    try :
     Ooo0oo0ooO = oo0o0O0Oooooo ( 'externallink' ) [ 0 ] . string
     OoOOOo0o0ooo = len ( oo0o0O0Oooooo ( 'externallink' ) )
    except : pass
    if 19 - 19: Ii1I % i11i / i11iIiiIii / IiII - OoooooooOO
    if OoOOOo0o0ooo > 1 : Ooo0oo0ooO = ''
    if 37 - 37: I11i / OoooooooOO - i11iIiiIii
    I1iIi1iIiiIiI = oo0o0O0Oooooo ( 'name' ) [ 0 ] . string
    i1iIiIi1I = oo0o0O0Oooooo ( 'thumbnail' ) [ 0 ] . string
    if i1iIiIi1I == None :
     i1iIiIi1I = ''
     if 45 - 45: i1IIi + i11i
    try :
     if not oo0o0O0Oooooo ( 'fanart' ) :
      if oO . getSetting ( 'use_thumb' ) == "true" :
       IiII1II11I = i1iIiIi1I
      else :
       IiII1II11I = fanart
     else :
      IiII1II11I = oo0o0O0Oooooo ( 'fanart' ) [ 0 ] . string
     if IiII1II11I == None :
      raise
    except :
     IiII1II11I = fanart
     if 54 - 54: I1Ii111 + O0 + Ii1I * ooOoO0o - I11i % OOooOOo
    try :
     II1I = oo0o0O0Oooooo ( 'info' ) [ 0 ] . string
     if II1I == None :
      raise
    except :
     II1I = ''
     if 13 - 13: o00O0oo / IiII * i1iIi11iIIi1I . i1iIi11iIIi1I * o00O0oo
    try :
     III1I1Iii1iiI = oo0o0O0Oooooo ( 'genre' ) [ 0 ] . string
     if III1I1Iii1iiI == None :
      raise
    except :
     III1I1Iii1iiI = ''
     if 63 - 63: ooOoO0o / O0 * I11i11Ii + i11i / I1Ii111 + iII111i
    try :
     II1I1I1Ii = oo0o0O0Oooooo ( 'date' ) [ 0 ] . string
     if II1I1I1Ii == None :
      raise
    except :
     II1I1I1Ii = ''
     if 63 - 63: i1iIi11iIIi1I + ii1IiI1i . ooOoO0o % ooOoO0o
    try :
     credits = oo0o0O0Oooooo ( 'credits' ) [ 0 ] . string
     if credits == None :
      raise
    except :
     credits = ''
     if 57 - 57: i11i
    try :
     OOOOoO00o0O = oo0o0O0Oooooo ( 'year' ) [ 0 ] . string
     if OOOOoO00o0O == None :
      raise
    except :
     OOOOoO00o0O = ''
     if 54 - 54: I11i11Ii + OOooOOo + i11iIiiIii
    try :
     I1I1I1IIi1III = oo0o0O0Oooooo ( 'director' ) [ 0 ] . string
     if I1I1I1IIi1III == None :
      raise
    except :
     I1I1I1IIi1III = ''
     if 28 - 28: OOooOOo
    try :
     II11IiiIII = oo0o0O0Oooooo ( 'duration' ) [ 0 ] . string
     if II11IiiIII == None :
      raise
    except :
     II11IiiIII = ''
     if 70 - 70: I1Ii111
    try :
     o0OOOo = oo0o0O0Oooooo ( 'premiered' ) [ 0 ] . string
     if o0OOOo == None :
      raise
    except :
     o0OOOo = ''
     if 34 - 34: ooOoO0o % I1Ii111
    try :
     ii1iiIiIII1ii = oo0o0O0Oooooo ( 'studio' ) [ 0 ] . string
     if ii1iiIiIII1ii == None :
      raise
    except :
     ii1iiIiIII1ii = ''
     if 3 - 3: i11i / I11i + I1Ii111 . o00O0oo . i1iIi11iIIi1I
    try :
     oO0o0oooO0oO = oo0o0O0Oooooo ( 'rate' ) [ 0 ] . string
     if oO0o0oooO0oO == None :
      raise
    except :
     oO0o0oooO0oO = ''
     if 83 - 83: OOooOOo + OoooooooOO
    try :
     IiIiII1 = oo0o0O0Oooooo ( 'originaltitle' ) [ 0 ] . string
     if IiIiII1 == None :
      raise
    except :
     IiIiII1 = ''
     if 22 - 22: iII111i % IiII * OoooooooOO - i1 / iIii1I11I1II1
    try :
     Iii1iiIi1II = oo0o0O0Oooooo ( 'country' ) [ 0 ] . string
     if Iii1iiIi1II == None :
      raise
    except :
     Iii1iiIi1II = ''
     if 86 - 86: OoooooooOO . IiII % o0 / Ii1I * IiII / i1
    try :
     oOoOOo000oOoO0 = oo0o0O0Oooooo ( 'mediatype' ) [ 0 ] . string
     if oOoOOo000oOoO0 == None :
      raise
    except :
     oOoOOo000oOoO0 = ''
     if 86 - 86: i11i % i11iIiiIii + iII111i % i11iIiiIii
    try :
     OO0O00oOo = oo0o0O0Oooooo ( 'rating' ) [ 0 ] . string
     if OO0O00oOo == None :
      raise
    except :
     OO0O00oOo = ''
     if 92 - 92: i11iIiiIii - IiII / o00O0oo / OOooOOo
    try :
     ii1II = oo0o0O0Oooooo ( 'userrating' ) [ 0 ] . string
     if ii1II == None :
      raise
    except :
     ii1II = ''
     if 43 - 43: i11i + I11i + IiII
    try :
     iI1I = oo0o0O0Oooooo ( 'votes' ) [ 0 ] . string
     if iI1I == None :
      raise
    except :
     iI1I = ''
     if 40 - 40: i1
    try :
     OooOoOo = oo0o0O0Oooooo ( 'aired' ) [ 0 ] . string
     if OooOoOo == None :
      raise
    except :
     OooOoOo = ''
     if 67 - 67: OOooOOo + i11i - O0 . OOooOOo * i11i * Ii1I
    try :
     if Ooo0oo0ooO == '' :
      I1IiiiiI ( I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 2 , i1iIiIi1I , IiII1II11I , II1I , III1I1Iii1iiI , II1I1I1Ii , credits , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , True )
     else :
      if 90 - 90: iII111i . I1Ii111
      I1IiiiiI ( I1iIi1iIiiIiI . encode ( 'utf-8' ) , Ooo0oo0ooO . encode ( 'utf-8' ) , 1 , i1iIiIi1I , IiII1II11I , II1I , III1I1Iii1iiI , II1I1I1Ii , None , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , 'source' )
    except :
     I1iI1iIi111i ( 'There was a problem adding directory from getData(): ' + I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) )
  else :
   I1iI1iIi111i ( 'No Channels: getItems' )
   OO00O0oOO ( ooOOo00O00Oo ( 'item' ) , fanart )
 else :
  Ii1iI111 ( ooOOo00O00Oo )
  if 51 - 51: I1Ii111 * O0 / i11i . iII111i % I11i / oOooOoO0Oo0O
 if o00oO == "thumbnail" :
  ii1iii1I1I ( )
  if 95 - 95: I1Ii111
  if 51 - 51: i11i + I1Ii111 . i1IIi . ii1IiI1i + o0 * oOooOoO0Oo0O
  if 72 - 72: OOooOOo + OOooOOo / i11i . OoooooooOO % iII111i
def Ii1iI111 ( data ) :
 III = data . rstrip ( )
 IiiIii = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)' ) . findall ( III )
 oOo0OoOOo0 = len ( IiiIii )
 print 'tsdownloader' , iI1
 if 30 - 30: ii1IiI1i % oOooOoO0Oo0O
 for O0Oo00 , ii1IiIIi1i , oOOo0OOOOo0Oo in IiiIii :
  if 67 - 67: OOooOOo / IiII . Ii1I . iIii1I11I1II1
  if 'tvg-logo' in O0Oo00 :
   i1iIiIi1I = iiiI ( O0Oo00 , 'tvg-logo=[\'"](.*?)[\'"]' )
   if i1iIiIi1I :
    if i1iIiIi1I . startswith ( 'http' ) :
     i1iIiIi1I = i1iIiIi1I
     if 21 - 21: i11iIiiIii / i1IIi + oOooOoO0Oo0O * I11i . ooOoO0o
    elif not oO . getSetting ( 'logo-folderPath' ) == "" :
     OoO = oO . getSetting ( 'logo-folderPath' )
     i1iIiIi1I = OoO + i1iIiIi1I
     if 73 - 73: i11i
    else :
     i1iIiIi1I = i1iIiIi1I
     if 24 - 24: o0 / OoooooooOO . i11i . oOooOoO0Oo0O % O0 % iII111i
     if 5 - 5: OoooooooOO - i1iIi11iIIi1I + I1Ii111 - IiII . i1iIi11iIIi1I / o00O0oo
  else :
   i1iIiIi1I = ''
   if 28 - 28: iII111i * iII111i - iIii1I11I1II1
  if 'type' in O0Oo00 :
   ooOO00oOOo000 = iiiI ( O0Oo00 , 'type=[\'"](.*?)[\'"]' )
   if ooOO00oOOo000 == 'yt-dl' :
    oOOo0OOOOo0Oo = oOOo0OOOOo0Oo + "&mode=18"
   elif ooOO00oOOo000 == 'regex' :
    O0O0Oooo0o = oOOo0OOOOo0Oo . split ( '&regexs=' )
    if 14 - 14: i1iIi11iIIi1I . i11i . Ii1I / iII111i % ii1IiI1i - o00O0oo
    o0oOoO0O = OoOo000oOo0oo ( i1III ( '' , data = O0O0Oooo0o [ 1 ] ) )
    if 65 - 65: o0 / i1iIi11iIIi1I % I1Ii111
    iIiIIii ( O0O0Oooo0o [ 0 ] , ii1IiIIi1i , i1iIiIi1I , '' , '' , '' , '' , '' , None , o0oOoO0O , oOo0OoOOo0 )
    continue
   elif ooOO00oOOo000 == 'ftv' :
    oOOo0OOOOo0Oo = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( ii1IiIIi1i ) + '&url=' + oOOo0OOOOo0Oo + '&mode=125&ch_fanart=na'
  elif iI1 and '.ts' in oOOo0OOOOo0Oo :
   oOOo0OOOOo0Oo = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( oOOo0OOOOo0Oo ) + '&amp;streamtype=TSDOWNLOADER&name=' + urllib . quote ( ii1IiIIi1i )
  OOo00 ( oOOo0OOOOo0Oo , ii1IiIIi1i , i1iIiIi1I , '' , '' , '' , '' , '' , None , '' , oOo0OoOOo0 )
  if 37 - 37: i1IIi
def III1i1iI1 ( name , url , fanart ) :
 ooOOo00O00Oo = i1III ( url )
 o0ooo00o = ooOOo00O00Oo . find ( 'channel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 oOO00oO00O0OO = o0ooo00o ( 'item' )
 try :
  IiII1II11I = o0ooo00o ( 'fanart' ) [ 0 ] . string
  if IiII1II11I == None :
   raise
 except :
  IiII1II11I = fanart
 for oo0o0O0Oooooo in o0ooo00o ( 'subchannel' ) :
  name = oo0o0O0Oooooo ( 'name' ) [ 0 ] . string
  try :
   i1iIiIi1I = oo0o0O0Oooooo ( 'thumbnail' ) [ 0 ] . string
   if i1iIiIi1I == None :
    raise
  except :
   i1iIiIi1I = ''
  try :
   if not oo0o0O0Oooooo ( 'fanart' ) :
    if oO . getSetting ( 'use_thumb' ) == "true" :
     IiII1II11I = i1iIiIi1I
   else :
    IiII1II11I = oo0o0O0Oooooo ( 'fanart' ) [ 0 ] . string
   if IiII1II11I == None :
    raise
  except :
   pass
  try :
   II1I = oo0o0O0Oooooo ( 'info' ) [ 0 ] . string
   if II1I == None :
    raise
  except :
   II1I = ''
   if 96 - 96: o0
  try :
   III1I1Iii1iiI = oo0o0O0Oooooo ( 'genre' ) [ 0 ] . string
   if III1I1Iii1iiI == None :
    raise
  except :
   III1I1Iii1iiI = ''
   if 54 - 54: ooOoO0o
  try :
   II1I1I1Ii = oo0o0O0Oooooo ( 'date' ) [ 0 ] . string
   if II1I1I1Ii == None :
    raise
  except :
   II1I1I1Ii = ''
   if 84 - 84: ooOoO0o - ii1IiI1i / Ii1I
  try :
   credits = oo0o0O0Oooooo ( 'credits' ) [ 0 ] . string
   if credits == None :
    raise
  except :
   credits = ''
   if 13 - 13: I1Ii111 - I11i11Ii - o00O0oo
  try :
   OOOOoO00o0O = oo0o0O0Oooooo ( 'year' ) [ 0 ] . string
   if OOOOoO00o0O == None :
    raise
  except :
   OOOOoO00o0O = ''
   if 92 - 92: o00O0oo / o0 * i1iIi11iIIi1I . Ii1I % i11i
  try :
   I1I1I1IIi1III = oo0o0O0Oooooo ( 'director' ) [ 0 ] . string
   if I1I1I1IIi1III == None :
    raise
  except :
   I1I1I1IIi1III = ''
   if 71 - 71: ooOoO0o % i1IIi - i11i - I11i + I11i * o00O0oo
  try :
   II11IiiIII = oo0o0O0Oooooo ( 'duration' ) [ 0 ] . string
   if II11IiiIII == None :
    raise
  except :
   II11IiiIII = ''
   if 51 - 51: iIii1I11I1II1 / o0 + I11i - Ii1I + IiII
  try :
   o0OOOo = oo0o0O0Oooooo ( 'premiered' ) [ 0 ] . string
   if o0OOOo == None :
    raise
  except :
   o0OOOo = ''
   if 29 - 29: i1 % iIii1I11I1II1 . OoooooooOO % OoooooooOO % i11i / IiII
  try :
   ii1iiIiIII1ii = oo0o0O0Oooooo ( 'studio' ) [ 0 ] . string
   if ii1iiIiIII1ii == None :
    raise
  except :
   ii1iiIiIII1ii = ''
   if 70 - 70: i11iIiiIii % IiII
  try :
   oO0o0oooO0oO = oo0o0O0Oooooo ( 'rate' ) [ 0 ] . string
   if oO0o0oooO0oO == None :
    raise
  except :
   oO0o0oooO0oO = ''
   if 11 - 11: I1Ii111 % ii1IiI1i % iII111i / i11i % ooOoO0o - I11i11Ii
  try :
   IiIiII1 = oo0o0O0Oooooo ( 'originaltitle' ) [ 0 ] . string
   if IiIiII1 == None :
    raise
  except :
   IiIiII1 = ''
   if 96 - 96: ii1IiI1i / i11i . iII111i - IiII * Ii1I * OOooOOo
  try :
   Iii1iiIi1II = oo0o0O0Oooooo ( 'country' ) [ 0 ] . string
   if Iii1iiIi1II == None :
    raise
  except :
   Iii1iiIi1II = ''
   if 76 - 76: iII111i - i11i * I11i / OoooooooOO
  try :
   OO0O00oOo = oo0o0O0Oooooo ( 'rating' ) [ 0 ] . string
   if OO0O00oOo == None :
    raise
  except :
   OO0O00oOo = ''
   if 18 - 18: i1iIi11iIIi1I + iIii1I11I1II1 - i11i - oOooOoO0Oo0O
  try :
   ii1II = oo0o0O0Oooooo ( 'userrating' ) [ 0 ] . string
   if ii1II == None :
    raise
  except :
   ii1II = ''
   if 71 - 71: OoooooooOO
  try :
   iI1I = oo0o0O0Oooooo ( 'votes' ) [ 0 ] . string
   if iI1I == None :
    raise
  except :
   iI1I = ''
   if 33 - 33: ooOoO0o
  try :
   OooOoOo = oo0o0O0Oooooo ( 'aired' ) [ 0 ] . string
   if OooOoOo == None :
    raise
  except :
   OooOoOo = ''
   if 62 - 62: ii1IiI1i + iII111i + i1IIi / OoooooooOO
  try :
   I1IiiiiI ( name . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 3 , i1iIiIi1I , IiII1II11I , II1I , III1I1Iii1iiI , credits , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo )
  except :
   I1iI1iIi111i ( 'There was a problem adding directory - ' + name . encode ( 'utf-8' , 'ignore' ) )
 OO00O0oOO ( oOO00oO00O0OO , IiII1II11I )
 if 7 - 7: i1 + i1IIi . oOooOoO0Oo0O / I11i11Ii
 if 22 - 22: o00O0oo - o00O0oo % I11i . ooOoO0o + OOooOOo
def Oo00OOo00O ( name , url , fanart ) :
 ooOOo00O00Oo = i1III ( url )
 o0ooo00o = ooOOo00O00Oo . find ( 'subchannel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 oOO00oO00O0OO = o0ooo00o ( 'subitem' )
 OO00O0oOO ( oOO00oO00O0OO , fanart )
 if 81 - 81: I1Ii111 . i1 / ooOoO0o
 if 17 - 17: i11iIiiIii - I11i . I1Ii111 % iIii1I11I1II1 + Ii1I - o00O0oo
def O0oOooo0OOooO ( name , url , iconimage , fanart ) :
 o0O0O0o0o0o = [ ] ; IIIIIiI = [ ] ; Oo0000O0OOooO = 0
 O00OO = Oo0i1111IIiii1 ( url , 'sublink:' , '#' )
 for iIi in O00OO :
  OOOoO = iIi . replace ( 'sublink:' , '' ) . replace ( '#' , '' )
  if 57 - 57: i1iIi11iIIi1I / i1IIi . i1IIi
  if len ( OOOoO ) > 10 :
   Oo0000O0OOooO = Oo0000O0OOooO + 1 ; o0O0O0o0o0o . append ( name + ' Source [' + str ( Oo0000O0OOooO ) + ']' ) ; IIIIIiI . append ( OOOoO )
   if 74 - 74: iIii1I11I1II1 * I1Ii111 % o0
 if Oo0000O0OOooO == 1 :
  try :
   if 36 - 36: OoooooooOO - OOooOOo
   OOo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; OOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
   oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIIIIiI [ 0 ] , listitem = OOo )
   xbmc . Player ( ) . play ( o00o ( IIIIIiI [ 0 ] ) , OOo )
  except :
   pass
 else :
  I11iiI1i1 = xbmcgui . Dialog ( )
  if 47 - 47: i1 + IiII - OOooOOo % OoooooooOO
  o0O0 = I11iiI1i1 . select ( 'Select A Source' , o0O0O0o0o0o )
  if o0O0 >= 0 :
   ooOoOo = name
   IIIi1i = str ( IIIIIiI [ o0O0 ] )
   if 71 - 71: IiII % i1 / I11i / I11i11Ii
   try :
    OOo = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; OOo . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
    oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = IIIi1i , listitem = OOo )
    xbmc . Player ( ) . play ( o00o ( IIIi1i ) , OOo )
   except :
    pass
    if 66 - 66: I11i11Ii - i1 * I1Ii111 + o0 + i1 - iIii1I11I1II1
    if 17 - 17: OOooOOo
def iI1i11II1i ( url , headers = None ) :
 try :
  if headers is None :
   if 22 - 22: Ii1I + iIii1I11I1II1
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
   headers = { 'User-agent' : '\xbd\xbf\xef\xbd\xbf\xef\x38\x62\x55\xbd\xbf\xef\xbd\xbf\xef\xbd\xbf\xef\x19' }
  oOoOo0O0OOOoO = urllib2 . Request ( url , None , headers )
  oO00OOoO00 = urllib2 . urlopen ( oOoOo0O0OOOoO )
  IiI111111IIII = oO00OOoO00 . read ( )
  oO00OOoO00 . close ( )
  return IiI111111IIII
 except urllib2 . URLError , ooooooo00o :
  I1iI1iIi111i ( 'URL: ' + url )
  if hasattr ( ooooooo00o , 'code' ) :
   I1iI1iIi111i ( 'Falha com o código de erro - %s.' % ooooooo00o . code )
   if 24 - 24: o0 % i1IIi + IiII . i11iIiiIii . ii1IiI1i
   if 17 - 17: ii1IiI1i . i11i . o00O0oo / ii1IiI1i
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( ooooooo00o . code ) + ",10000," + oOO00Oo + ")" )
  elif hasattr ( ooooooo00o , 'reason' ) :
   I1iI1iIi111i ( 'Falha ao acessar um servidor.' )
   I1iI1iIi111i ( 'Razão: %s' % ooooooo00o . reason )
   if 57 - 57: Ii1I
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( ooooooo00o . reason ) + ",10000," + oOO00Oo + ")" )
   if 67 - 67: i1iIi11iIIi1I . o00O0oo
   if 87 - 87: OOooOOo % iII111i
def oo0OOOoOo ( ) :
 if 21 - 21: i1iIi11iIIi1I - O0 . OOooOOo + iII111i . iIii1I11I1II1 - o0
 I11IIIiIi11 = 'Name of channel show or movie'
 I11iiIi1i1 = ''
 OOii111IiiI1 = xbmc . Keyboard ( I11iiIi1i1 , I11IIIiIi11 )
 OOii111IiiI1 . doModal ( )
 if OOii111IiiI1 . isConfirmed ( ) :
  I11iiIi1i1 = OOii111IiiI1 . getText ( ) . replace ( '\n' , '' ) . strip ( )
  if len ( I11iiIi1i1 ) == 0 :
   xbmcgui . Dialog ( ) . ok ( 'RobinHood' , 'Nothing Entered' )
   return
   if 41 - 41: iII111i % ii1IiI1i
 I11iiIi1i1 = I11iiIi1i1 . lower ( )
 o0O0O0o0o0o = [ ]
 o0O0O0o0o0o . append ( plugin_name )
 i1iIiIi1Ii1I1IIIiiI = 0
 OO0O0ooOOO00 = 1
 IiIiiiiI1 = 0
 OO00OOoO0o = 0
 Iiiiiii1 = xbmcgui . DialogProgress ( )
 if 78 - 78: ii1IiI1i + Ii1I - O0
 Iiiiiii1 . create ( 'Searching Please wait' , ' ' )
 if 10 - 10: ooOoO0o % oOooOoO0Oo0O
 while OO0O0ooOOO00 <> IiIiiiiI1 :
  oo0OoOooo = o0O0O0o0o0o [ IiIiiiiI1 ] . strip ( )
  print 'read this one from file list (' + str ( IiIiiiiI1 ) + ')'
  IiIiiiiI1 = IiIiiiiI1 + 1
  if 95 - 95: I1Ii111 * ii1IiI1i % o00O0oo % iII111i - iII111i
  oOoooO0 = ''
  try :
   oOoooO0 = net . http_GET ( oo0OoOooo ) . content
   oOoooO0 = oOoooO0 . encode ( 'ascii' , 'ignore' ) . decode ( 'ascii' )
   if 68 - 68: o00O0oo / i1
  except :
   pass
   if 1 - 1: O0 / IiII % ooOoO0o . I11i11Ii + I1Ii111
  if len ( oOoooO0 ) < 10 :
   oOoooO0 = ''
   i1iIiIi1Ii1I1IIIiiI = i1iIiIi1Ii1I1IIIiiI + 1
   print '*** PASSED ****' + oo0OoOooo + '  ************* Total Passed Urls: ' + str ( i1iIiIi1Ii1I1IIIiiI )
   time . sleep ( .5 )
   if 27 - 27: ooOoO0o % OoooooooOO + I1Ii111 % i1IIi / OOooOOo / OoooooooOO
  III1IiIII1 = int ( ( IiIiiiiI1 / 300 ) * 100 )
  O00ooOo = '     Pages Read: ' + str ( IiIiiiiI1 ) + '        Matches Found: ' + str ( OO00OOoO0o )
  Iiiiiii1 . update ( III1IiIII1 , "" , O00ooOo , "" )
  if 80 - 80: i1 - I11i + OoooooooOO
  if Iiiiiii1 . iscanceled ( ) :
   return
   if 98 - 98: I11i + i1IIi . oOooOoO0Oo0O - i11i - i1
  if len ( oOoooO0 ) > 10 :
   iIIi1I1ii = Oo0i1111IIiii1 ( oOoooO0 , '<channel>' , '</channel>' )
   for iIi in iIIi1I1ii :
    OOOoO = Iiii ( iIi , '<externallink>' , '</externallink>' )
    if 44 - 44: o00O0oo . IiII . OoooooooOO
    if 50 - 50: i1 * iII111i % ii1IiI1i / I11i11Ii - O0 % IiII
    if len ( OOOoO ) > 5 :
     OO0O0ooOOO00 = OO0O0ooOOO00 + 1
     o0O0O0o0o0o . append ( OOOoO )
     if 48 - 48: oOooOoO0Oo0O + ii1IiI1i + i11i * i11iIiiIii
     if 13 - 13: OoooooooOO * OOooOOo - iII111i / I11i + Ii1I + I1Ii111
   iii1III1i = Oo0i1111IIiii1 ( oOoooO0 , '<item>' , '</item>' )
   for iIi in iii1III1i :
    OOOoO = Iiii ( iIi , '<link>' , '</link>' )
    I1iIi1iIiiIiI = Iiii ( iIi , '<title>' , '</title>' )
    iiiIi = '  ' + I1iIi1iIiiIiI . lower ( ) + '  '
    if 45 - 45: ii1IiI1i + i1iIi11iIIi1I * i11iIiiIii / I11i % Ii1I * O0
    if len ( OOOoO ) > 5 and iiiIi . find ( I11iiIi1i1 ) > 0 :
     OO00OOoO0o = OO00OOoO0o + 1
     o00o0 = ''
     i1iIiIi1I = Iiii ( iIi , '<thumbnail>' , '</thumbnail>' )
     o00o0 = Iiii ( iIi , '<fanart>' , '</fanart>' )
     if len ( o00o0 ) < 5 :
      o00o0 = oOO00Oo
     if OOOoO . find ( 'sublink' ) > 0 :
      I1IiiiiI ( I1iIi1iIiiIiI , OOOoO , 30 , i1iIiIi1I , o00o0 , '' , '' , '' , '' )
     else :
      iIiIIii ( str ( OOOoO ) , I1iIi1iIiiIiI , i1iIiIi1I , o00o0 , '' , '' , '' , True , None , '' , 1 )
      if 17 - 17: O0
      if 88 - 88: I11i11Ii . O0 % OoooooooOO / I11i
 Iiiiiii1 . close ( )
 xbmc . executebuiltin ( "Container.SetViewMode(50)" )
 if 89 - 89: i11i / OOooOOo
def IIo0OoO00 ( data , Searchkey ) :
 III = data . rstrip ( )
 IiiIii = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)' ) . findall ( III )
 oOo0OoOOo0 = len ( IiiIii )
 print 'total m3u links' , oOo0OoOOo0
 for O0Oo00 , ii1IiIIi1i , oOOo0OOOOo0Oo in IiiIii :
  if 'tvg-logo' in O0Oo00 :
   i1iIiIi1I = iiiI ( O0Oo00 , 'tvg-logo=[\'"](.*?)[\'"]' )
   if i1iIiIi1I :
    if i1iIiIi1I . startswith ( 'http' ) :
     i1iIiIi1I = i1iIiIi1I
     if 18 - 18: OOooOOo - i1 - oOooOoO0Oo0O - oOooOoO0Oo0O
    elif not oO . getSetting ( 'logo-folderPath' ) == "" :
     OoO = oO . getSetting ( 'logo-folderPath' )
     i1iIiIi1I = OoO + i1iIiIi1I
     if 54 - 54: I11i11Ii + oOooOoO0Oo0O / IiII . oOooOoO0Oo0O * o0
    else :
     i1iIiIi1I = i1iIiIi1I
     if 1 - 1: o0 * i1iIi11iIIi1I . i1IIi / I11i11Ii . ii1IiI1i + I11i11Ii
     if 17 - 17: I11i11Ii + i1iIi11iIIi1I / iII111i / IiII * I11i
  else :
   i1iIiIi1I = ''
  if 'type' in O0Oo00 :
   ooOO00oOOo000 = iiiI ( O0Oo00 , 'type=[\'"](.*?)[\'"]' )
   if ooOO00oOOo000 == 'yt-dl' :
    oOOo0OOOOo0Oo = oOOo0OOOOo0Oo + "&mode=18"
   elif ooOO00oOOo000 == 'regex' :
    O0O0Oooo0o = oOOo0OOOOo0Oo . split ( '&regexs=' )
    if 29 - 29: i1iIi11iIIi1I % OoooooooOO * OOooOOo / i11i - OOooOOo
    o0oOoO0O = OoOo000oOo0oo ( i1III ( '' , data = O0O0Oooo0o [ 1 ] ) )
    if 19 - 19: i11iIiiIii
    iIiIIii ( O0O0Oooo0o [ 0 ] , ii1IiIIi1i , i1iIiIi1I , '' , '' , '' , '' , '' , None , o0oOoO0O , oOo0OoOOo0 )
    continue
  iIiIIii ( oOOo0OOOOo0Oo , ii1IiIIi1i , i1iIiIi1I , '' , '' , '' , '' , '' , None , '' , oOo0OoOOo0 )
  if 54 - 54: i11i . Ii1I
def oOO ( text , pattern ) :
 II1i11i1iIi11 = ""
 try :
  oo0O0oO0O0O = re . findall ( pattern , text , flags = re . DOTALL )
  II1i11i1iIi11 = oo0O0oO0O0O [ 0 ]
 except :
  II1i11i1iIi11 = ""
  if 69 - 69: OOooOOo / i11iIiiIii
 return II1i11i1iIi11
 if 94 - 94: OOooOOo / I1Ii111 / i1IIi * iIii1I11I1II1
def Oo0i1111IIiii1 ( text , start_with , end_with ) :
 ooo0 = re . findall ( "(?i)(" + start_with + "[\S\s]+?" + end_with + ")" , text )
 return ooo0
 if 1 - 1: iII111i
def Iiii ( text , from_string , to_string , excluding = True ) :
 if excluding :
  try : ooo0 = re . search ( "(?i)" + from_string + "([\S\s]+?)" + to_string , text ) . group ( 1 )
  except : ooo0 = ''
 else :
  try : ooo0 = re . search ( "(?i)(" + from_string + "[\S\s]+?" + to_string + ")" , text ) . group ( 1 )
  except : ooo0 = ''
 return ooo0
 if 48 - 48: O0 + O0 . ooOoO0o - o00O0oo
def OO00O0oOO ( items , fanart , dontLink = False ) :
 oOo0OoOOo0 = len ( items )
 I1iI1iIi111i ( 'Total Items: %s' % oOo0OoOOo0 )
 o00oo0000 = oO . getSetting ( 'add_playlist' )
 iIi1IIi1ii = oO . getSetting ( 'ask_playlist_items' )
 I11Ii = oO . getSetting ( 'use_thumb' )
 iIiII = oO . getSetting ( 'parentalblocked' )
 iIiII = ''
 iIiII = iIiII == "true"
 for i1i1IIIIIIIi in items :
  oo0o0oOo = False
  OO0oOOo0o = False
  if 50 - 50: IiII . ii1IiI1i . i1iIi11iIIi1I * Ii1I + i11i % i11iIiiIii
  i1i1IiIiIi1Ii = 'false'
  try :
   i1i1IiIiIi1Ii = i1i1IIIIIIIi ( 'parentalblock' ) [ 0 ] . string
  except :
   I1iI1iIi111i ( 'parentalblock Error' )
   i1i1IiIiIi1Ii = ''
  if i1i1IiIiIi1Ii == 'true' and iIiII : continue
  if 64 - 64: I11i + OoooooooOO * OoooooooOO
  try :
   I1iIi1iIiiIiI = i1i1IIIIIIIi ( 'title' ) [ 0 ] . string
   if I1iIi1iIiiIiI is None :
    I1iIi1iIiiIiI = 'unknown?'
  except :
   I1iI1iIi111i ( 'Name Error' )
   I1iIi1iIiiIiI = ''
   if 41 - 41: o00O0oo . I11i11Ii + oOooOoO0Oo0O
   if 100 - 100: iII111i + i1iIi11iIIi1I
  try :
   if i1i1IIIIIIIi ( 'epg' ) :
    if i1i1IIIIIIIi . epg_url :
     I1iI1iIi111i ( 'Get EPG Regex' )
     Oo00o0OO = i1i1IIIIIIIi . epg_url . string
     OO0ooo0o0 = i1i1IIIIIIIi . epg_regex . string
     oO0ooOoO = ooO0000o00O ( Oo00o0OO , OO0ooo0o0 )
     if oO0ooOoO :
      I1iIi1iIiiIiI += ' - ' + oO0ooOoO
    elif i1i1IIIIIIIi ( 'epg' ) [ 0 ] . string > 1 :
     I1iIi1iIiiIiI += O0Ooo ( i1i1IIIIIIIi ( 'epg' ) [ 0 ] . string )
   else :
    pass
  except :
   I1iI1iIi111i ( 'EPG Error' )
  try :
   O0O0Oooo0o = [ ]
   if len ( i1i1IIIIIIIi ( 'link' ) ) > 0 :
    if 78 - 78: i1iIi11iIIi1I % I1Ii111 * i1IIi
    if 66 - 66: iII111i . oOooOoO0Oo0O + i1 . iIii1I11I1II1
    for ii in i1i1IIIIIIIi ( 'link' ) :
     if not ii . string == None :
      O0O0Oooo0o . append ( ii . string )
      if 51 - 51: Ii1I . I11i11Ii
   elif len ( i1i1IIIIIIIi ( 'sportsdevil' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'sportsdevil' ) :
     if not ii . string == None :
      IiiIiiIi = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + ii . string
      i1iiIIIi = i1i1IIIIIIIi ( 'referer' ) [ 0 ] . string
      if i1iiIIIi :
       if 62 - 62: O0 / oOooOoO0Oo0O % O0 * i1iIi11iIIi1I % oOooOoO0Oo0O
       IiiIiiIi = IiiIiiIi + '%26referer=' + i1iiIIIi
      O0O0Oooo0o . append ( IiiIiiIi )
   elif len ( i1i1IIIIIIIi ( 'p2p' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'p2p' ) :
     if not ii . string == None :
      if 'sop://' in ii . string :
       IiOOoo0oO00oo00 = 'plugin://plugin.video.p2p-streams/?mode=2url=' + ii . string + '&' + 'name=' + I1iIi1iIiiIiI
       O0O0Oooo0o . append ( IiOOoo0oO00oo00 )
      else :
       O0ii = 'plugin://plugin.video.p2p-streams/?mode=1&url=' + ii . string + '&' + 'name=' + I1iIi1iIiiIiI
       O0O0Oooo0o . append ( O0ii )
   elif len ( i1i1IIIIIIIi ( 'vaughn' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'vaughn' ) :
     if not ii . string == None :
      ooO0o0oO = 'plugin://plugin.stream.vaughnlive.tv/?mode=PlayLiveStream&amp;channel=' + ii . string
      O0O0Oooo0o . append ( ooO0o0oO )
   elif len ( i1i1IIIIIIIi ( 'ilive' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'ilive' ) :
     if not ii . string == None :
      if not 'http' in ii . string :
       oo0O = 'plugin://plugin.video.tbh.ilive/?url=http://www.streamlive.to/view/' + ii . string + '&amp;link=99&amp;mode=iLivePlay'
      else :
       oo0O = 'plugin://plugin.video.tbh.ilive/?url=' + ii . string + '&amp;link=99&amp;mode=iLivePlay'
   elif len ( i1i1IIIIIIIi ( 'yt-dl' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'yt-dl' ) :
     if not ii . string == None :
      III1i1IiI1i = ii . string + '&mode=18'
      O0O0Oooo0o . append ( III1i1IiI1i )
   elif len ( i1i1IIIIIIIi ( 'dm' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'dm' ) :
     if not ii . string == None :
      IiII1iiI = "plugin://plugin.video.dailymotion_com/?mode=playVideo&url=" + ii . string
      O0O0Oooo0o . append ( IiII1iiI )
   elif len ( i1i1IIIIIIIi ( 'dmlive' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'dmlive' ) :
     if not ii . string == None :
      IiII1iiI = "plugin://plugin.video.dailymotion_com/?mode=playLiveVideo&url=" + ii . string
      O0O0Oooo0o . append ( IiII1iiI )
   elif len ( i1i1IIIIIIIi ( 'utube' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'utube' ) :
     if not ii . string == None :
      if ' ' in ii . string :
       iII = 'plugin://plugin.video.youtube/search/?q=' + urllib . quote_plus ( ii . string )
       OO0oOOo0o = iII
      elif len ( ii . string ) == 11 :
       iII = 'plugin://plugin.video.youtube/play/?video_id=' + ii . string
      elif ( ii . string . startswith ( 'PL' ) and not '&order=' in ii . string ) or ii . string . startswith ( 'UU' ) :
       iII = 'plugin://plugin.video.youtube/play/?&order=default&playlist_id=' + ii . string
      elif ii . string . startswith ( 'PL' ) or ii . string . startswith ( 'UU' ) :
       iII = 'plugin://plugin.video.youtube/play/?playlist_id=' + ii . string
      elif ii . string . startswith ( 'UC' ) and len ( ii . string ) > 12 :
       iII = 'plugin://plugin.video.youtube/channel/' + ii . string + '/'
       OO0oOOo0o = iII
      elif not ii . string . startswith ( 'UC' ) and not ( ii . string . startswith ( 'PL' ) ) :
       iII = 'plugin://plugin.video.youtube/user/' + ii . string + '/'
       OO0oOOo0o = iII
     O0O0Oooo0o . append ( iII )
     if 63 - 63: i1 * IiII
   elif len ( i1i1IIIIIIIi ( 'gdrive' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'gdrive' ) :
     if not ii . string == None :
      if len ( ii . string ) == 33 :
       O0oOoo0OoO0O = 'plugin://plugin.video.gdrive?mode=streamURL&amp;url=https://drive.google.com/open?id=' + ii . string
       if 63 - 63: OoooooooOO / o00O0oo
     O0O0Oooo0o . append ( O0oOoo0OoO0O )
     if 91 - 91: i1IIi - iIii1I11I1II1
   elif len ( i1i1IIIIIIIi ( 'imdb' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'imdb' ) :
     if not ii . string == None :
      if oO . getSetting ( 'genesisorpulsar' ) == '0' :
       Oo0Oo00o00oO = 'plugin://plugin.video.genesis/?action=play&imdb=' + ii . string
      else :
       Oo0Oo00o00oO = 'plugin://plugin.video.pulsar/movie/tt' + ii . string + '/play'
      O0O0Oooo0o . append ( Oo0Oo00o00oO )
   elif len ( i1i1IIIIIIIi ( 'f4m' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'f4m' ) :
     if not ii . string == None :
      if '.f4m' in ii . string :
       o0000 = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( ii . string )
      elif '.m3u8' in ii . string :
       o0000 = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( ii . string ) + '&amp;streamtype=HLS'
       if 42 - 42: ooOoO0o + ooOoO0o * i11i
      else :
       o0000 = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( ii . string ) + '&amp;streamtype=SIMPLE'
     O0O0Oooo0o . append ( o0000 )
   elif len ( i1i1IIIIIIIi ( 'ftv' ) ) > 0 :
    for ii in i1i1IIIIIIIi ( 'ftv' ) :
     if not ii . string == None :
      o0Oo = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( I1iIi1iIiiIiI ) + '&url=' + ii . string + '&mode=125&ch_fanart=na'
     O0O0Oooo0o . append ( o0Oo )
   elif len ( i1i1IIIIIIIi ( 'urlsolve' ) ) > 0 :
    if 57 - 57: I11i / I11i11Ii
    for ii in i1i1IIIIIIIi ( 'urlsolve' ) :
     if not ii . string == None :
      oO0O0Ooo = ii . string + '&mode=19'
      O0O0Oooo0o . append ( oO0O0Ooo )
   if len ( O0O0Oooo0o ) < 1 :
    raise
  except :
   I1iI1iIi111i ( 'Error <link> element, Passing:' + I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) )
   continue
  try :
   oo0o0oOo = i1i1IIIIIIIi ( 'externallink' ) [ 0 ] . string
  except : pass
  if 4 - 4: i11i . Ii1I + iII111i * ooOoO0o . o00O0oo
  if oo0o0oOo :
   oOoOo = [ oo0o0oOo ]
   oo0o0oOo = True
  else :
   oo0o0oOo = False
  try :
   OO0oOOo0o = i1i1IIIIIIIi ( 'jsonrpc' ) [ 0 ] . string
  except : pass
  if OO0oOOo0o :
   if 74 - 74: OOooOOo / ii1IiI1i % i1
   oOoOo = [ OO0oOOo0o ]
   if 88 - 88: o0 - i11iIiiIii % i1 * Ii1I + ii1IiI1i
   OO0oOOo0o = True
  else :
   OO0oOOo0o = False
  try :
   i1iIiIi1I = i1i1IIIIIIIi ( 'thumbnail' ) [ 0 ] . string
   if i1iIiIi1I == None :
    raise
  except :
   i1iIiIi1I = ''
  try :
   if not i1i1IIIIIIIi ( 'fanart' ) :
    if oO . getSetting ( 'use_thumb' ) == "true" :
     IiII1II11I = i1iIiIi1I
    else :
     IiII1II11I = fanart
   else :
    IiII1II11I = i1i1IIIIIIIi ( 'fanart' ) [ 0 ] . string
   if IiII1II11I == None :
    raise
  except :
   IiII1II11I = fanart
  try :
   II1I = i1i1IIIIIIIi ( 'info' ) [ 0 ] . string
   if II1I == None :
    raise
  except :
   II1I = ''
   if 52 - 52: i11i . oOooOoO0Oo0O + o0 % i1iIi11iIIi1I
  try :
   III1I1Iii1iiI = i1i1IIIIIIIi ( 'genre' ) [ 0 ] . string
   if III1I1Iii1iiI == None :
    raise
  except :
   III1I1Iii1iiI = ''
   if 62 - 62: i1
  try :
   II1I1I1Ii = i1i1IIIIIIIi ( 'date' ) [ 0 ] . string
   if II1I1I1Ii == None :
    raise
  except :
   II1I1I1Ii = ''
   if 15 - 15: Ii1I + iII111i . I11i * i1iIi11iIIi1I . o0
  try :
   OOOOoO00o0O = i1i1IIIIIIIi ( 'year' ) [ 0 ] . string
   if II1I1I1Ii == None :
    raise
  except :
   OOOOoO00o0O = ''
   if 18 - 18: i1IIi % i11i + ooOoO0o % iII111i
  try :
   I1I1I1IIi1III = i1i1IIIIIIIi ( 'director' ) [ 0 ] . string
   if I1I1I1IIi1III == None :
    raise
  except :
   I1I1I1IIi1III = ''
   if 72 - 72: iIii1I11I1II1
  try :
   II11IiiIII = i1i1IIIIIIIi ( 'duration' ) [ 0 ] . string
   if II11IiiIII == None :
    raise
  except :
   II11IiiIII = ''
   if 45 - 45: I11i11Ii - i1 % ooOoO0o
  try :
   o0OOOo = i1i1IIIIIIIi ( 'premiered' ) [ 0 ] . string
   if o0OOOo == None :
    raise
  except :
   o0OOOo = ''
   if 38 - 38: ooOoO0o % I11i - OoooooooOO
  try :
   ii1iiIiIII1ii = i1i1IIIIIIIi ( 'studio' ) [ 0 ] . string
   if ii1iiIiIII1ii == None :
    raise
  except :
   ii1iiIiIII1ii = ''
   if 87 - 87: i1iIi11iIIi1I % oOooOoO0Oo0O
  try :
   oO0o0oooO0oO = i1i1IIIIIIIi ( 'rate' ) [ 0 ] . string
   if oO0o0oooO0oO == None :
    raise
  except :
   oO0o0oooO0oO = ''
   if 77 - 77: iIii1I11I1II1 - i1IIi . OOooOOo
  try :
   IiIiII1 = channel ( 'originaltitle' ) [ 0 ] . string
   if IiIiII1 == None :
    raise
  except :
   IiIiII1 = ''
   if 26 - 26: i1 * I1Ii111 . i1IIi
  try :
   Iii1iiIi1II = channel ( 'country' ) [ 0 ] . string
   if Iii1iiIi1II == None :
    raise
  except :
   Iii1iiIi1II = ''
   if 59 - 59: O0 + i1IIi - i1
  try :
   OO0O00oOo = channel ( 'rating' ) [ 0 ] . string
   if OO0O00oOo == None :
    raise
  except :
   OO0O00oOo = ''
   if 62 - 62: i11iIiiIii % I11i . I1Ii111 . I11i
  try :
   ii1II = channel ( 'userrating' ) [ 0 ] . string
   if ii1II == None :
    raise
  except :
   ii1II = ''
   if 84 - 84: i11iIiiIii * i1iIi11iIIi1I
  try :
   iI1I = channel ( 'votes' ) [ 0 ] . string
   if iI1I == None :
    raise
  except :
   iI1I = ''
   if 18 - 18: I11i - iII111i - o0 / ooOoO0o - O0
  try :
   OooOoOo = channel ( 'aired' ) [ 0 ] . string
   if OooOoOo == None :
    raise
  except :
   OooOoOo = ''
   if 30 - 30: O0 + ii1IiI1i + i11i
  o0oOoO0O = None
  if i1i1IIIIIIIi ( 'regex' ) :
   try :
    III1I = i1i1IIIIIIIi ( 'regex' )
    o0oOoO0O = OoOo000oOo0oo ( III1I )
   except :
    pass
  try :
   if 11 - 11: o00O0oo - I11i + o00O0oo * OOooOOo / oOooOoO0Oo0O
   if len ( O0O0Oooo0o ) > 1 :
    OoOOOO = 0
    I1iiIi111I = [ ]
    for ii in O0O0Oooo0o :
     if o00oo0000 == "false" :
      OoOOOO += 1
      iIiIIii ( ii , '%s) %s' % ( OoOOOO , I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) ) , i1iIiIi1I , IiII1II11I , II1I , III1I1Iii1iiI , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , True , I1iiIi111I , o0oOoO0O , oOo0OoOOo0 )
     elif o00oo0000 == "true" and iIi1IIi1ii == 'true' :
      if o0oOoO0O :
       I1iiIi111I . append ( ii + '&regexs=' + o0oOoO0O )
      elif any ( x in ii for x in o0oo0oOo ) and ii . startswith ( 'http' ) :
       I1iiIi111I . append ( ii + '&mode=19' )
      else :
       I1iiIi111I . append ( ii )
     else :
      I1iiIi111I . append ( ii )
    if len ( I1iiIi111I ) > 1 :
     iIiIIii ( '' , I1iIi1iIiiIiI , i1iIiIi1I , IiII1II11I , II1I , III1I1Iii1iiI , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , True , I1iiIi111I , o0oOoO0O , oOo0OoOOo0 )
   else :
    if 34 - 34: i11iIiiIii - i11i / oOooOoO0Oo0O % i1
    if dontLink :
     return I1iIi1iIiiIiI , O0O0Oooo0o [ 0 ] , o0oOoO0O
    if oo0o0oOo :
     if not o0oOoO0O == None :
      I1IiiiiI ( I1iIi1iIiiIiI . encode ( 'utf-8' ) , oOoOo [ 0 ] . encode ( 'utf-8' ) , 1 , i1iIiIi1I , fanart , II1I , III1I1Iii1iiI , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , None , '!!update' , o0oOoO0O , O0O0Oooo0o [ 0 ] . encode ( 'utf-8' ) )
      if 33 - 33: I11i
     else :
      I1IiiiiI ( I1iIi1iIiiIiI . encode ( 'utf-8' ) , oOoOo [ 0 ] . encode ( 'utf-8' ) , 1 , i1iIiIi1I , fanart , II1I , III1I1Iii1iiI , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , None , 'source' , None , None )
      if 35 - 35: i11iIiiIii - oOooOoO0Oo0O / I11i + iII111i * OOooOOo
    elif OO0oOOo0o :
     I1IiiiiI ( I1iIi1iIiiIiI . encode ( 'utf-8' ) , oOoOo [ 0 ] , 53 , i1iIiIi1I , fanart , II1I , III1I1Iii1iiI , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , None , 'source' )
     if 49 - 49: i1 * iII111i + Ii1I + IiII
    else :
     if 30 - 30: i1 / I11i / I1Ii111 % o00O0oo + i11i
     iIiIIii ( O0O0Oooo0o [ 0 ] , I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) , i1iIiIi1I , IiII1II11I , II1I , III1I1Iii1iiI , II1I1I1Ii , OOOOoO00o0O , I1I1I1IIi1III , II11IiiIII , o0OOOo , ii1iiIiIII1ii , oO0o0oooO0oO , IiIiII1 , Iii1iiIi1II , OO0O00oOo , ii1II , iI1I , OooOoOo , True , None , o0oOoO0O , oOo0OoOOo0 )
     if 4 - 4: IiII - I11i11Ii - I1Ii111 - Ii1I % i11iIiiIii / i1iIi11iIIi1I
  except :
   I1iI1iIi111i ( 'There was a problem adding item - ' + I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) )
   if 50 - 50: o00O0oo + i1IIi
def OoOo000oOo0oo ( reg_item ) :
 try :
  o0oOoO0O = { }
  for ii in reg_item :
   o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] = { }
   o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'name' ] = ii ( 'name' ) [ 0 ] . string
   if 31 - 31: iII111i
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'expres' ] = ii ( 'expres' ) [ 0 ] . string
    if not o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'expres' ] :
     o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'expres' ] = ''
   except :
    I1iI1iIi111i ( "Regex: -- No Referer --" )
   o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'page' ] = ii ( 'page' ) [ 0 ] . string
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'referer' ] = ii ( 'referer' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No Referer --" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'connection' ] = ii ( 'connection' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No connection --" )
    if 78 - 78: i11iIiiIii + i1 + ooOoO0o / i1 % iIii1I11I1II1 % I1Ii111
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'notplayable' ] = ii ( 'notplayable' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No notplayable --" )
    if 83 - 83: iIii1I11I1II1 % o0 % i1 % ooOoO0o . ii1IiI1i % O0
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'noredirect' ] = ii ( 'noredirect' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No noredirect --" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'origin' ] = ii ( 'origin' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No origin --" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'accept' ] = ii ( 'accept' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No accept --" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'includeheaders' ] = ii ( 'includeheaders' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No includeheaders --" )
    if 47 - 47: i1
    if 66 - 66: oOooOoO0Oo0O - I1Ii111
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'listrepeat' ] = ii ( 'listrepeat' ) [ 0 ] . string
    if 33 - 33: oOooOoO0Oo0O / i1iIi11iIIi1I
   except :
    I1iI1iIi111i ( "Regex: -- No listrepeat --" )
    if 12 - 12: i11i
    if 2 - 2: i1IIi - oOooOoO0Oo0O + Ii1I . i11i
    if 25 - 25: OOooOOo
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'proxy' ] = ii ( 'proxy' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No proxy --" )
    if 34 - 34: o0 . iIii1I11I1II1 % O0
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'x-req' ] = ii ( 'x-req' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No x-req --" )
    if 43 - 43: ii1IiI1i - IiII
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'x-addr' ] = ii ( 'x-addr' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No x-addr --" )
    if 70 - 70: IiII / I11i % o00O0oo - iII111i
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'x-forward' ] = ii ( 'x-forward' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No x-forward --" )
    if 47 - 47: IiII
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'agent' ] = ii ( 'agent' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- No User Agent --" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'post' ] = ii ( 'post' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a post" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'rawpost' ] = ii ( 'rawpost' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a rawpost" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'htmlunescape' ] = ii ( 'htmlunescape' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a htmlunescape" )
    if 92 - 92: I11i + o0 % i1IIi
    if 23 - 23: ooOoO0o - I11i + iII111i - o0 * o0 . I11i11Ii
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'readcookieonly' ] = ii ( 'readcookieonly' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a readCookieOnly" )
    if 47 - 47: OOooOOo % iIii1I11I1II1
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = ii ( 'cookiejar' ) [ 0 ] . string
    if not o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] :
     o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = ''
   except :
    I1iI1iIi111i ( "Regex: -- Not a cookieJar" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'setcookie' ] = ii ( 'setcookie' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a setcookie" )
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'appendcookie' ] = ii ( 'appendcookie' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- Not a appendcookie" )
    if 11 - 11: oOooOoO0Oo0O % iII111i - i1iIi11iIIi1I - OOooOOo + i1
   try :
    o0oOoO0O [ ii ( 'name' ) [ 0 ] . string ] [ 'ignorecache' ] = ii ( 'ignorecache' ) [ 0 ] . string
   except :
    I1iI1iIi111i ( "Regex: -- no ignorecache" )
    if 98 - 98: IiII + iII111i - i1iIi11iIIi1I
    if 79 - 79: I11i / ooOoO0o . o0 - ii1IiI1i
    if 47 - 47: OoooooooOO % O0 * IiII . iII111i
    if 38 - 38: O0 - I1Ii111 % ooOoO0o
    if 64 - 64: iIii1I11I1II1
  o0oOoO0O = urllib . quote ( repr ( o0oOoO0O ) )
  return o0oOoO0O
  if 15 - 15: ii1IiI1i + I11i / ii1IiI1i / ooOoO0o
 except :
  o0oOoO0O = None
  I1iI1iIi111i ( 'regex Error: ' + I1iIi1iIiiIiI . encode ( 'utf-8' , 'ignore' ) )
  if 31 - 31: o00O0oo + O0 + o00O0oo . iIii1I11I1II1 + I11i11Ii / i1
  if 6 - 6: I11i11Ii % I1Ii111 * Ii1I / oOooOoO0Oo0O + I11i11Ii
def IIiI11i11 ( url ) :
 try :
  for ii in range ( 1 , 51 ) :
   II1i11i1iIi11 = i1iiIII1IIiIIII ( url )
   if "EXT-X-STREAM-INF" in II1i11i1iIi11 : return url
   if not "EXTM3U" in II1i11i1iIi11 : return
   xbmc . sleep ( 2000 )
  return
 except :
  return
  if 19 - 19: IiII - i1 / i1 + I11i11Ii
def OoO0o0000O ( regexs , url , cookieJar = None , forCookieJarOnly = False , recursiveCall = False , cachedPages = { } , rawPost = False , cookie_jar_file = None ) :
 if not recursiveCall :
  regexs = eval ( urllib . unquote ( regexs ) )
  if 8 - 8: o0 . o00O0oo % OOooOOo . oOooOoO0Oo0O % oOooOoO0Oo0O . iII111i
  if 47 - 47: Ii1I + o00O0oo + i11i % i11iIiiIii
 OOoOoo00Oo = re . compile ( '\$doregex\[([^\]]*)\]' ) . findall ( url )
 if 9 - 9: i11i * i11i . i11iIiiIii * iIii1I11I1II1
 II1 = True
 for I11Iii1 in OOoOoo00Oo :
  if I11Iii1 in regexs :
   if 16 - 16: iII111i * i1iIi11iIIi1I / OOooOOo
   II1iiI = regexs [ I11Iii1 ]
   if 31 - 31: i1 % Ii1I + iIii1I11I1II1 + i11iIiiIii * ooOoO0o
   I1i1I1I11IiiI = False
   if 'cookiejar' in II1iiI :
    if 40 - 40: Ii1I % OoooooooOO - I11i + i1 / I11i
    I1i1I1I11IiiI = II1iiI [ 'cookiejar' ]
    if '$doregex' in I1i1I1I11IiiI :
     cookieJar = OoO0o0000O ( regexs , II1iiI [ 'cookiejar' ] , cookieJar , True , True , cachedPages )
     I1i1I1I11IiiI = True
    else :
     I1i1I1I11IiiI = True
     if 84 - 84: O0
   if I1i1I1I11IiiI :
    if cookieJar == None :
     if 11 - 11: i11i / i11iIiiIii / O0
     cookie_jar_file = None
     if 'open[' in II1iiI [ 'cookiejar' ] :
      cookie_jar_file = II1iiI [ 'cookiejar' ] . split ( 'open[' ) [ 1 ] . split ( ']' ) [ 0 ]
      if 94 - 94: o00O0oo * Ii1I - I1Ii111 . iIii1I11I1II1
      if 66 - 66: o00O0oo - I11i * o0 / OOooOOo * i11i * i1iIi11iIIi1I
     cookieJar = Ooo0O ( cookie_jar_file )
     if 34 - 34: o00O0oo
     if cookie_jar_file :
      i1IiIi1 ( cookieJar , cookie_jar_file )
      if 22 - 22: Ii1I * O0 . i11i - i1iIi11iIIi1I
      if 90 - 90: OOooOOo
      if 94 - 94: Ii1I / ii1IiI1i * ooOoO0o - o0
    elif 'save[' in II1iiI [ 'cookiejar' ] :
     cookie_jar_file = II1iiI [ 'cookiejar' ] . split ( 'save[' ) [ 1 ] . split ( ']' ) [ 0 ]
     I1Ii11II1I1 = os . path . join ( O0oOoOOOoOO , cookie_jar_file )
     if 41 - 41: O0 * o00O0oo - o0 . iII111i
     i1IiIi1 ( cookieJar , cookie_jar_file )
   if II1iiI [ 'page' ] and '$doregex' in II1iiI [ 'page' ] :
    oOIIIiI1ii1IIi = OoO0o0000O ( regexs , II1iiI [ 'page' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if len ( oOIIIiI1ii1IIi ) == 0 :
     oOIIIiI1ii1IIi = 'http://regexfailed'
    II1iiI [ 'page' ] = oOIIIiI1ii1IIi
    if 55 - 55: IiII - i1iIi11iIIi1I
   if 'setcookie' in II1iiI and II1iiI [ 'setcookie' ] and '$doregex' in II1iiI [ 'setcookie' ] :
    II1iiI [ 'setcookie' ] = OoO0o0000O ( regexs , II1iiI [ 'setcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if 'appendcookie' in II1iiI and II1iiI [ 'appendcookie' ] and '$doregex' in II1iiI [ 'appendcookie' ] :
    II1iiI [ 'appendcookie' ] = OoO0o0000O ( regexs , II1iiI [ 'appendcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 100 - 100: O0
    if 79 - 79: iIii1I11I1II1
   if 'post' in II1iiI and '$doregex' in II1iiI [ 'post' ] :
    II1iiI [ 'post' ] = OoO0o0000O ( regexs , II1iiI [ 'post' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 81 - 81: I11i + iIii1I11I1II1 * ooOoO0o - iIii1I11I1II1 . I11i
    if 48 - 48: Ii1I . OoooooooOO . oOooOoO0Oo0O . o0 % ii1IiI1i / IiII
   if 'rawpost' in II1iiI and '$doregex' in II1iiI [ 'rawpost' ] :
    II1iiI [ 'rawpost' ] = OoO0o0000O ( regexs , II1iiI [ 'rawpost' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages , rawPost = True )
    if 11 - 11: i1IIi % i1iIi11iIIi1I % IiII
    if 99 - 99: o00O0oo / iIii1I11I1II1 - iII111i * ii1IiI1i % oOooOoO0Oo0O
   if 'rawpost' in II1iiI and '$epoctime$' in II1iiI [ 'rawpost' ] :
    II1iiI [ 'rawpost' ] = II1iiI [ 'rawpost' ] . replace ( '$epoctime$' , i1II1i ( ) )
    if 10 - 10: iII111i - o0 . OoooooooOO . I11i . i1iIi11iIIi1I * IiII
   if 'rawpost' in II1iiI and '$epoctime2$' in II1iiI [ 'rawpost' ] :
    II1iiI [ 'rawpost' ] = II1iiI [ 'rawpost' ] . replace ( '$epoctime2$' , OOOO ( ) )
    if 94 - 94: OoooooooOO . o00O0oo + iII111i - oOooOoO0Oo0O
    if 1 - 1: i1 . O0
   I1i1Iiiii = ''
   if II1iiI [ 'page' ] and II1iiI [ 'page' ] in cachedPages and not 'ignorecache' in II1iiI and forCookieJarOnly == False :
    if 37 - 37: i1IIi - I11i % OoooooooOO / I11i % o00O0oo
    I1i1Iiiii = cachedPages [ II1iiI [ 'page' ] ]
   else :
    if II1iiI [ 'page' ] and not II1iiI [ 'page' ] == '' and II1iiI [ 'page' ] . startswith ( 'http' ) :
     if '$epoctime$' in II1iiI [ 'page' ] :
      II1iiI [ 'page' ] = II1iiI [ 'page' ] . replace ( '$epoctime$' , i1II1i ( ) )
     if '$epoctime2$' in II1iiI [ 'page' ] :
      II1iiI [ 'page' ] = II1iiI [ 'page' ] . replace ( '$epoctime2$' , OOOO ( ) )
      if 48 - 48: i11iIiiIii % OOooOOo
      if 29 - 29: IiII + i11iIiiIii % Ii1I
     oOo00Ooo0o0 = II1iiI [ 'page' ] . split ( '|' )
     i1IiII1i1I = oOo00Ooo0o0 [ 0 ]
     iI1ii1ii1I = None
     if len ( oOo00Ooo0o0 ) > 1 :
      iI1ii1ii1I = oOo00Ooo0o0 [ 1 ]
      if 18 - 18: OOooOOo * OOooOOo % OOooOOo
      if 17 - 17: O0 * o0 * ii1IiI1i * i11i * Ii1I % i1IIi
      if 33 - 33: ii1IiI1i * ii1IiI1i . o00O0oo . i11iIiiIii
      if 48 - 48: i1 . iII111i + o0 % ii1IiI1i / i11iIiiIii
      if 74 - 74: i11i . O0 - oOooOoO0Oo0O + I1Ii111 % i11iIiiIii % o0
      if 78 - 78: iII111i + o0 + I1Ii111 - I1Ii111 . i11iIiiIii / i1iIi11iIIi1I
      if 27 - 27: iII111i - O0 % Ii1I * ooOoO0o . I1Ii111 % iIii1I11I1II1
      if 37 - 37: OoooooooOO + O0 - i1IIi % o00O0oo
      if 24 - 24: o0
      if 94 - 94: i1IIi * i1IIi % i11i + I11i
     iIIi11 = urllib2 . ProxyHandler ( urllib2 . getproxies ( ) )
     if 54 - 54: iII111i - ooOoO0o
     if 81 - 81: I1Ii111 . O0 + i11i * iIii1I11I1II1 * I11i / o0
     if 88 - 88: i11i - i1 * oOooOoO0Oo0O . i1iIi11iIIi1I
     oOoOo0O0OOOoO = urllib2 . Request ( i1IiII1i1I )
     if 'proxy' in II1iiI :
      o0IIIIiI11I = II1iiI [ 'proxy' ]
      if 31 - 31: iII111i
      if 18 - 18: o00O0oo + iII111i
      if i1IiII1i1I [ : 5 ] == "https" :
       ii11i11 = urllib2 . ProxyHandler ( { 'https' : o0IIIIiI11I } )
       if 70 - 70: i1IIi . oOooOoO0Oo0O . i11i . OoooooooOO
      else :
       ii11i11 = urllib2 . ProxyHandler ( { 'http' : o0IIIIiI11I } )
       if 57 - 57: oOooOoO0Oo0O
      IIi = urllib2 . build_opener ( ii11i11 )
      urllib2 . install_opener ( IIi )
      if 35 - 35: OoooooooOO - ooOoO0o / i1iIi11iIIi1I
      if 50 - 50: o0
     oOoOo0O0OOOoO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
     o0IIIIiI11I = None
     if 33 - 33: Ii1I
     if 'referer' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'Referer' , II1iiI [ 'referer' ] )
     if 'accept' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'Accept' , II1iiI [ 'accept' ] )
     if 'agent' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'User-agent' , II1iiI [ 'agent' ] )
     if 'x-req' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'X-Requested-With' , II1iiI [ 'x-req' ] )
     if 'x-addr' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'x-addr' , II1iiI [ 'x-addr' ] )
     if 'x-forward' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'X-Forwarded-For' , II1iiI [ 'x-forward' ] )
     if 'setcookie' in II1iiI :
      if 98 - 98: o0 % i11i
      oOoOo0O0OOOoO . add_header ( 'Cookie' , II1iiI [ 'setcookie' ] )
     if 'appendcookie' in II1iiI :
      if 95 - 95: iIii1I11I1II1 - ooOoO0o - I11i + ooOoO0o % ii1IiI1i . oOooOoO0Oo0O
      IiiIIi1 = II1iiI [ 'appendcookie' ]
      IiiIIi1 = IiiIIi1 . split ( ';' )
      for iI1iIiiI in IiiIIi1 :
       Oo0OOo , Ii1I11i11I1i = iI1iIiiI . split ( '=' )
       oO00 , Oo0OOo = Oo0OOo . split ( ':' )
       IiI1II11iiI = cookielib . Cookie ( version = 0 , name = Oo0OOo , value = Ii1I11i11I1i , port = None , port_specified = False , domain = oO00 , domain_specified = False , domain_initial_dot = False , path = '/' , path_specified = True , secure = False , expires = None , discard = True , comment = None , comment_url = None , rest = { 'HttpOnly' : None } , rfc2109 = False )
       cookieJar . set_cookie ( IiI1II11iiI )
     if 'origin' in II1iiI :
      oOoOo0O0OOOoO . add_header ( 'Origin' , II1iiI [ 'origin' ] )
     if iI1ii1ii1I :
      iI1ii1ii1I = iI1ii1ii1I . split ( '&' )
      for iI1iIiiI in iI1ii1ii1I :
       Oo0OOo , Ii1I11i11I1i = iI1iIiiI . split ( '=' )
       oOoOo0O0OOOoO . add_header ( Oo0OOo , Ii1I11i11I1i )
       if 56 - 56: IiII
     if not cookieJar == None :
      if 84 - 84: o0 - i11iIiiIii
      i1II1II1iii1i = urllib2 . HTTPCookieProcessor ( cookieJar )
      IIi = urllib2 . build_opener ( i1II1II1iii1i , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      IIi = urllib2 . install_opener ( IIi )
      if 75 - 75: I1Ii111 - o0 - iIii1I11I1II1 % i1
      if 58 - 58: O0 . I1Ii111 / OoooooooOO . i1iIi11iIIi1I / I11i11Ii * i11i
      if 'noredirect' in II1iiI :
       IIi = urllib2 . build_opener ( i1II1II1iii1i , II , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
       IIi = urllib2 . install_opener ( IIi )
     elif 'noredirect' in II1iiI :
      IIi = urllib2 . build_opener ( II , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      IIi = urllib2 . install_opener ( IIi )
      if 53 - 53: iII111i - O0 / i1 % IiII * oOooOoO0Oo0O % I11i
      if 69 - 69: ii1IiI1i
     if 'connection' in II1iiI :
      if 83 - 83: i1
      from keepalive import HTTPHandler
      i1iiii = HTTPHandler ( )
      IIi = urllib2 . build_opener ( i1iiii )
      urllib2 . install_opener ( IIi )
      if 90 - 90: i1 % ii1IiI1i - iIii1I11I1II1 % o0
      if 8 - 8: o0 * I11i11Ii / I1Ii111 % iII111i - oOooOoO0Oo0O
      if 71 - 71: IiII
     Iii = None
     if 14 - 14: I11i
     if 'post' in II1iiI :
      o0oo0Ooooo0 = II1iiI [ 'post' ]
      if 76 - 76: i1IIi * OoooooooOO * O0 + ooOoO0o * ooOoO0o
      if 35 - 35: i1
      if 73 - 73: O0 - ii1IiI1i
      if 2 - 2: i11i / ooOoO0o
      OoOoO0oOOooo = o0oo0Ooooo0 . split ( ',' ) ;
      Iii = { }
      for oo0 in OoOoO0oOOooo :
       Oo0OOo = oo0 . split ( ':' ) [ 0 ] ;
       Ii1I11i11I1i = oo0 . split ( ':' ) [ 1 ] ;
       Iii [ Oo0OOo ] = Ii1I11i11I1i
      Iii = urllib . urlencode ( Iii )
      if 71 - 71: oOooOoO0Oo0O . i11i . oOooOoO0Oo0O - o00O0oo
     if 'rawpost' in II1iiI :
      Iii = II1iiI [ 'rawpost' ]
      if 45 - 45: I1Ii111 / O0 / o0 * I11i
      if 18 - 18: iIii1I11I1II1 + I11i + iIii1I11I1II1 . ii1IiI1i + ooOoO0o . o00O0oo
      if 7 - 7: ii1IiI1i + iIii1I11I1II1 * Ii1I * Ii1I / i11i - iII111i
      if 65 - 65: OOooOOo + o0 + i11i
     I1i1Iiiii = ''
     try :
      if 77 - 77: i11i
      if Iii :
       oO00OOoO00 = urllib2 . urlopen ( oOoOo0O0OOOoO , Iii )
      else :
       oO00OOoO00 = urllib2 . urlopen ( oOoOo0O0OOOoO )
      if oO00OOoO00 . info ( ) . get ( 'Content-Encoding' ) == 'gzip' :
       from StringIO import StringIO
       import gzip
       iii11i1IIII = StringIO ( oO00OOoO00 . read ( ) )
       Ii = gzip . GzipFile ( fileobj = iii11i1IIII )
       I1i1Iiiii = Ii . read ( )
      else :
       I1i1Iiiii = oO00OOoO00 . read ( )
       if 50 - 50: O0 . O0 . o00O0oo % I11i11Ii
       if 68 - 68: OOooOOo
       if 10 - 10: iII111i
      if 'proxy' in II1iiI and not iIIi11 is None :
       urllib2 . install_opener ( urllib2 . build_opener ( iIIi11 ) )
       if 77 - 77: I11i / i11i + I1Ii111 + o00O0oo - i11iIiiIii
      I1i1Iiiii = IiIIiI ( I1i1Iiiii )
      if 87 - 87: o0 % iIii1I11I1II1
      if 72 - 72: I11i . I11i - ii1IiI1i
      if 'includeheaders' in II1iiI :
       if 48 - 48: I11i11Ii - o00O0oo + I11i11Ii - oOooOoO0Oo0O * i11iIiiIii . IiII
       I1i1Iiiii += '$$HEADERS_START$$:'
       for oooooOOO000Oo in oO00OOoO00 . headers :
        I1i1Iiiii += oooooOOO000Oo + ':' + oO00OOoO00 . headers . get ( oooooOOO000Oo ) + '\n'
       I1i1Iiiii += '$$HEADERS_END$$:'
       if 35 - 35: I1Ii111 . O0 + I11i11Ii + I11i + i1IIi
      I1iI1iIi111i ( I1i1Iiiii )
      I1iI1iIi111i ( cookieJar )
      if 65 - 65: O0 * oOooOoO0Oo0O / oOooOoO0Oo0O . o0
      oO00OOoO00 . close ( )
     except :
      pass
     cachedPages [ II1iiI [ 'page' ] ] = I1i1Iiiii
     if 87 - 87: i11i * ii1IiI1i % I11i11Ii * I11i11Ii
     if 58 - 58: I11i . i1 + oOooOoO0Oo0O % I11i11Ii - i1iIi11iIIi1I
     if 50 - 50: IiII % i11i - o00O0oo . i1IIi + O0 % IiII
     if forCookieJarOnly :
      return cookieJar
    elif II1iiI [ 'page' ] and not II1iiI [ 'page' ] . startswith ( 'http' ) :
     if II1iiI [ 'page' ] . startswith ( '$pyFunction:' ) :
      i1iIi1IIiIII1 = i1Ii11I1II ( II1iiI [ 'page' ] . split ( '$pyFunction:' ) [ 1 ] , '' , cookieJar , II1iiI )
      if forCookieJarOnly :
       return cookieJar
      I1i1Iiiii = i1iIi1IIiIII1
      I1i1Iiiii = IiIIiI ( I1i1Iiiii )
     else :
      I1i1Iiiii = II1iiI [ 'page' ]
   if '$pyFunction:playmedia(' in II1iiI [ 'expres' ] or 'ActivateWindow' in II1iiI [ 'expres' ] or '$PLAYERPROXY$=' in url or any ( x in url for x in o000O0o ) :
    II1 = False
   if '$doregex' in II1iiI [ 'expres' ] :
    II1iiI [ 'expres' ] = OoO0o0000O ( regexs , II1iiI [ 'expres' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if not II1iiI [ 'expres' ] == '' :
    if 77 - 77: OOooOOo - I11i11Ii - iIii1I11I1II1
    if '$LiveStreamCaptcha' in II1iiI [ 'expres' ] :
     i1iIi1IIiIII1 = IIi1i ( II1iiI , I1i1Iiiii , cookieJar )
     if 21 - 21: OOooOOo % OOooOOo / i1iIi11iIIi1I
     url = url . replace ( "$doregex[" + I11Iii1 + "]" , i1iIi1IIiIII1 )
     if 12 - 12: IiII / o0
    elif II1iiI [ 'expres' ] . startswith ( '$pyFunction:' ) or '#$pyFunction' in II1iiI [ 'expres' ] :
     if 56 - 56: i11iIiiIii - iIii1I11I1II1 . i11i
     i1iIi1IIiIII1 = ''
     if II1iiI [ 'expres' ] . startswith ( '$pyFunction:' ) :
      i1iIi1IIiIII1 = i1Ii11I1II ( II1iiI [ 'expres' ] . split ( '$pyFunction:' ) [ 1 ] , I1i1Iiiii , cookieJar , II1iiI )
     else :
      i1iIi1IIiIII1 = doEvalFunction ( II1iiI [ 'expres' ] , I1i1Iiiii , cookieJar , II1iiI )
     if 'ActivateWindow' in II1iiI [ 'expres' ] : return
     if 81 - 81: I1Ii111 / o0 * I1Ii111 . O0
     if 61 - 61: i1iIi11iIIi1I * I11i + ooOoO0o . iIii1I11I1II1 % Ii1I . ooOoO0o
     if 53 - 53: ooOoO0o * I1Ii111 / iIii1I11I1II1 / oOooOoO0Oo0O % ii1IiI1i
     try :
      url = url . replace ( u"$doregex[" + I11Iii1 + "]" , i1iIi1IIiIII1 )
     except : url = url . replace ( "$doregex[" + I11Iii1 + "]" , i1iIi1IIiIII1 . decode ( "utf-8" ) )
    else :
     if 'listrepeat' in II1iiI :
      IIii = II1iiI [ 'listrepeat' ]
      oOOO0 = re . findall ( II1iiI [ 'expres' ] , I1i1Iiiii )
      return IIii , oOOO0 , II1iiI , regexs
      if 32 - 32: o00O0oo % ooOoO0o * I11i11Ii
     i1iIi1IIiIII1 = ''
     if not I1i1Iiiii == '' :
      if 72 - 72: o00O0oo . IiII - ooOoO0o - iII111i % i1IIi
      oO0o00O0O0oo0 = re . compile ( II1iiI [ 'expres' ] ) . search ( I1i1Iiiii )
      try :
       i1iIi1IIiIII1 = oO0o00O0O0oo0 . group ( 1 ) . strip ( )
      except : traceback . print_exc ( )
      if II1iiI [ 'page' ] == '' :
       i1iIi1IIiIII1 = II1iiI [ 'expres' ]
       if 24 - 24: ooOoO0o * OOooOOo
     if rawPost :
      if 88 - 88: i11iIiiIii + IiII * o0 * IiII + Ii1I
      i1iIi1IIiIII1 = urllib . quote_plus ( i1iIi1IIiIII1 )
     if 'htmlunescape' in II1iiI :
      if 88 - 88: I11i % I11i11Ii - IiII - o0 % i11iIiiIii
      import HTMLParser
      i1iIi1IIiIII1 = HTMLParser . HTMLParser ( ) . unescape ( i1iIi1IIiIII1 )
     try :
      url = url . replace ( "$doregex[" + I11Iii1 + "]" , i1iIi1IIiIII1 )
     except : url = url . replace ( "$doregex[" + I11Iii1 + "]" , i1iIi1IIiIII1 . decode ( "utf-8" ) )
     if 6 - 6: iII111i - i1iIi11iIIi1I . oOooOoO0Oo0O - O0
     if 16 - 16: IiII * IiII % iII111i % oOooOoO0Oo0O
   else :
    url = url . replace ( "$doregex[" + I11Iii1 + "]" , '' )
 if '$epoctime$' in url :
  url = url . replace ( '$epoctime$' , i1II1i ( ) )
 if '$epoctime2$' in url :
  url = url . replace ( '$epoctime2$' , OOOO ( ) )
  if 48 - 48: I11i / iII111i % i1iIi11iIIi1I / I1Ii111 / ooOoO0o
 if '$GUID$' in url :
  import uuid
  url = url . replace ( '$GUID$' , str ( uuid . uuid1 ( ) ) . upper ( ) )
 if '$get_cookies$' in url :
  url = url . replace ( '$get_cookies$' , o0OO00o0oOOoo ( cookieJar ) )
  if 37 - 37: Ii1I . ooOoO0o + I11i + Ii1I . I1Ii111 / iII111i
 if recursiveCall : return url
 if 29 - 29: I1Ii111 . o00O0oo - i11i
 if url == "" :
  return
 else :
  return url , II1
  if 68 - 68: iIii1I11I1II1 + i11i / OOooOOo
def oOooo00000 ( t ) :
 import hashlib
 iI1iIiiI = hashlib . md5 ( )
 iI1iIiiI . update ( t )
 return iI1iIiiI . hexdigest ( )
 if 26 - 26: O0
def i111I1iiIiII ( encrypted ) :
 OoO00ooO = ""
 for i1iIi1IIiIII1 in encrypted . split ( ':' ) :
  OoO00ooO += chr ( int ( i1iIi1IIiIII1 . replace ( "0m0" , "" ) ) / 84 / 5 )
 return OoO00ooO
 if 15 - 15: i11iIiiIii
def I11i1I1ii1i1 ( media_url ) :
 try :
  import CustomPlayer
  oO0ooooo0O00 = CustomPlayer . MyXBMCPlayer ( )
  iII11ii1ii = xbmcgui . ListItem ( label = str ( I1iIi1iIiiIiI ) , iconImage = "DefaultVideo.png" , thumbnailImage = xbmc . getInfoImage ( "ListItem.Thumb" ) , path = media_url )
  oO0ooooo0O00 . play ( media_url , iII11ii1ii )
  xbmc . sleep ( 1000 )
  while oO0ooooo0O00 . is_active :
   xbmc . sleep ( 200 )
 except :
  traceback . print_exc ( )
 return ''
 if 51 - 51: ii1IiI1i * ii1IiI1i
 if 98 - 98: i1iIi11iIIi1I - iII111i . I1Ii111 % i11iIiiIii
def OO00oo ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  O0Oo0O0 = page_value
  page_value = i1iiIII1IIiIIII ( page_value , headers = referer )
  if 33 - 33: o00O0oo % i1IIi - OOooOOo . O0 / O0
 oo00o0 = "(eval\(function\(p,a,c,k,e,(?:r|d).*)"
 if 17 - 17: iII111i / iIii1I11I1II1 - i1iIi11iIIi1I + oOooOoO0Oo0O % I11i
 III1III11II = re . compile ( oo00o0 ) . findall ( page_value )
 ooo0 = ""
 if III1III11II and len ( III1III11II ) > 0 :
  for Ii1I11i11I1i in III1III11II :
   iIi1iI = OO0Oo ( Ii1I11i11I1i )
   IIiiiiiIiIIi = iiiI ( iIi1iI , '\'(.*?)\'' )
   if 'unescape' in iIi1iI :
    iIi1iI = urllib . unquote ( IIiiiiiIiIIi )
   ooo0 += iIi1iI + '\n'
  print 'final value is ' , ooo0
  if 26 - 26: i1
  O0Oo0O0 = iiiI ( ooo0 , 'src="(.*?)"' )
  if 12 - 12: OoooooooOO / O0 + i11i * ii1IiI1i
  page_value = i1iiIII1IIiIIII ( O0Oo0O0 , headers = referer )
  if 46 - 46: i11i - I1Ii111 * OoooooooOO / OOooOOo % I1Ii111
  if 11 - 11: iIii1I11I1II1 . o0 / I1Ii111 % o00O0oo
  if 61 - 61: o00O0oo - I11i + I11i
 iii = iiiI ( page_value , 'streamer\'.*?\'(.*?)\'\)' )
 IiIIII1iiIIi = iiiI ( page_value , 'file\',\s\'(.*?)\'' )
 if 17 - 17: Ii1I
 if 97 - 97: ii1IiI1i * ii1IiI1i / IiII
 return iii + ' playpath=' + IiIIII1iiIIi + ' pageUrl=' + O0Oo0O0
 if 6 - 6: OOooOOo
def O0OOoOOOO00O ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  page_value = i1iiIII1IIiIIII ( page_value , headers = referer )
 oo00o0 = "var a = (.*?);\s*var b = (.*?);\s*var c = (.*?);\s*var d = (.*?);\s*var f = (.*?);\s*var v_part = '(.*?)';"
 III1III11II = re . compile ( oo00o0 ) . findall ( page_value ) [ 0 ]
 if 72 - 72: oOooOoO0Oo0O + I1Ii111 . o0 + o0
 iIi , oooooOOO000Oo , Oo0000O0OOooO , ooooOoo0OO , Ii , Ii1I11i11I1i = ( III1III11II )
 Ii = int ( Ii )
 iIi = int ( iIi ) / Ii
 oooooOOO000Oo = int ( oooooOOO000Oo ) / Ii
 Oo0000O0OOooO = int ( Oo0000O0OOooO ) / Ii
 ooooOoo0OO = int ( ooooOoo0OO ) / Ii
 if 85 - 85: i11i . o00O0oo % I11i % Ii1I
 oOOO0 = 'rtmp://' + str ( iIi ) + '.' + str ( oooooOOO000Oo ) + '.' + str ( Oo0000O0OOooO ) + '.' + str ( ooooOoo0OO ) + Ii1I11i11I1i ;
 return oOOO0
 if 80 - 80: OOooOOo * Ii1I / iIii1I11I1II1 % OOooOOo / iIii1I11I1II1
def Iiii1 ( url , useragent = None ) :
 str = '#EXTM3U'
 str += '\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=361816'
 str += '\n' + url + '&bytes=0-200000'
 OOooo0O00o = os . path . join ( O0oOoOOOoOO , 'testfile.m3u' )
 str += '\n'
 i1iiIIiiiII ( OOooo0O00o , str )
 if 5 - 5: OoooooooOO / i1 % Ii1I % i1iIi11iIIi1I * IiII + iIii1I11I1II1
 return OOooo0O00o
 if 11 - 11: ooOoO0o % i11iIiiIii % OOooOOo . I1Ii111
def i1iiIIiiiII ( file_name , page_data , append = False ) :
 if append :
  Ii = open ( file_name , 'a' )
  Ii . write ( page_data )
  Ii . close ( )
 else :
  Ii = open ( file_name , 'wb' )
  Ii . write ( page_data )
  Ii . close ( )
  return ''
  if 92 - 92: i11i
def IiIIi1II1i ( file_name ) :
 Ii = open ( file_name , 'rb' )
 ooooOoo0OO = Ii . read ( )
 Ii . close ( )
 return ooooOoo0OO
 if 81 - 81: O0 - iII111i + I11i11Ii
def oOo0OOO00Oo ( page_data ) :
 import re , base64 , urllib ;
 i1ii1ii1II1 = page_data
 while 'geh(' in i1ii1ii1II1 :
  if i1ii1ii1II1 . startswith ( 'lol(' ) : i1ii1ii1II1 = i1ii1ii1II1 [ 5 : - 1 ]
  if 6 - 6: I11i % i11i - I11i + ii1IiI1i
  i1ii1ii1II1 = re . compile ( '"(.*?)"' ) . findall ( i1ii1ii1II1 ) [ 0 ] ;
  i1ii1ii1II1 = base64 . b64decode ( i1ii1ii1II1 ) ;
  i1ii1ii1II1 = urllib . unquote ( i1ii1ii1II1 ) ;
 print i1ii1ii1II1
 return i1ii1ii1II1
 if 31 - 31: i11iIiiIii * i1 / Ii1I * i1IIi + i1
def O00OoooO00 ( page_data ) :
 print 'get_dag_url2' , page_data
 IiII1iIi111iiIII = i1iiIII1IIiIIII ( page_data ) ;
 Ii1 = '(http.*)'
 import uuid
 I1I1IIIIi11 = str ( uuid . uuid1 ( ) ) . upper ( )
 OooO0Oo0 = re . compile ( Ii1 ) . findall ( IiII1iIi111iiIII )
 o0iIIIIi = [ ( 'X-Playback-Session-Id' , I1I1IIIIi11 ) ]
 for i1I11ii in OooO0Oo0 :
  try :
   o0ooO00O0O = i1iiIII1IIiIIII ( i1I11ii , headers = o0iIIIIi ) ;
   if 41 - 41: ii1IiI1i
  except : pass
  if 5 - 5: I11i11Ii
 return page_data + '|&X-Playback-Session-Id=' + I1I1IIIIi11
 if 100 - 100: iII111i + iIii1I11I1II1
 if 59 - 59: I1Ii111
def oOoO0OOO00O ( page_data ) :
 print 'get_dag_url' , page_data
 if page_data . startswith ( 'http://dag.total-stream.net' ) :
  o0iIIIIi = [ ( 'User-Agent' , 'Verismo-BlackUI_(2.4.7.5.8.0.34)' ) ]
  page_data = i1iiIII1IIiIIII ( page_data , headers = o0iIIIIi ) ;
  if 73 - 73: i1 % i1iIi11iIIi1I + I1Ii111 + oOooOoO0Oo0O
 if '127.0.0.1' in page_data :
  return OoOO00 ( page_data )
 elif iiiI ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  O0O00OoOoOOo = iiiI ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + iiiI ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + iiiI ( page_data , '\\?y=([^&]+)&' )
 else :
  O0O00OoOoOOo = iiiI ( page_data , 'href="([^"]+)"[^"]+$' )
  if len ( O0O00OoOoOOo ) == 0 :
   O0O00OoOoOOo = page_data
 O0O00OoOoOOo = O0O00OoOoOOo . replace ( ' ' , '%20' )
 return O0O00OoOoOOo
 if 58 - 58: I1Ii111 + iIii1I11I1II1
def iiiI ( data , re_patten ) :
 IiiIii = ''
 II1iiI = re . search ( re_patten , data )
 if II1iiI != None :
  IiiIii = II1iiI . group ( 1 )
 else :
  IiiIii = ''
 return IiiIii
 if 94 - 94: iII111i . i1IIi
def OoOO00 ( page_data ) :
 O0O00OoOoOOo = ''
 if '127.0.0.1' in page_data :
  O0O00OoOoOOo = iiiI ( page_data , '&ver_t=([^&]+)&' ) + ' live=true timeout=15 playpath=' + iiiI ( page_data , '\\?y=([a-zA-Z0-9-_\\.@]+)' )
  if 71 - 71: IiII + i1iIi11iIIi1I - I1Ii111 . i1iIi11iIIi1I . I1Ii111 + oOooOoO0Oo0O
 if iiiI ( page_data , 'token=([^&]+)&' ) != '' :
  O0O00OoOoOOo = O0O00OoOoOOo + '?token=' + iiiI ( page_data , 'token=([^&]+)&' )
 elif iiiI ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  O0O00OoOoOOo = iiiI ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + iiiI ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + iiiI ( page_data , '\\?y=([^&]+)&' )
 else :
  O0O00OoOoOOo = iiiI ( page_data , 'HREF="([^"]+)"' )
  if 26 - 26: O0
 if 'dag1.asx' in O0O00OoOoOOo :
  return oOoO0OOO00O ( O0O00OoOoOOo )
  if 17 - 17: i11i
 if 'devinlivefs.fplive.net' not in O0O00OoOoOOo :
  O0O00OoOoOOo = O0O00OoOoOOo . replace ( 'devinlive' , 'flive' )
 if 'permlivefs.fplive.net' not in O0O00OoOoOOo :
  O0O00OoOoOOo = O0O00OoOoOOo . replace ( 'permlive' , 'flive' )
 return O0O00OoOoOOo
 if 9 - 9: OoooooooOO + OOooOOo
 if 33 - 33: O0
def iiI1ii ( str_eval ) :
 O0OooOO = ""
 try :
  i1i1 = "w,i,s,e=(" + str_eval + ')'
  exec ( i1i1 )
  O0OooOO = o0oOoOo0 ( w , i , s , e )
 except : traceback . print_exc ( file = sys . stdout )
 if 38 - 38: i1 % ooOoO0o + i11iIiiIii + IiII + o00O0oo / i11iIiiIii
 return O0OooOO
 if 94 - 94: IiII - I11i11Ii + OOooOOo
def o0oOoOo0 ( w , i , s , e ) :
 O0oooOoO = 0 ;
 O0Oo0 = 0 ;
 iIIIi1IiI11I1 = 0 ;
 O0Ooo000 = [ ] ;
 IIi11iI1Iii = [ ] ;
 while True :
  if ( O0oooOoO < 5 ) :
   IIi11iI1Iii . append ( w [ O0oooOoO ] )
  elif ( O0oooOoO < len ( w ) ) :
   O0Ooo000 . append ( w [ O0oooOoO ] ) ;
  O0oooOoO += 1 ;
  if ( O0Oo0 < 5 ) :
   IIi11iI1Iii . append ( i [ O0Oo0 ] )
  elif ( O0Oo0 < len ( i ) ) :
   O0Ooo000 . append ( i [ O0Oo0 ] )
  O0Oo0 += 1 ;
  if ( iIIIi1IiI11I1 < 5 ) :
   IIi11iI1Iii . append ( s [ iIIIi1IiI11I1 ] )
  elif ( iIIIi1IiI11I1 < len ( s ) ) :
   O0Ooo000 . append ( s [ iIIIi1IiI11I1 ] ) ;
  iIIIi1IiI11I1 += 1 ;
  if ( len ( w ) + len ( i ) + len ( s ) + len ( e ) == len ( O0Ooo000 ) + len ( IIi11iI1Iii ) + len ( e ) ) :
   break ;
   if 29 - 29: O0 + oOooOoO0Oo0O - i1IIi % I11i11Ii + ooOoO0o / Ii1I
 iI1IIIII1Ii = '' . join ( O0Ooo000 )
 iIiI1 = '' . join ( IIi11iI1Iii )
 O0Oo0 = 0 ;
 I1IiII1I1i1I1 = [ ] ;
 for O0oooOoO in range ( 0 , len ( O0Ooo000 ) , 2 ) :
  if 28 - 28: I11i11Ii + I1Ii111 % i11i / i1iIi11iIIi1I + i11iIiiIii
  ii11Iiii = - 1 ;
  if ( ord ( iIiI1 [ O0Oo0 ] ) % 2 ) :
   ii11Iiii = 1 ;
   if 32 - 32: o0 . ii1IiI1i % oOooOoO0Oo0O - i11i
  I1IiII1I1i1I1 . append ( chr ( int ( iI1IIIII1Ii [ O0oooOoO : O0oooOoO + 2 ] , 36 ) - ii11Iiii ) ) ;
  O0Oo0 += 1 ;
  if ( O0Oo0 >= len ( IIi11iI1Iii ) ) :
   O0Oo0 = 0 ;
 oOOO0 = '' . join ( I1IiII1I1i1I1 )
 if 'eval(function(w,i,s,e)' in oOOO0 :
  print 'STILL GOing'
  oOOO0 = re . compile ( 'eval\(function\(w,i,s,e\).*}\((.*?)\)' ) . findall ( oOOO0 ) [ 0 ]
  return iiI1ii ( oOOO0 )
 else :
  print 'FINISHED'
  return oOOO0
  if 11 - 11: O0 + oOooOoO0Oo0O
def OO0Oo ( page_value , regex_for_text = '' , iterations = 1 , total_iteration = 1 ) :
 try :
  OO0OOoooo0o = None
  if page_value . startswith ( "http" ) :
   page_value = i1iiIII1IIiIIII ( page_value )
  print 'page_value' , page_value
  if regex_for_text and len ( regex_for_text ) > 0 :
   page_value = re . compile ( regex_for_text ) . findall ( page_value ) [ 0 ]
   if 13 - 13: oOooOoO0Oo0O + O0 - ii1IiI1i % I11i11Ii / iII111i . i1IIi
  page_value = OOOO00OoooO ( page_value , iterations , total_iteration )
 except : traceback . print_exc ( file = sys . stdout )
 print 'unpacked' , page_value
 if 'sav1live.tv' in page_value :
  page_value = page_value . replace ( 'sav1live.tv' , 'sawlive.tv' )
  print 'sav1 unpacked' , page_value
 return page_value
 if 7 - 7: ii1IiI1i / i11i - Ii1I + i1IIi + iII111i
def OOOO00OoooO ( sJavascript , iteration = 1 , totaliterations = 2 ) :
 print 'iteration' , iteration
 if sJavascript . startswith ( 'var _0xcb8a=' ) :
  i11i11i = sJavascript . split ( 'var _0xcb8a=' )
  i1i1 = "myarray=" + i11i11i [ 1 ] . split ( "eval(" ) [ 0 ]
  exec ( i1i1 )
  iiI1iI = 62
  Ooo00O0 = int ( i11i11i [ 1 ] . split ( ",62," ) [ 1 ] . split ( ',' ) [ 0 ] )
  OoO0OOoO0 = myarray [ 0 ]
  iiI11i = myarray [ 3 ]
  with open ( 'temp file' + str ( iteration ) + '.js' , "wb" ) as o0OoiiI1i :
   o0OoiiI1i . write ( str ( iiI11i ) )
   if 3 - 3: I1Ii111 / Ii1I
 else :
  if 34 - 34: i11iIiiIii / ooOoO0o * I11i . I11i11Ii
  i11i11i = sJavascript . split ( "rn p}('" )
  print i11i11i
  if 79 - 79: ooOoO0o
  OoO0OOoO0 , iiI1iI , Ooo00O0 , iiI11i = ( '' , '0' , '0' , '' )
  if 31 - 31: I11i % ooOoO0o
  i1i1 = "p1,a1,c1,k1=('" + i11i11i [ 1 ] . split ( ".spli" ) [ 0 ] + ')'
  exec ( i1i1 )
 iiI11i = iiI11i . split ( '|' )
 i11i11i = i11i11i [ 1 ] . split ( "))'" )
 if 98 - 98: I1Ii111 * iIii1I11I1II1 . iII111i * I11i11Ii / ii1IiI1i + o00O0oo
 if 25 - 25: OOooOOo
 if 19 - 19: oOooOoO0Oo0O % iII111i . I1Ii111 * o00O0oo
 if 89 - 89: o0 . I11i
 if 7 - 7: OOooOOo % o0 - oOooOoO0Oo0O + I11i11Ii
 if 70 - 70: i11i + ooOoO0o + i11iIiiIii - i1IIi / I1Ii111
 if 40 - 40: ii1IiI1i * ooOoO0o
 if 38 - 38: O0 . I11i11Ii + o0 - OOooOOo
 if 43 - 43: IiII + I11i11Ii / OoooooooOO
 if 24 - 24: O0 + i1 * iII111i - ooOoO0o
 if 10 - 10: i11iIiiIii
 if 21 - 21: oOooOoO0Oo0O / IiII
 if 69 - 69: o00O0oo % o00O0oo
 if 76 - 76: i11iIiiIii * IiII / i1iIi11iIIi1I % ii1IiI1i + I11i
 if 48 - 48: iIii1I11I1II1 % i1IIi + o0 % i1
 if 79 - 79: o0 % oOooOoO0Oo0O % iII111i / i1IIi % i1iIi11iIIi1I
 if 56 - 56: iIii1I11I1II1 - i11iIiiIii * IiII
 if 84 - 84: I11i + iII111i + i1
 if 33 - 33: iII111i
 if 93 - 93: o00O0oo
 if 34 - 34: OOooOOo - o00O0oo * I11i11Ii / i1
 if 19 - 19: ii1IiI1i
 ooooooo00o = ''
 ooooOoo0OO = ''
 if 46 - 46: iIii1I11I1II1 . i11iIiiIii - o0 % O0 / i11i * i1IIi
 if 66 - 66: O0
 oOooOOo00ooO = str ( o0OO0oooo ( OoO0OOoO0 , iiI1iI , Ooo00O0 , iiI11i , ooooooo00o , ooooOoo0OO , iteration ) )
 if 40 - 40: ooOoO0o - o0 * Ii1I - I1Ii111 / o0
 if 71 - 71: OOooOOo / OoooooooOO % I1Ii111 / o0 % ooOoO0o
 if 19 - 19: ooOoO0o + I1Ii111 / OOooOOo / i11i
 if 92 - 92: i1IIi % o00O0oo + o00O0oo - iIii1I11I1II1 . iII111i
 if 33 - 33: i1 / O0 + I11i
 if iteration >= totaliterations :
  if 75 - 75: I1Ii111 % i11iIiiIii + iIii1I11I1II1
  return oOooOOo00ooO
 else :
  if 92 - 92: o0 % O0
  return OOOO00OoooO ( oOooOOo00ooO , iteration + 1 )
  if 55 - 55: iIii1I11I1II1 * IiII
def o0OO0oooo ( p , a , c , k , e , d , iteration , v = 1 ) :
 if 85 - 85: iIii1I11I1II1 . i11i
 if 54 - 54: iII111i . OoooooooOO % I11i11Ii
 if 22 - 22: I11i
 while ( c >= 1 ) :
  c = c - 1
  if ( k [ c ] ) :
   I1I11Iiii111 = str ( iI1ii111iiIii ( c , a ) )
   if v == 1 :
    p = re . sub ( '\\b' + I1I11Iiii111 + '\\b' , k [ c ] , p )
   else :
    p = oO0oiIiI ( p , I1I11Iiii111 , k [ c ] )
    if 46 - 46: IiII
    if 65 - 65: i1IIi . ii1IiI1i / o00O0oo
    if 11 - 11: I1Ii111 * o00O0oo / o00O0oo - I11i
    if 68 - 68: oOooOoO0Oo0O % I1Ii111 - I1Ii111 / oOooOoO0Oo0O + ii1IiI1i - I11i11Ii
    if 65 - 65: o00O0oo - i1IIi
    if 62 - 62: Ii1I / OOooOOo % I11i11Ii . OoooooooOO / i11iIiiIii / ooOoO0o
 return p
 if 60 - 60: oOooOoO0Oo0O % OOooOOo / i1 % OOooOOo * i11iIiiIii / IiII
 if 34 - 34: ooOoO0o - I11i
 if 25 - 25: OOooOOo % oOooOoO0Oo0O + i11iIiiIii + O0 * OoooooooOO
def oO0oiIiI ( source_str , word_to_find , replace_with ) :
 ooO0 = None
 ooO0 = source_str . split ( word_to_find )
 if len ( ooO0 ) > 1 :
  o0Iiii = [ ]
  I1i1I = 0
  for i1111iI1 in ooO0 :
   if 76 - 76: OoooooooOO - i11i % o0 + OOooOOo + iIii1I11I1II1 . o0
   o0Iiii . append ( i1111iI1 )
   i1iIi1IIiIII1 = word_to_find
   if 16 - 16: i1 . Ii1I
   if 50 - 50: o00O0oo * o0 + ii1IiI1i - i11iIiiIii + I11i11Ii * ii1IiI1i
   if I1i1I == len ( ooO0 ) - 1 :
    i1iIi1IIiIII1 = ''
   else :
    if len ( i1111iI1 ) == 0 :
     if ( len ( ooO0 [ I1i1I + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( ooO0 [ I1i1I + 1 ] ) > 0 and ooO0 [ I1i1I + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) :
      i1iIi1IIiIII1 = replace_with
      if 20 - 20: ooOoO0o / i1 % o0
    else :
     if ( ooO0 [ I1i1I ] [ - 1 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) and ( ( len ( ooO0 [ I1i1I + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( ooO0 [ I1i1I + 1 ] ) > 0 and ooO0 [ I1i1I + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) ) :
      i1iIi1IIiIII1 = replace_with
      if 69 - 69: ooOoO0o - i1IIi % IiII . I11i - I11i
   o0Iiii . append ( i1iIi1IIiIII1 )
   I1i1I += 1
   if 65 - 65: I11i + i11i
  source_str = '' . join ( o0Iiii )
 return source_str
 if 61 - 61: i11iIiiIii * OOooOOo % I11i11Ii * ooOoO0o - OoooooooOO - i1iIi11iIIi1I
def o0OOo ( num , radix ) :
 if 42 - 42: O0 % iII111i - iIii1I11I1II1 + ooOoO0o % oOooOoO0Oo0O + o00O0oo
 II1i11i1iIi11 = ""
 if num == 0 : return '0'
 while num > 0 :
  II1i11i1iIi11 = "0123456789abcdefghijklmnopqrstuvwxyz" [ num % radix ] + II1i11i1iIi11
  num /= radix
 return II1i11i1iIi11
 if 82 - 82: O0
def iI1ii111iiIii ( cc , a ) :
 I1I11Iiii111 = "" if cc < a else iI1ii111iiIii ( int ( cc / a ) , a )
 cc = ( cc % a )
 O0oO0oo0O = chr ( cc + 29 ) if cc > 35 else str ( o0OOo ( cc , 36 ) )
 return I1I11Iiii111 + O0oO0oo0O
 if 82 - 82: OoooooooOO . iII111i
 if 26 - 26: OOooOOo + I1Ii111 - i11i . i11i + ii1IiI1i + o0
def iI1i11II1i ( url , headers = None ) :
 try :
  if headers is None :
   if 68 - 68: O0
   if 76 - 76: ii1IiI1i
   headers = { '\x55\x73\x65\x72\x2d\x61\x67\x65\x6e\x74' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0)/Apollo Gecko/20100101 Firefox/19.0' , 'Apollo' : 'Direitos Reservados' , 'Referer' : 'https://deus-apollo.ml' , 'Ref' : 'copyright © 2017-2020' , 'DEUS' : 'Apollo' }
  oOoOo0O0OOOoO = urllib2 . Request ( url , None , headers )
  oO00OOoO00 = urllib2 . urlopen ( oOoOo0O0OOOoO )
  IiI111111IIII = oO00OOoO00 . read ( )
  oO00OOoO00 . close ( )
  return IiI111111IIII
 except urllib2 . URLError , ooooooo00o :
  I1iI1iIi111i ( 'URL: ' + url )
  if hasattr ( ooooooo00o , 'code' ) :
   I1iI1iIi111i ( 'Falha com o código de erro - %s.' % ooooooo00o . code )
   if 99 - 99: i1
   if 1 - 1: iII111i * o0 * i1iIi11iIIi1I + I11i11Ii
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( ooooooo00o . code ) + ",10000," + oOO00Oo + ")" )
  elif hasattr ( ooooooo00o , 'reason' ) :
   I1iI1iIi111i ( 'Falha ao acessar um servidor.' )
   I1iI1iIi111i ( 'Razão: %s' % ooooooo00o . reason )
   if 90 - 90: ooOoO0o % I11i11Ii - I11i11Ii . iIii1I11I1II1 / I11i + Ii1I
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( ooooooo00o . reason ) + ",10000," + oOO00Oo + ")" )
   if 89 - 89: OOooOOo
def o0OO00o0oOOoo ( cookieJar ) :
 try :
  o0OOOOOo00 = ""
  for oOOO00o000o , oo0oOO in enumerate ( cookieJar ) :
   o0OOOOOo00 += oo0oOO . name + "=" + oo0oOO . value + ";"
 except : pass
 if 41 - 41: i1iIi11iIIi1I . ooOoO0o * I1Ii111 * ooOoO0o
 return o0OOOOOo00
 if 74 - 74: iIii1I11I1II1 / i1
 if 58 - 58: iIii1I11I1II1 - oOooOoO0Oo0O % i1 % OoooooooOO * iIii1I11I1II1 + I11i
def i1IiIi1 ( cookieJar , COOKIEFILE ) :
 try :
  I1Ii11II1I1 = os . path . join ( O0oOoOOOoOO , COOKIEFILE )
  cookieJar . save ( I1Ii11II1I1 , ignore_discard = True )
 except : pass
 if 25 - 25: I11i % O0
def Ooo0O ( COOKIEFILE ) :
 if 44 - 44: ooOoO0o . iII111i * i11i / I1Ii111 + iIii1I11I1II1
 Ii1111III1 = None
 if COOKIEFILE :
  try :
   I1Ii11II1I1 = os . path . join ( O0oOoOOOoOO , COOKIEFILE )
   Ii1111III1 = cookielib . LWPCookieJar ( )
   Ii1111III1 . load ( I1Ii11II1I1 , ignore_discard = True )
  except :
   Ii1111III1 = None
   if 74 - 74: ii1IiI1i - IiII * i1IIi
 if not Ii1111III1 :
  Ii1111III1 = cookielib . LWPCookieJar ( )
  if 12 - 12: O0
 return Ii1111III1
 if 75 - 75: iIii1I11I1II1 % I1Ii111 + ii1IiI1i * O0 . IiII - o00O0oo
def i1Ii11I1II ( fun_call , page_data , Cookie_Jar ) :
 i1IIiIIIi1 = ''
 if oOOoOooOo not in sys . path :
  sys . path . append ( oOOoOooOo )
  if 84 - 84: OOooOOo + I11i . IiII
 print fun_call
 try :
  O0o00 = 'import ' + fun_call . split ( '.' ) [ 0 ]
  print O0o00 , sys . path
  exec ( O0o00 )
  print 'done'
 except :
  print 'error in import'
  traceback . print_exc ( file = sys . stdout )
 print 'ret_val=' + fun_call
 exec ( 'ret_val=' + fun_call )
 print i1IIiIIIi1
 if 48 - 48: Ii1I + o00O0oo + IiII / Ii1I / IiII
 return str ( i1IIiIIIi1 )
 if 71 - 71: I1Ii111
def i1I11I ( url ) :
 I1IIi1i1Ii1I1 = i1iiIII1IIiIIII ( url )
 Ooo0ooo = ""
 O0Oo0O00o0oo0OO = ""
 OooO00 = "<script.*?src=\"(.*?recap.*?)\""
 IiiIii = re . findall ( OooO00 , I1IIi1i1Ii1I1 )
 o0O00OoOOo = False
 iIiIIi11iI = None
 O0Oo0O00o0oo0OO = None
 if 65 - 65: O0 - ooOoO0o . iII111i
 if IiiIii and len ( IiiIii ) > 0 :
  IIOOO00o0 = IiiIii [ 0 ]
  o0O00OoOOo = True
  if 97 - 97: ii1IiI1i / ii1IiI1i / iIii1I11I1II1 % i1IIi . ii1IiI1i . I1Ii111
  IIII1ii1 = 'challenge.*?\'(.*?)\''
  OOO0O0OOo = '\'(.*?)\''
  Iii1 = i1iiIII1IIiIIII ( IIOOO00o0 )
  Ooo0ooo = re . findall ( IIII1ii1 , Iii1 ) [ 0 ]
  OOoO = 'http://www.google.com/recaptcha/api/reload?c=' ;
  i1IiiI = IIOOO00o0 . split ( 'k=' ) [ 1 ]
  OOoO += Ooo0ooo + '&k=' + i1IiiI + '&captcha_k=1&type=image&lang=en-GB'
  O0OOO0 = i1iiIII1IIiIIII ( OOoO )
  iIiIIi11iI = re . findall ( OOO0O0OOo , O0OOO0 ) [ 0 ]
  o0OIi = 'http://www.google.com/recaptcha/api/image?c=' + iIiIIi11iI
  if not o0OIi . startswith ( "http" ) :
   o0OIi = 'http://www.google.com/recaptcha/api/' + o0OIi
  import random
  Oo0OOo = random . randrange ( 100 , 1000 , 5 )
  IIi1iiI = os . path . join ( O0oOoOOOoOO , str ( Oo0OOo ) + "captcha.img" )
  o0o = open ( IIi1iiI , "wb" )
  o0o . write ( i1iiIII1IIiIIII ( o0OIi ) )
  o0o . close ( )
  oOO00OO0o0O = III1IiiIiiI1i ( captcha = IIi1iiI )
  O0Oo0O00o0oo0OO = oOO00OO0o0O . get ( )
  os . remove ( IIi1iiI )
 return iIiIIi11iI , O0Oo0O00o0oo0OO
 if 73 - 73: i1IIi % Ii1I - o00O0oo / i1 % i1iIi11iIIi1I / ooOoO0o
def i1iiIII1IIiIIII ( url , cookieJar = None , post = None , timeout = 20 , headers = None ) :
 if 89 - 89: I1Ii111 / i1iIi11iIIi1I * O0 / Ii1I . ooOoO0o
 if 17 - 17: Ii1I
 i1II1II1iii1i = urllib2 . HTTPCookieProcessor ( cookieJar )
 IIi = urllib2 . build_opener ( i1II1II1iii1i , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
 if 56 - 56: o00O0oo * i1 + Ii1I
 oOoOo0O0OOOoO = urllib2 . Request ( url )
 oOoOo0O0OOOoO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36' )
 if headers :
  for iI1iIiiI , I11II11111i11 in headers :
   oOoOo0O0OOOoO . add_header ( iI1iIiiI , I11II11111i11 )
   if 83 - 83: OOooOOo - o00O0oo - I1Ii111 % i1IIi - IiII . i1
 oO00OOoO00 = IIi . open ( oOoOo0O0OOOoO , post , timeout = timeout )
 I1i1Iiiii = oO00OOoO00 . read ( )
 oO00OOoO00 . close ( )
 return I1i1Iiiii ;
 if 96 - 96: I11i11Ii + ooOoO0o . i1IIi
def Ooo ( str , reg = None ) :
 if reg :
  str = re . findall ( reg , str ) [ 0 ]
 Iii1I1iI = urllib . unquote ( str [ 0 : len ( str ) - 1 ] ) ;
 oOoOo0 = '' ;
 for ii in range ( len ( Iii1I1iI ) ) :
  oOoOo0 += chr ( ord ( Iii1I1iI [ ii ] ) - Iii1I1iI [ len ( Iii1I1iI ) - 1 ] ) ;
 oOoOo0 = urllib . unquote ( oOoOo0 )
 print oOoOo0
 return oOoOo0
 if 19 - 19: o0 . i1 . OoooooooOO
def IiIIiI ( str ) :
 iIiii1iI1i = re . findall ( 'unescape\(\'(.*?)\'' , str )
 print 'js' , iIiii1iI1i
 if ( not iIiii1iI1i == None ) and len ( iIiii1iI1i ) > 0 :
  for i1iiiI in iIiii1iI1i :
   if 75 - 75: OoooooooOO . I11i + i1iIi11iIIi1I / iII111i - oOooOoO0Oo0O % iII111i
   str = str . replace ( i1iiiI , urllib . unquote ( i1iiiI ) )
 return str
 if 89 - 89: IiII * iIii1I11I1II1 + i11iIiiIii . OoooooooOO
O0O0 = 0
def IIi1i ( m , html_page , cookieJar ) :
 global O0O0
 O0O0 += 1
 oO0oo = m [ 'expre' ]
 O0Oo0O0 = m [ 'page' ]
 o00o0o000Oo = re . compile ( '\$LiveStreamCaptcha\[([^\]]*)\]' ) . findall ( oO0oo ) [ 0 ]
 if 100 - 100: i1IIi - i11iIiiIii . ooOoO0o * i1iIi11iIIi1I
 IIOOO00o0 = re . compile ( o00o0o000Oo ) . findall ( html_page ) [ 0 ]
 print oO0oo , o00o0o000Oo , IIOOO00o0
 if not IIOOO00o0 . startswith ( "http" ) :
  oOIIII = 'http://' + "" . join ( O0Oo0O0 . split ( '/' ) [ 2 : 3 ] )
  if IIOOO00o0 . startswith ( "/" ) :
   IIOOO00o0 = oOIIII + IIOOO00o0
  else :
   IIOOO00o0 = oOIIII + '/' + IIOOO00o0
   if 65 - 65: i11i / I11i11Ii
 IIi1iiI = os . path . join ( O0oOoOOOoOO , str ( O0O0 ) + "captcha.jpg" )
 o0o = open ( IIi1iiI , "wb" )
 print ' c capurl' , IIOOO00o0
 oOoOo0O0OOOoO = urllib2 . Request ( IIOOO00o0 )
 oOoOo0O0OOOoO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
 if 'refer' in m :
  oOoOo0O0OOOoO . add_header ( 'Referer' , m [ 'refer' ] )
 if 'agent' in m :
  oOoOo0O0OOOoO . add_header ( 'User-agent' , m [ 'agent' ] )
 if 'setcookie' in m :
  print 'adding cookie' , m [ 'setcookie' ]
  oOoOo0O0OOOoO . add_header ( 'Cookie' , m [ 'setcookie' ] )
  if 42 - 42: i11iIiiIii . O0
  if 75 - 75: ooOoO0o + iIii1I11I1II1
  if 19 - 19: oOooOoO0Oo0O + i11iIiiIii . I1Ii111 - Ii1I / iII111i + i1
  if 38 - 38: I11i11Ii / iIii1I11I1II1 * iIii1I11I1II1 % ii1IiI1i
 urllib2 . urlopen ( oOoOo0O0OOOoO )
 oO00OOoO00 = urllib2 . urlopen ( oOoOo0O0OOOoO )
 if 92 - 92: Ii1I / O0 * oOooOoO0Oo0O - Ii1I
 o0o . write ( oO00OOoO00 . read ( ) )
 oO00OOoO00 . close ( )
 o0o . close ( )
 oOO00OO0o0O = III1IiiIiiI1i ( captcha = IIi1iiI )
 O0Oo0O00o0oo0OO = oOO00OO0o0O . get ( )
 return O0Oo0O00o0oo0OO
 if 99 - 99: i11iIiiIii % OoooooooOO
class III1IiiIiiI1i ( xbmcgui . WindowDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  self . cptloc = kwargs . get ( 'captcha' )
  self . img = xbmcgui . ControlImage ( 335 , 30 , 624 , 60 , self . cptloc )
  self . addControl ( self . img )
  self . kbd = xbmc . Keyboard ( )
  if 56 - 56: I1Ii111 * ooOoO0o
 def get ( self ) :
  self . show ( )
  time . sleep ( 2 )
  self . kbd . doModal ( )
  if ( self . kbd . isConfirmed ( ) ) :
   O00oO0O = self . kbd . getText ( )
   self . close ( )
   return O00oO0O
  self . close ( )
  return False
  if 3 - 3: iIii1I11I1II1 % ii1IiI1i . I11i % Ii1I
def i1II1i ( ) :
 import time
 return str ( int ( time . time ( ) * 1000 ) )
 if 40 - 40: o00O0oo * iII111i . iII111i + i11i + OoooooooOO
def OOOO ( ) :
 import time
 return str ( int ( time . time ( ) ) )
 if 17 - 17: I1Ii111 % iII111i
def Iii1Iiii ( ) :
 i1i1Ii1IiIII = [ ]
 I1IIii11 = sys . argv [ 2 ]
 if len ( I1IIii11 ) >= 2 :
  I1I1 = sys . argv [ 2 ]
  O0O = I1I1 . replace ( '?' , '' )
  if ( I1I1 [ len ( I1I1 ) - 1 ] == '/' ) :
   I1I1 = I1I1 [ 0 : len ( I1I1 ) - 2 ]
  OO0ooO00o = O0O . split ( '&' )
  i1i1Ii1IiIII = { }
  for ii in range ( len ( OO0ooO00o ) ) :
   I1iii1 = { }
   I1iii1 = OO0ooO00o [ ii ] . split ( '=' )
   if ( len ( I1iii1 ) ) == 2 :
    i1i1Ii1IiIII [ I1iii1 [ 0 ] ] = I1iii1 [ 1 ]
 return i1i1Ii1IiIII
 if 19 - 19: OOooOOo % OoooooooOO . OoooooooOO
 if 40 - 40: O0 . ooOoO0o / iIii1I11I1II1 * i1
def OOo00Oooo ( ) :
 oOO00oO00O0OO = json . loads ( open ( O00OOOoOoo0O ) . read ( ) )
 oOo0OoOOo0 = len ( oOO00oO00O0OO )
 for ii in oOO00oO00O0OO :
  I1iIi1iIiiIiI = ii [ 0 ]
  O0O0Oooo0o = ii [ 1 ]
  I1oO0oOOOooo = ii [ 2 ]
  try :
   IiII1II11I = ii [ 3 ]
   if IiII1II11I == None :
    raise
  except :
   if oO . getSetting ( 'use_thumb' ) == "true" :
    IiII1II11I = I1oO0oOOOooo
   else :
    IiII1II11I = o00o0
  try : I1iiIi111I = ii [ 5 ]
  except : I1iiIi111I = None
  try : o0oOoO0O = ii [ 6 ]
  except : o0oOoO0O = None
  if 6 - 6: iIii1I11I1II1 - iIii1I11I1II1 % i1 / iIii1I11I1II1 * ooOoO0o
  if ii [ 4 ] == 0 :
   iIiIIii ( O0O0Oooo0o , I1iIi1iIiiIiI , I1oO0oOOOooo , IiII1II11I , '' , '' , '' , 'fav' , I1iiIi111I , o0oOoO0O , oOo0OoOOo0 )
  else :
   I1IiiiiI ( I1iIi1iIiiIiI , O0O0Oooo0o , ii [ 4 ] , I1oO0oOOOooo , o00o0 , '' , '' , '' , '' , 'fav' )
   if 3 - 3: I11i . I1Ii111 / I11i11Ii
   if 89 - 89: OoooooooOO . iIii1I11I1II1 . I11i11Ii * iIii1I11I1II1 - ooOoO0o
def OoOO0o0o0 ( name , url , iconimage , fanart , mode , playlist = None , regexs = None ) :
 iI111ii1iIiI = [ ]
 if not os . path . exists ( O00OOOoOoo0O + 'txt' ) :
  os . makedirs ( O00OOOoOoo0O + 'txt' )
 if not os . path . exists ( O000OOo00oo ) :
  os . makedirs ( O000OOo00oo )
 try :
  if 73 - 73: O0 + o00O0oo - O0 / OoooooooOO * I11i11Ii
  name = name . encode ( 'utf-8' , 'ignore' )
 except :
  pass
 if os . path . exists ( O00OOOoOoo0O ) == False :
  I1iI1iIi111i ( 'Making Favorites File' )
  iI111ii1iIiI . append ( ( name , url , iconimage , fanart , mode , playlist , regexs ) )
  iIi = open ( O00OOOoOoo0O , "w" )
  iIi . write ( json . dumps ( iI111ii1iIiI ) )
  iIi . close ( )
 else :
  I1iI1iIi111i ( 'Appending Favorites' )
  iIi = open ( O00OOOoOoo0O ) . read ( )
  IiI111111IIII = json . loads ( iIi )
  IiI111111IIII . append ( ( name , url , iconimage , fanart , mode ) )
  oooooOOO000Oo = open ( O00OOOoOoo0O , "w" )
  oooooOOO000Oo . write ( json . dumps ( IiI111111IIII ) )
  oooooOOO000Oo . close ( )
  if 32 - 32: i1iIi11iIIi1I % oOooOoO0Oo0O % IiII
  if 66 - 66: o0 + i1
def OOOO00 ( name ) :
 IiI111111IIII = json . loads ( open ( O00OOOoOoo0O ) . read ( ) )
 for oOOO00o000o in range ( len ( IiI111111IIII ) ) :
  if IiI111111IIII [ oOOO00o000o ] [ 0 ] == name :
   del IiI111111IIII [ oOOO00o000o ]
   oooooOOO000Oo = open ( O00OOOoOoo0O , "w" )
   oooooOOO000Oo . write ( json . dumps ( IiI111111IIII ) )
   oooooOOO000Oo . close ( )
   break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 71 - 71: o00O0oo . i11iIiiIii
def o00o ( url ) :
 if oO . getSetting ( 'Updatecommonresolvers' ) == 'true' :
  i1I11ii = os . path . join ( ii1ii11IIIiiI , 'genesisresolvers.py' )
  if xbmcvfs . exists ( i1I11ii ) :
   os . remove ( i1I11ii )
   if 56 - 56: O0 * IiII + IiII * iIii1I11I1II1 / o00O0oo * ooOoO0o
  IiOo0O0O = 'https://raw.githubusercontent.com/KelTec-Maedia-Play/master/plugin.video.genesis/commonresolvers.py'
  IiIiiI1ii111 = urllib . urlretrieve ( IiOo0O0O , i1I11ii )
  oO . setSetting ( 'Updatecommonresolvers' , 'false' )
 try :
  import genesisresolvers
 except Exception :
  if 30 - 30: iII111i + i11i % OoooooooOO
  if 89 - 89: iII111i
  xbmc . executebuiltin ( "XBMC.Notification(Por favor Ative Atualizar Resolvedores comuns para reproduzir em configurações. - ,10000)" )
  if 51 - 51: IiII
 O00O0Oo0 = genesisresolvers . get ( url ) . result
 if url == O00O0Oo0 or O00O0Oo0 is None :
  if 53 - 53: i1IIi . i1IIi - Ii1I / IiII - o0 % oOooOoO0Oo0O
  if 65 - 65: IiII . OoooooooOO - O0 . IiII - i11iIiiIii
  xbmc . executebuiltin ( "XBMC.Notification(Using Urlresolver module.. - ,5000)" )
  import urlresolver
  IIoOoo0OO0 = urlresolver . HostedMediaFile ( url )
  if IIoOoo0OO0 :
   oO0O0Ooo = urlresolver . resolve ( url )
   O00O0Oo0 = oO0O0Ooo
 if O00O0Oo0 :
  if isinstance ( O00O0Oo0 , list ) :
   for I11Iii1 in O00O0Oo0 :
    iiIiIi1111iI1 = oO . getSetting ( 'quality' )
    if I11Iii1 [ 'quality' ] == 'HD' :
     oO0O0Ooo = I11Iii1 [ 'url' ]
     break
    elif I11Iii1 [ 'quality' ] == 'SD' :
     oO0O0Ooo = I11Iii1 [ 'url' ]
    elif I11Iii1 [ 'quality' ] == '1080p' and oO . getSetting ( '1080pquality' ) == 'true' :
     oO0O0Ooo = I11Iii1 [ 'url' ]
     break
  else :
   oO0O0Ooo = O00O0Oo0
 return oO0O0Ooo
 if 11 - 11: ii1IiI1i . ii1IiI1i + i11i * o0 . I1Ii111
def I1I1i1I1I1I1 ( name , mu_playlist , queueVideo = None ) :
 I1iiIi111I = xbmc . PlayList ( xbmc . PLAYLIST_VIDEO )
 if 34 - 34: i1iIi11iIIi1I * iII111i * I11i11Ii
 if '$$LSPlayOnlyOne$$' in mu_playlist [ 0 ] :
  mu_playlist [ 0 ] = mu_playlist [ 0 ] . replace ( '$$LSPlayOnlyOne$$' , '' )
  import urlparse
  Iioo0O00ooo0o = [ ]
  ii1 = 0
  Iiiiiii1 = xbmcgui . DialogProgress ( )
  Iiiiiii1 . create ( 'Progress' , 'Trying Multiple Links' )
  for ii in mu_playlist :
   if 26 - 26: I1Ii111 / iIii1I11I1II1 - iIii1I11I1II1
   if 57 - 57: I1Ii111
   if 41 - 41: iIii1I11I1II1 * IiII + I11i11Ii * i1 % I1Ii111 / I11i
   if OOoOO0oo0ooO in ii :
    if 63 - 63: i1IIi % i11iIiiIii % i11i * OoooooooOO
    iIiII1 = ii . split ( OOoOO0oo0ooO ) [ 1 ] . split ( '&regexs' ) [ 0 ]
    Iioo0O00ooo0o . append ( iIiII1 )
    if 47 - 47: Ii1I
    mu_playlist [ ii1 ] = ii . split ( OOoOO0oo0ooO ) [ 0 ] + ( '&regexs' + ii . split ( '&regexs' ) [ 1 ] if '&regexs' in ii else '' )
   else :
    iIiII1 = urlparse . urlparse ( ii ) . netloc
    if iIiII1 == '' :
     Iioo0O00ooo0o . append ( name )
    else :
     Iioo0O00ooo0o . append ( iIiII1 )
   oOOO00o000o = ii1
   ii1 += 1
   if 92 - 92: OoooooooOO % oOooOoO0Oo0O / o0 * o0 % i11iIiiIii / OoooooooOO
   IiII1ii111iI = Iioo0O00ooo0o [ oOOO00o000o ]
   if Iiiiiii1 . iscanceled ( ) : return
   Iiiiiii1 . update ( ii1 / len ( mu_playlist ) * 100 , "" , "Link#%d" % ( ii1 ) , IiII1ii111iI )
   print 'auto playnamexx' , IiII1ii111iI
   if "&mode=19" in mu_playlist [ oOOO00o000o ] :
    if 9 - 9: i1iIi11iIIi1I
    OOo = xbmcgui . ListItem ( IiII1ii111iI , iconImage = I1oO0oOOOooo , thumbnailImage = I1oO0oOOOooo )
    OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : IiII1ii111iI } )
    OOo . setProperty ( "IsPlayable" , "true" )
    II1i1i1I1iII = o00o ( mu_playlist [ oOOO00o000o ] . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    OOo . setPath ( II1i1i1I1iII )
    if 48 - 48: I11i . I11i + i11iIiiIii + ii1IiI1i % O0
    O0000 = tryplay ( II1i1i1I1iII , OOo )
   elif "$doregex" in mu_playlist [ oOOO00o000o ] :
    if 32 - 32: o0
    I1I = mu_playlist [ oOOO00o000o ] . split ( '&regexs=' )
    if 53 - 53: o0
    O0O0Oooo0o , II1 = OoO0o0000O ( I1I [ 1 ] , I1I [ 0 ] )
    o0oo0OO = O0O0Oooo0o . replace ( ';' , '' )
    OOo = xbmcgui . ListItem ( IiII1ii111iI , iconImage = I1oO0oOOOooo , thumbnailImage = I1oO0oOOOooo )
    OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : IiII1ii111iI } )
    OOo . setProperty ( "IsPlayable" , "true" )
    OOo . setPath ( o0oo0OO )
    if 17 - 17: o00O0oo + ii1IiI1i * i11iIiiIii
    O0000 = tryplay ( o0oo0OO , OOo )
    if 82 - 82: I1Ii111
   else :
    O0O0Oooo0o = mu_playlist [ oOOO00o000o ]
    O0O0Oooo0o = O0O0Oooo0o . split ( '&regexs=' ) [ 0 ]
    OOo = xbmcgui . ListItem ( IiII1ii111iI , iconImage = I1oO0oOOOooo , thumbnailImage = I1oO0oOOOooo )
    OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : IiII1ii111iI } )
    OOo . setProperty ( "IsPlayable" , "true" )
    OOo . setPath ( O0O0Oooo0o )
    if 51 - 51: OOooOOo % i1iIi11iIIi1I + i1 + iII111i - OoooooooOO . i1iIi11iIIi1I
    O0000 = tryplay ( O0O0Oooo0o , OOo )
    print 'played' , O0000
   print 'played' , O0000
   if O0000 : return
  return
 if oO . getSetting ( 'ask_playlist_items' ) == 'true' and not queueVideo :
  import urlparse
  Iioo0O00ooo0o = [ ]
  ii1 = 0
  for ii in mu_playlist :
   if 18 - 18: I11i11Ii - I11i * i11i + OOooOOo
   if OOoOO0oo0ooO in ii :
    if 93 - 93: IiII * OOooOOo . i1iIi11iIIi1I - iII111i + O0 * i1iIi11iIIi1I
    iIiII1 = ii . split ( OOoOO0oo0ooO ) [ 1 ] . split ( '&regexs' ) [ 0 ]
    Iioo0O00ooo0o . append ( iIiII1 )
    if 59 - 59: i11i
    mu_playlist [ ii1 ] = ii . split ( OOoOO0oo0ooO ) [ 0 ] + ( '&regexs' + ii . split ( '&regexs' ) [ 1 ] if '&regexs' in ii else '' )
   else :
    iIiII1 = urlparse . urlparse ( ii ) . netloc
    if iIiII1 == '' :
     Iioo0O00ooo0o . append ( name )
    else :
     Iioo0O00ooo0o . append ( iIiII1 )
     if 43 - 43: I11i11Ii + OoooooooOO
   ii1 += 1
  I11iiI1i1 = xbmcgui . Dialog ( )
  if 47 - 47: o00O0oo
  oOOO00o000o = I11iiI1i1 . select ( II111ii1II1i , Iioo0O00ooo0o )
  if oOOO00o000o >= 0 :
   IiII1ii111iI = Iioo0O00ooo0o [ oOOO00o000o ]
   print 'playnamexx' , IiII1ii111iI
   if "&mode=19" in mu_playlist [ oOOO00o000o ] :
    if 92 - 92: Ii1I % i11iIiiIii % I11i11Ii
    OOo = xbmcgui . ListItem ( IiII1ii111iI , iconImage = I1oO0oOOOooo , thumbnailImage = I1oO0oOOOooo )
    OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : IiII1ii111iI } )
    OOo . setProperty ( "IsPlayable" , "true" )
    II1i1i1I1iII = o00o ( mu_playlist [ oOOO00o000o ] . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    OOo . setPath ( II1i1i1I1iII )
    xbmc . Player ( ) . play ( II1i1i1I1iII , OOo )
   elif "$doregex" in mu_playlist [ oOOO00o000o ] :
    if 23 - 23: i11i * IiII
    I1I = mu_playlist [ oOOO00o000o ] . split ( '&regexs=' )
    if 80 - 80: ooOoO0o / i11iIiiIii + OoooooooOO
    O0O0Oooo0o , II1 = OoO0o0000O ( I1I [ 1 ] , I1I [ 0 ] )
    o0oo0OO = O0O0Oooo0o . replace ( ';' , '' )
    OOo = xbmcgui . ListItem ( IiII1ii111iI , iconImage = I1oO0oOOOooo , thumbnailImage = I1oO0oOOOooo )
    OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : IiII1ii111iI } )
    OOo . setProperty ( "IsPlayable" , "true" )
    OOo . setPath ( o0oo0OO )
    xbmc . Player ( ) . play ( o0oo0OO , OOo )
    if 38 - 38: ii1IiI1i % o00O0oo + i1IIi * OoooooooOO * OOooOOo
   else :
    O0O0Oooo0o = mu_playlist [ oOOO00o000o ]
    O0O0Oooo0o = O0O0Oooo0o . split ( '&regexs=' ) [ 0 ]
    OOo = xbmcgui . ListItem ( IiII1ii111iI , iconImage = I1oO0oOOOooo , thumbnailImage = I1oO0oOOOooo )
    OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : IiII1ii111iI } )
    OOo . setProperty ( "IsPlayable" , "true" )
    OOo . setPath ( O0O0Oooo0o )
    xbmc . Player ( ) . play ( O0O0Oooo0o , OOo )
 elif not queueVideo :
  if 83 - 83: iIii1I11I1II1 - o00O0oo - ooOoO0o / i1iIi11iIIi1I - O0
  I1iiIi111I . clear ( )
  i1i1IIIIIIIi = 0
  for ii in mu_playlist :
   i1i1IIIIIIIi += 1
   O00OoO0oo = xbmcgui . ListItem ( '%s) %s' % ( str ( i1i1IIIIIIIi ) , name ) )
   if 44 - 44: i11iIiiIii - ooOoO0o % I11i11Ii . Ii1I
   try :
    if "$doregex" in ii :
     I1I = ii . split ( '&regexs=' )
     if 14 - 14: I11i11Ii - I1Ii111 / i11i
     O0O0Oooo0o , II1 = OoO0o0000O ( I1I [ 1 ] , I1I [ 0 ] )
    elif "&mode=19" in ii :
     O0O0Oooo0o = o00o ( ii . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    if O0O0Oooo0o :
     I1iiIi111I . add ( O0O0Oooo0o , O00OoO0oo )
    else :
     raise
   except Exception :
    I1iiIi111I . add ( ii , O00OoO0oo )
    pass
    if 54 - 54: iII111i % iII111i
  xbmc . executebuiltin ( 'playlist.playoffset(video,0)' )
 else :
  if 66 - 66: OOooOOo * OOooOOo
  iII11ii1ii = xbmcgui . ListItem ( name )
  I1iiIi111I . add ( mu_playlist , iII11ii1ii )
  if 58 - 58: o0
def o0oOO ( name , url ) :
 if oO . getSetting ( 'save_location' ) == "" :
  if 84 - 84: i11iIiiIii + o00O0oo . O0
  xbmc . executebuiltin ( "XBMC.Notification('','Choose a location to save files.',15000," + oOO00Oo + ")" )
  oO . openSettings ( )
 I1I1 = { 'url' : url , 'download_path' : oO . getSetting ( 'save_location' ) }
 downloader . download ( name , I1I1 )
 I11iiI1i1 = xbmcgui . Dialog ( )
 if 69 - 69: ooOoO0o / OoooooooOO % i11iIiiIii
 oOOO0 = I11iiI1i1 . yesno ( '' , 'Do you want to add this file as a source?' )
 if oOOO0 :
  oooiIi1i ( os . path . join ( oO . getSetting ( 'save_location' ) , name ) )
  if 18 - 18: i11iIiiIii - o00O0oo * OOooOOo + i1
def IiiiIi1iiii11 ( name , url , mode , iconimage , fanart , description , genre , date , credits , showcontext = False , regexs = None , reg_url = None , allinfo = { } ) :
 if 27 - 27: oOooOoO0Oo0O * i11i - Ii1I
 if mode == 1 :
  Iii11i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 else :
  Iii11i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 oooOO0OO0O = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 OOo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if len ( allinfo ) < 1 :
  OOo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 else :
  OOo . setInfo ( type = "Video" , infoLabels = allinfo )
 OOo . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  Ii11I1I11II = [ ]
  if 43 - 43: OOooOOo + OoooooooOO . i1 . ii1IiI1i
  iIiII = ''
  iIiII = iIiII == "true"
  if 30 - 30: o00O0oo - i11iIiiIii + oOooOoO0Oo0O / I11i11Ii % O0
  oooooO00OOO = ''
  if 53 - 53: i11i
  if len ( oooooO00OOO ) > 0 :
   if iIiII :
    Ii11I1I11II . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   else :
    Ii11I1I11II . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 61 - 61: O0 * i1iIi11iIIi1I * oOooOoO0Oo0O % OoooooooOO / o0 % o00O0oo
  if showcontext == 'source' :
   if 43 - 43: OoooooooOO
   if name in str ( I1 ) :
    Ii11I1I11II . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 33 - 33: i11i - I1Ii111 - o00O0oo
    if 92 - 92: i1iIi11iIIi1I * I1Ii111
  elif showcontext == 'download' :
   Ii11I1I11II . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   Ii11I1I11II . append ( ( 'Remove from KelTec-Media-Play Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  if showcontext == '!!update' :
   ooo00o0OO = (
 '%s?url=%s&mode=17&regexs=%s'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( reg_url ) , regexs )
 )
   Ii11I1I11II . append ( ( '[COLOR orange]!!update[/COLOR]' , 'XBMC.RunPlugin(%s)' % ooo00o0OO ) )
  if not name in iiIiI :
   I1I11i = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if I1iiIi111I :
    I1I11i += 'playlist=' + urllib . quote_plus ( str ( I1iiIi111I ) . replace ( ',' , '||' ) )
   if regexs :
    I1I11i += "&regexs=" + regexs
    if 38 - 38: i11iIiiIii . iIii1I11I1II1 . I11i / i1iIi11iIIi1I
    if 18 - 18: I11i11Ii * ooOoO0o
  OOo . addContextMenuItems ( Ii11I1I11II )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Iii11i , listitem = OOo , isFolder = True )
 return oooOO0OO0O
 if 99 - 99: i11i * iIii1I11I1II1 % O0 * OOooOOo / i11i % OoooooooOO
def I1IiiiiI ( name , url , mode , iconimage , fanart , description , genre , date , credits , year , director , duration , premiered , studio , rate , originaltitle , country , rating , userrating , votes , aired , showcontext = False , reg_url = None , regexs = None , allinfo = { } ) :
 if 14 - 14: I1Ii111 . I1Ii111 % o00O0oo
 if mode == 1 :
  Iii11i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 else :
  Iii11i = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 oooOO0OO0O = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 OOo = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if len ( allinfo ) < 1 :
  OOo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "credits" : credits , "Year" : year , "Director" : director , "Duration" : duration , "Premiered" : premiered , "Studio" : studio , "Mpaa" : rate , "Originaltitle" : originaltitle , "Country" : country , "Rating" : rating , "Userrating" : userrating , "Votes" : votes , "Aired" : aired } )
 else :
  OOo . setInfo ( type = "Video" , infoLabels = allinfo )
 OOo . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  Ii11I1I11II = [ ]
  if 42 - 42: i1 . I11i - o00O0oo
  iIiII = ''
  iIiII = iIiII == "true"
  if 33 - 33: i11i / O0 / I1Ii111 - Ii1I - i1IIi
  oooooO00OOO = ''
  if 8 - 8: i11iIiiIii . IiII / iIii1I11I1II1 / ii1IiI1i / I1Ii111 - iII111i
  if len ( oooooO00OOO ) > 0 :
   if iIiII :
    Ii11I1I11II . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   else :
    Ii11I1I11II . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 32 - 32: i1 . i1IIi * I11i11Ii
  if showcontext == 'source' :
   if 98 - 98: iII111i - i11i / oOooOoO0Oo0O . OOooOOo * I1Ii111 . Ii1I
   if name in str ( I1 ) :
    Ii11I1I11II . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 25 - 25: i11iIiiIii / o0 - ooOoO0o / i1iIi11iIIi1I . i1 . i1
    if 6 - 6: OOooOOo . Ii1I
  elif showcontext == 'download' :
   Ii11I1I11II . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   Ii11I1I11II . append ( ( 'Remove from KelTec-Maedia-Play Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  if showcontext == '!!update' :
   ooo00o0OO = (
 '%s?url=%s&mode=17&regexs=%s'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( reg_url ) , regexs )
 )
   Ii11I1I11II . append ( ( '[COLOR orange]!!update[/COLOR]' , 'XBMC.RunPlugin(%s)' % ooo00o0OO ) )
  if not name in iiIiI :
   I1I11i = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if I1iiIi111I :
    I1I11i += 'playlist=' + urllib . quote_plus ( str ( I1iiIi111I ) . replace ( ',' , '||' ) )
   if regexs :
    I1I11i += "&regexs=" + regexs
    if 43 - 43: ii1IiI1i + i1
    if 50 - 50: OOooOOo % i1IIi * O0
  OOo . addContextMenuItems ( Ii11I1I11II )
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Iii11i , listitem = OOo , isFolder = True )
 return oooOO0OO0O
 if 4 - 4: iIii1I11I1II1 . i1IIi
def Oo00oo ( url , title , media_type = 'video' ) :
 if 79 - 79: ii1IiI1i / O0 % i1
 if 71 - 71: ooOoO0o / oOooOoO0Oo0O / O0
 import youtubedl
 if not url == '' :
  if media_type == 'audio' :
   youtubedl . single_YD ( url , download = True , audio = True )
  else :
   youtubedl . single_YD ( url , download = True )
 elif xbmc . Player ( ) . isPlaying ( ) == True :
  import YDStreamExtractor
  if YDStreamExtractor . isDownloading ( ) == True :
   if 19 - 19: i11iIiiIii . oOooOoO0Oo0O + i11i / I11i . ii1IiI1i * o00O0oo
   YDStreamExtractor . manageDownloads ( )
  else :
   oo0OOoooo0O0 = xbmc . Player ( ) . getPlayingFile ( )
   if 99 - 99: I11i11Ii + i11iIiiIii
   oo0OOoooo0O0 = oo0OOoooo0O0 . split ( '|User-Agent=' ) [ 0 ]
   O00OoO0oo = { 'url' : oo0OOoooo0O0 , 'title' : title , 'media_type' : media_type }
   youtubedl . single_YD ( '' , download = True , dl_info = O00OoO0oo )
 else :
  xbmc . executebuiltin ( "XBMC.Notification(DOWNLOAD,First Play [COLOR yellow]WHILE playing download[/COLOR] ,10000)" )
  if 36 - 36: iII111i * ooOoO0o * iIii1I11I1II1 - Ii1I % i11iIiiIii
def OoOo00O0o ( site_name , search_term = None ) :
 i1iIiIi1I = ''
 if os . path . exists ( O000OOo00oo ) == False or oO . getSetting ( 'clearseachhistory' ) == 'true' :
  i1iiIIiiiII ( O000OOo00oo , '' )
  oO . setSetting ( "clearseachhistory" , "false" )
 if site_name == 'history' :
  III = IiIIi1II1i ( O000OOo00oo )
  IiiIii = re . compile ( '(.+?):(.*?)(?:\r|\n)' ) . findall ( III )
  if 96 - 96: I1Ii111 * I1Ii111 % o00O0oo + i1
  for I1iIi1iIiiIiI , search_term in IiiIii :
   if 'plugin://' in search_term :
    iIiIIii ( search_term , I1iIi1iIiiIiI , i1iIiIi1I , '' , '' , '' , '' , '' , None , '' , total = int ( len ( IiiIii ) ) )
   else :
    I1IiiiiI ( I1iIi1iIiiIiI + ':' + search_term , I1iIi1iIiiIiI , 26 , oOO00Oo , i1iI11i1ii11 , '' , '' , '' , '' )
 if not search_term :
  OOii111IiiI1 = xbmc . Keyboard ( '' , 'Enter Search Term' )
  OOii111IiiI1 . doModal ( )
  if ( OOii111IiiI1 . isConfirmed ( ) == False ) :
   return
  search_term = OOii111IiiI1 . getText ( )
  if len ( search_term ) == 0 :
   return
 search_term = search_term . replace ( ' ' , '+' )
 search_term = search_term . encode ( 'utf-8' )
 if 'youtube' in site_name :
  if 27 - 27: I11i11Ii * o00O0oo + i11iIiiIii / oOooOoO0Oo0O - OOooOOo
  import _ytplist
  if 44 - 44: iII111i * o00O0oo / o0
  o0Oo0ooo = { }
  o0Oo0ooo = _ytplist . YoUTube ( 'searchYT' , youtube = search_term , max_page = 4 , nosave = 'nosave' )
  oOo0OoOOo0 = len ( o0Oo0ooo )
  for i1i1IIIIIIIi in o0Oo0ooo :
   try :
    I1iIi1iIiiIiI = o0Oo0ooo [ i1i1IIIIIIIi ] [ 'title' ]
    II1I1I1Ii = o0Oo0ooo [ i1i1IIIIIIIi ] [ 'date' ]
    try :
     oOOoo = o0Oo0ooo [ i1i1IIIIIIIi ] [ 'desc' ]
    except Exception :
     oOOoo = 'UNAVAIABLE'
     if 36 - 36: I11i * iII111i
    O0O0Oooo0o = 'plugin://plugin.video.youtube/play/?video_id=' + o0Oo0ooo [ i1i1IIIIIIIi ] [ 'url' ]
    i1iIiIi1I = 'http://img.youtube.com/vi/' + o0Oo0ooo [ i1i1IIIIIIIi ] [ 'url' ] + '/0.jpg'
    iIiIIii ( O0O0Oooo0o , I1iIi1iIiiIiI , i1iIiIi1I , '' , '' , '' , '' , '' , None , '' , oOo0OoOOo0 )
   except Exception :
    I1iI1iIi111i ( 'This item is ignored::' )
  i1iIi = site_name + ':' + search_term + '\n'
  i1iiIIiiiII ( os . path . join ( O0oOoOOOoOO , 'history' ) , i1iIi , append = True )
 elif 'dmotion' in site_name :
  i1II1iiI1iI = "https://api.dailymotion.com"
  if 69 - 69: ii1IiI1i . oOooOoO0Oo0O
  import _DMsearch
  III1IiIi1 = str ( oO . getSetting ( 'familyFilter' ) )
  _DMsearch . listVideos ( i1II1iiI1iI + "/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&search=" + search_term + "&sort=relevance&limit=100&family_filter=" + III1IiIi1 + "&localization=en_EN&page=1" )
  if 72 - 72: i1iIi11iIIi1I + i11iIiiIii + ii1IiI1i
  i1iIi = site_name + ':' + search_term + '\n'
  i1iiIIiiiII ( os . path . join ( O0oOoOOOoOO , 'history' ) , i1iIi , append = True )
 elif 'IMDBidplay' in site_name :
  i1II1iiI1iI = "http://www.omdbapi.com/?t="
  O0O0Oooo0o = i1II1iiI1iI + search_term
  if 96 - 96: OOooOOo % i1IIi / i1
  o0iIIIIi = dict ( { 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.3; rv:33.0) Gecko/20100101 Firefox/33.0' , 'Referer' : 'http://joker.org/' , 'Accept-Encoding' : 'gzip, deflate' , 'Content-Type' : 'application/json;charset=utf-8' , 'Accept' : 'application/json, text/plain, */*' } )
  if 13 - 13: i11i - I11i11Ii % i11iIiiIii + IiII
  ooo0 = requests . get ( O0O0Oooo0o , headers = o0iIIIIi )
  IiI111111IIII = ooo0 . json ( )
  ooOooOoo = IiI111111IIII [ 'Response' ]
  if ooOooOoo == 'True' :
   Oooo0Oo00o = IiI111111IIII [ 'imdbID' ]
   I1iIi1iIiiIiI = IiI111111IIII [ 'Title' ] + IiI111111IIII [ 'Released' ]
   I11iiI1i1 = xbmcgui . Dialog ( )
   oOOO0 = I11iiI1i1 . yesno ( 'Check Movie Title' , 'PLAY :: %s ?' % I1iIi1iIiiIiI )
   if oOOO0 :
    O0O0Oooo0o = 'plugin://plugin.video.pulsar/movie/' + Oooo0Oo00o + '/play'
    i1iIi = I1iIi1iIiiIiI + ':' + O0O0Oooo0o + '\n'
    i1iiIIiiiII ( O000OOo00oo , i1iIi , append = True )
    return O0O0Oooo0o
  else :
   if 32 - 32: o0 . iIii1I11I1II1 % OOooOOo . O0 . o0 / IiII
   xbmc . executebuiltin ( "XBMC.Notification(No IMDB match found ,7000," + oOO00Oo + ")" )
   if 45 - 45: iIii1I11I1II1
def I1I111IIIi1 ( string ) :
 if isinstance ( string , basestring ) :
  if isinstance ( string , unicode ) :
   string = string . encode ( 'ascii' , 'ignore' )
 return string
def oOOo00O0O0 ( string , encoding = 'utf-8' ) :
 if isinstance ( string , basestring ) :
  if not isinstance ( string , unicode ) :
   string = unicode ( string , encoding , 'ignore' )
 return string
def iiIIiiI ( s ) : return "" . join ( filter ( lambda O0oo0O0OO0Oo : ord ( O0oo0O0OO0Oo ) < 128 , s ) )
if 66 - 66: oOooOoO0Oo0O % iII111i % i11i
def o0OOOO ( command ) :
 IiI111111IIII = ''
 try :
  IiI111111IIII = xbmc . executeJSONRPC ( oOOo00O0O0 ( command ) )
 except UnicodeEncodeError :
  IiI111111IIII = xbmc . executeJSONRPC ( I1I111IIIi1 ( command ) )
  if 58 - 58: i1 % oOooOoO0Oo0O . oOooOoO0Oo0O * i1iIi11iIIi1I - I1Ii111 . OoooooooOO
 return oOOo00O0O0 ( IiI111111IIII )
 if 10 - 10: ooOoO0o
 if 48 - 48: IiII * i1IIi % OoooooooOO * iII111i * i1iIi11iIIi1I
def ii1iii1I1I ( ) :
 I1i = xbmc . getSkinDir ( )
 if I1i == 'skin.confluence' :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 elif I1i == 'skin.aeon.nox' :
  xbmc . executebuiltin ( 'Container.SetViewMode(511)' )
 else :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  if 77 - 77: ooOoO0o * I11i / o00O0oo + ii1IiI1i
  if 20 - 20: i11i + i1IIi
def IiII1i11III ( url ) :
 i1II1IIIII = oOOo00O0O0 ( '{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":["thumbnail","title","year","dateadded","fanart","rating","season","episode","studio"]},"id":1}' ) % url
 if 14 - 14: i1iIi11iIIi1I
 i1iIii = json . loads ( o0OOOO ( i1II1IIIII ) )
 for ii in i1iIii [ 'result' ] [ 'files' ] :
  url = ii [ 'file' ]
  I1iIi1iIiiIiI = iiIIiiI ( ii [ 'label' ] )
  i1iIiIi1I = iiIIiiI ( ii [ 'thumbnail' ] )
  try :
   o00o0 = iiIIiiI ( ii [ 'fanart' ] )
  except Exception :
   o00o0 = ''
  try :
   II1I1I1Ii = ii [ 'year' ]
  except Exception :
   II1I1I1Ii = ''
  try :
   O0o00I1IIi1iI1iiI = ii [ 'episode' ]
   iiI11I1ii11 = ii [ 'season' ]
   if O0o00I1IIi1iI1iiI == - 1 or iiI11I1ii11 == - 1 :
    oOOoo = ''
   else :
    oOOoo = '[COLOR yellow] S' + str ( iiI11I1ii11 ) + '[/COLOR][COLOR hotpink] E' + str ( O0o00I1IIi1iI1iiI ) + '[/COLOR]'
  except Exception :
   oOOoo = ''
  try :
   ii1iiIiIII1ii = ii [ 'studio' ]
   if ii1iiIiIII1ii :
    oOOoo += '\n Studio:[COLOR steelblue] ' + ii1iiIiIII1ii [ 0 ] + '[/COLOR]'
  except Exception :
   ii1iiIiIII1ii = ''
   if 71 - 71: o00O0oo . ii1IiI1i * O0 - ooOoO0o - i11i
  if ii [ 'filetype' ] == 'file' :
   OOo00 ( url , I1iIi1iIiiIiI , i1iIiIi1I , o00o0 , oOOoo , '' , II1I1I1Ii , '' , None , '' , total = len ( i1iIii [ 'result' ] [ 'files' ] ) )
   if 5 - 5: i1
   if 66 - 66: IiII / i11iIiiIii * O0
  else :
   IiiiIi1iiii11 ( I1iIi1iIiiIiI , url , 53 , i1iIiIi1I , o00o0 , oOOoo , '' , II1I1I1Ii , '' )
   if 78 - 78: I1Ii111 - Ii1I % O0 - I11i % i1iIi11iIIi1I
   if 43 - 43: i1iIi11iIIi1I
def OOo00 ( url , name , iconimage , fanart , description , genre , date , showcontext , playlist , regexs , total , setCookie = "" , allinfo = { } ) :
 if 90 - 90: OoooooooOO + O0 + ii1IiI1i / Ii1I / iII111i * ii1IiI1i
 Ii11I1I11II = [ ]
 iIiII = oO . getSetting ( 'parentalblocked' )
 iIiII = iIiII == "true"
 oooooO00OOO = oO . getSetting ( 'parentalblockedpin' )
 if 100 - 100: Ii1I
 if len ( oooooO00OOO ) > 0 :
  if iIiII :
   Ii11I1I11II . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  else :
   Ii11I1I11II . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 82 - 82: iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oooOO0OO0O = True
 iIiiII = False
 if regexs :
  iII1I = '17'
  if 'listrepeat' in regexs :
   iIiiII = True
   if 92 - 92: ooOoO0o % iII111i
   if 30 - 30: i11i - i1 % ooOoO0o . Ii1I
  Ii11I1I11II . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif ( any ( x in url for x in o0oo0oOo ) and url . startswith ( 'http' ) ) or url . endswith ( '&mode=19' ) :
  url = url . replace ( '&mode=19' , '' )
  iII1I = '19'
  if 63 - 63: iIii1I11I1II1 / o00O0oo
  Ii11I1I11II . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  iII1I = '18'
  Ii11I1I11II . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if oO . getSetting ( 'dlaudioonly' ) == 'true' :
   Ii11I1I11II . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
   if 24 - 24: I11i11Ii / iIii1I11I1II1 % I11i * o0 - iIii1I11I1II1
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
   if 50 - 50: i11i
  url = 'plugin://plugin.video.elementum/play?uri=' + url
  iII1I = '12'
 else :
  iII1I = '12'
  if 39 - 39: i11i . o0 - I11i11Ii * i1IIi . OoooooooOO
  Ii11I1I11II . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 if 'plugin://plugin.video.youtube/play/?video_id=' in url :
  iIIiI = url . replace ( 'plugin://plugin.video.youtube/play/?video_id=' , 'https://www.youtube.com/watch?v=' )
  Ii11I1I11II . append ( ( '!!Download [COLOR blue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( iIIiI ) , urllib . quote_plus ( name ) ) ) )
 Iii11i = sys . argv [ 0 ] + "?"
 O0O0O0OO00oo = False
 if playlist :
  if oO . getSetting ( 'add_playlist' ) == "false" and '$$LSPlayOnlyOne$$' not in playlist [ 0 ] :
   Iii11i += "url=" + urllib . quote_plus ( url ) + "&mode=" + iII1I
  else :
   Iii11i += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR orange] (' + str ( len ( playlist ) ) + ' itens)[/COLOR]'
   O0O0O0OO00oo = True
 else :
  Iii11i += "url=" + urllib . quote_plus ( url ) + "&mode=" + iII1I
 if regexs :
  Iii11i += "&regexs=" + regexs
 if not setCookie == '' :
  Iii11i += "&setCookie=" + urllib . quote_plus ( setCookie )
 if iconimage and not iconimage == '' :
  Iii11i += "&iconimage=" + urllib . quote_plus ( iconimage )
  if 39 - 39: I1Ii111 % o0 * ii1IiI1i - OoooooooOO - I11i11Ii
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 OOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 if 75 - 75: i11iIiiIii . o00O0oo % i1IIi . oOooOoO0Oo0O - OOooOOo + I11i11Ii
 if allinfo == None or len ( allinfo ) < 1 :
  OOo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 else :
  OOo . setInfo ( type = "Video" , infoLabels = allinfo )
 OOo . setProperty ( "Fanart_Image" , fanart )
 if 66 - 66: OOooOOo % ii1IiI1i . i11i / o0 / i1iIi11iIIi1I
 if ( not O0O0O0OO00oo ) and not any ( x in url for x in o000O0o ) and not '$PLAYERPROXY$=' in url :
  if regexs :
   if 47 - 47: IiII + O0 / i11i * oOooOoO0Oo0O - OoooooooOO . iII111i
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) and 'listrepeat' not in urllib . unquote_plus ( regexs ) :
    if 28 - 28: OOooOOo . OOooOOo . iIii1I11I1II1 . I11i . ii1IiI1i * i11iIiiIii
    OOo . setProperty ( 'IsPlayable' , 'true' )
  else :
   OOo . setProperty ( 'IsPlayable' , 'true' )
 else :
  I1iI1iIi111i ( 'NOT setting isplayable' + url )
 if showcontext :
  if 72 - 72: Ii1I
  if showcontext == 'fav' :
   Ii11I1I11II . append (
 ( 'Remove CANAIS do Favoritos' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in iiIiI :
   try :
    I1I11i = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   except :
    I1I11i = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage . encode ( "utf-8" ) ) , urllib . quote_plus ( fanart . encode ( "utf-8" ) ) )
 )
   if playlist :
    I1I11i += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    I1I11i += "&regexs=" + regexs
    if 26 - 26: I1Ii111 % I11i11Ii
  OOo . addContextMenuItems ( Ii11I1I11II )
 try :
  if not playlist is None :
   if oO . getSetting ( 'add_playlist' ) == "false" :
    OoOOoo = name . split ( ') ' ) [ 1 ]
    II1ii1 = [
 ( 'Play ' + OoOOoo + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( OoOOoo ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
    OOo . addContextMenuItems ( II1ii1 )
 except : pass
 if 34 - 34: o0 - OOooOOo * OoooooooOO
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Iii11i , listitem = OOo , totalItems = total , isFolder = iIiiII )
 if 5 - 5: i11iIiiIii * IiII - iII111i - ii1IiI1i - i1IIi + IiII
 if 4 - 4: o00O0oo + O0 . i1IIi * ii1IiI1i - i1
 return oooOO0OO0O
 if 42 - 42: i1 * o0 . i1iIi11iIIi1I - IiII / i11i
def iIiIIii ( url , name , iconimage , fanart , description , genre , date , year , director , duration , premiered , studio , rate , originaltitle , country , rating , userrating , votes , aired , showcontext , playlist , regexs , total , setCookie = "" , allinfo = { } ) :
 if 25 - 25: I11i11Ii % o0
 Ii11I1I11II = [ ]
 iIiII = oO . getSetting ( 'parentalblocked' )
 iIiII = iIiII == "true"
 oooooO00OOO = oO . getSetting ( 'parentalblockedpin' )
 if 75 - 75: i1IIi
 if len ( oooooO00OOO ) > 0 :
  if iIiII :
   Ii11I1I11II . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  else :
   Ii11I1I11II . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 74 - 74: I11i11Ii + ooOoO0o - OOooOOo - i1iIi11iIIi1I + IiII - iIii1I11I1II1
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 oooOO0OO0O = True
 iIiiII = False
 if regexs :
  iII1I = '17'
  if 'listrepeat' in regexs :
   iIiiII = True
   if 54 - 54: ii1IiI1i + i11i . oOooOoO0Oo0O / i1iIi11iIIi1I . o00O0oo
   if 58 - 58: I1Ii111 % i11iIiiIii * i11i . ii1IiI1i
  Ii11I1I11II . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif ( any ( x in url for x in o0oo0oOo ) and url . startswith ( 'http' ) ) or url . endswith ( '&mode=19' ) :
  url = url . replace ( '&mode=19' , '' )
  iII1I = '19'
  if 94 - 94: i11iIiiIii . I11i + iIii1I11I1II1 * ooOoO0o * ooOoO0o
  Ii11I1I11II . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  iII1I = '18'
  Ii11I1I11II . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if oO . getSetting ( 'dlaudioonly' ) == 'true' :
   Ii11I1I11II . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
   if 36 - 36: Ii1I - I1Ii111 . I1Ii111
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
   if 60 - 60: i11iIiiIii * I11i11Ii % i1iIi11iIIi1I + i1iIi11iIIi1I
  url = 'plugin://plugin.video.elementum/play?uri=' + url
  iII1I = '12'
 else :
  iII1I = '12'
  if 84 - 84: iIii1I11I1II1 + OoooooooOO
  Ii11I1I11II . append ( ( o0OOoo0OO0OOO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 if 'plugin://plugin.video.youtube/play/?video_id=' in url :
  iIIiI = url . replace ( 'plugin://plugin.video.youtube/play/?video_id=' , 'https://www.youtube.com/watch?v=' )
  Ii11I1I11II . append ( ( '!!Download [COLOR blue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( iIIiI ) , urllib . quote_plus ( name ) ) ) )
 Iii11i = sys . argv [ 0 ] + "?"
 O0O0O0OO00oo = False
 if playlist :
  if oO . getSetting ( 'add_playlist' ) == "false" and '$$LSPlayOnlyOne$$' not in playlist [ 0 ] :
   Iii11i += "url=" + urllib . quote_plus ( url ) + "&mode=" + iII1I
  else :
   Iii11i += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR orange] (' + str ( len ( playlist ) ) + ' itens)[/COLOR]'
   O0O0O0OO00oo = True
 else :
  Iii11i += "url=" + urllib . quote_plus ( url ) + "&mode=" + iII1I
 if regexs :
  Iii11i += "&regexs=" + regexs
 if not setCookie == '' :
  Iii11i += "&setCookie=" + urllib . quote_plus ( setCookie )
 if iconimage and not iconimage == '' :
  Iii11i += "&iconimage=" + urllib . quote_plus ( iconimage )
  if 77 - 77: O0 * ii1IiI1i * OOooOOo + i1iIi11iIIi1I + ii1IiI1i - ooOoO0o
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 OOo = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 if 10 - 10: ii1IiI1i + I1Ii111
 if allinfo == None or len ( allinfo ) < 1 :
  OOo . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "Year" : year , "Director" : director , "Duration" : duration , "Premiered" : premiered , "Studio" : studio , "Mpaa" : rate , "Originaltitle" : originaltitle , "Country" : country , "Rating" : rating , "Userrating" : userrating , "Votes" : votes , "Aired" : aired } )
 else :
  OOo . setInfo ( type = "Video" , infoLabels = allinfo )
 OOo . setProperty ( "Fanart_Image" , fanart )
 if 58 - 58: oOooOoO0Oo0O + OoooooooOO / IiII . o00O0oo % i1 / ii1IiI1i
 if ( not O0O0O0OO00oo ) and not any ( x in url for x in o000O0o ) and not '$PLAYERPROXY$=' in url :
  if regexs :
   if 62 - 62: i11i
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) and 'listrepeat' not in urllib . unquote_plus ( regexs ) :
    if 12 - 12: I1Ii111 + i11i
    OOo . setProperty ( 'IsPlayable' , 'true' )
  else :
   OOo . setProperty ( 'IsPlayable' , 'true' )
 else :
  I1iI1iIi111i ( 'NOT setting isplayable' + url )
 if showcontext :
  if 92 - 92: ooOoO0o % iIii1I11I1II1 - IiII / i11iIiiIii % o00O0oo * i1
  if showcontext == 'fav' :
   Ii11I1I11II . append (
 ( 'Remove CANAIS do Favoritos' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in iiIiI :
   try :
    I1I11i = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   except :
    I1I11i = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage . encode ( "utf-8" ) ) , urllib . quote_plus ( fanart . encode ( "utf-8" ) ) )
 )
   if playlist :
    I1I11i += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    I1I11i += "&regexs=" + regexs
    if 80 - 80: IiII
  OOo . addContextMenuItems ( Ii11I1I11II )
 try :
  if not playlist is None :
   if oO . getSetting ( 'add_playlist' ) == "false" :
    OoOOoo = name . split ( ') ' ) [ 1 ]
    II1ii1 = [
 ( 'Play ' + OoOOoo + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( OoOOoo ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
    OOo . addContextMenuItems ( II1ii1 )
 except : pass
 if 3 - 3: ii1IiI1i * Ii1I
 oooOO0OO0O = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = Iii11i , listitem = OOo , totalItems = total , isFolder = iIiiII )
 if 53 - 53: iIii1I11I1II1 / IiII % i1iIi11iIIi1I + I1Ii111 / o00O0oo
 if 74 - 74: I11i11Ii
 return oooOO0OO0O
 if 8 - 8: oOooOoO0Oo0O % i11i - i1 - Ii1I % oOooOoO0Oo0O
def o0o0O0oOooO00 ( url , name , iconimage , setresolved = True ) :
 if setresolved :
  OOo = xbmcgui . ListItem ( name , iconImage = iconimage )
  OOo . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
  OOo . setProperty ( "IsPlayable" , "true" )
  OOo . setPath ( str ( url ) )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , OOo )
 else :
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + url + ')' )
  if 27 - 27: IiII
  if 74 - 74: I1Ii111 / o00O0oo
  if 86 - 86: O0 . i1IIi - i1iIi11iIIi1I / I11i11Ii / ii1IiI1i
  if 64 - 64: OoooooooOO - i1IIi / i11i
def O0Ooo ( link ) :
 O0O0Oooo0o = urllib . urlopen ( link )
 IIIii1 = O0O0Oooo0o . read ( )
 O0O0Oooo0o . close ( )
 ooOoOoo000O0O = IIIii1 . split ( "Jetzt" )
 iI11i = ooOoOoo000O0O [ 1 ] . split ( 'programm/detail.php?const_id=' )
 oOOO0I1iIIi = iI11i [ 1 ] . split ( '<br /><a href="/' )
 IIiIi11i111II = oOOO0I1iIIi [ 0 ] [ 40 : len ( oOOO0I1iIIi [ 0 ] ) ]
 ooO0Iii11ii1iIIi = iI11i [ 2 ] . split ( "</a></p></div>" )
 iiii1Ii1iii = ooO0Iii11ii1iIIi [ 0 ] [ 17 : len ( ooO0Iii11ii1iIIi [ 0 ] ) ]
 iiii1Ii1iii = iiii1Ii1iii . encode ( 'utf-8' )
 return "  - " + iiii1Ii1iii + " - " + IIiIi11i111II
 if 73 - 73: i11iIiiIii + OOooOOo % Ii1I . OoooooooOO % OOooOOo
 if 32 - 32: i11iIiiIii - i11i
def ooO0000o00O ( url , regex ) :
 IiI111111IIII = iI1i11II1i ( url )
 try :
  i1i1IIIIIIIi = re . findall ( regex , IiI111111IIII ) [ 0 ]
  return i1i1IIIIIIIi
 except :
  I1iI1iIi111i ( 'regex failed' )
  I1iI1iIi111i ( regex )
  return
  if 21 - 21: o0 - i11i
  if 10 - 10: o0 - i1 * i11iIiiIii / I11i11Ii + i1 + iIii1I11I1II1
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 23 - 23: i1IIi + ii1IiI1i + oOooOoO0Oo0O - o00O0oo % OoooooooOO . I1Ii111
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_UNSORTED )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_LABEL )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_DATE )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_GENRE )
except :
 pass
 if 49 - 49: OOooOOo . o0
I1I1 = Iii1Iiii ( )
if 73 - 73: iII111i / oOooOoO0Oo0O / OoooooooOO + oOooOoO0Oo0O
O0O0Oooo0o = None
I1iIi1iIiiIiI = None
iII1I = None
I1iiIi111I = None
I1oO0oOOOooo = None
o00o0 = i1iI11i1ii11
I1iiIi111I = None
o0OoOo0O00 = None
o0oOoO0O = None
if 9 - 9: I11i
try :
 O0O0Oooo0o = urllib . unquote_plus ( I1I1 [ "url" ] ) . decode ( 'utf-8' )
except :
 pass
try :
 I1iIi1iIiiIiI = urllib . unquote_plus ( I1I1 [ "name" ] )
except :
 pass
try :
 I1oO0oOOOooo = urllib . unquote_plus ( I1I1 [ "iconimage" ] )
except :
 pass
try :
 o00o0 = urllib . unquote_plus ( I1I1 [ "fanart" ] )
except :
 pass
try :
 iII1I = int ( I1I1 [ "mode" ] )
except :
 pass
try :
 I1iiIi111I = eval ( urllib . unquote_plus ( I1I1 [ "playlist" ] ) . replace ( '||' , ',' ) )
except :
 pass
try :
 o0OoOo0O00 = int ( I1I1 [ "fav_mode" ] )
except :
 pass
try :
 o0oOoO0O = I1I1 [ "regexs" ]
except :
 pass
 if 38 - 38: Ii1I . i1iIi11iIIi1I . i11iIiiIii * OoooooooOO + IiII
I1iI1iIi111i ( "Mode: " + str ( iII1I ) )
if not O0O0Oooo0o is None :
 I1iI1iIi111i ( "URL: " + str ( O0O0Oooo0o . encode ( 'utf-8' ) ) )
I1iI1iIi111i ( "Name: " + str ( I1iIi1iIiiIiI ) )
if 49 - 49: I11i11Ii - i1iIi11iIIi1I / ooOoO0o / i1 % OOooOOo
if iII1I == None :
 I1iI1iIi111i ( "Index" )
 O00oO000O0O ( True )
 if 38 - 38: i1 . OOooOOo / i1 % i11i
elif iII1I == 1 :
 I1iI1iIi111i ( "getData" )
 IiI111111IIII = None
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if o0oOoO0O :
  IiI111111IIII = OoO0o0000O ( o0oOoO0O , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 47 - 47: Ii1I * iIii1I11I1II1 * IiII - i1iIi11iIIi1I . O0 . o00O0oo
 i1I ( O0O0Oooo0o , o00o0 , IiI111111IIII )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 32 - 32: i1 % oOooOoO0Oo0O
elif iII1I == 2 :
 I1iI1iIi111i ( "getChannelItems" )
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if o0oOoO0O :
  IiI111111IIII = OoO0o0000O ( o0oOoO0O , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 7 - 7: I11i11Ii . i1IIi - OOooOOo
 III1i1iI1 ( I1iIi1iIiiIiI , O0O0Oooo0o , o00o0 )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 93 - 93: I1Ii111 % ii1IiI1i
elif iII1I == 3 :
 I1iI1iIi111i ( "getSubChannelItems" )
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if o0oOoO0O :
  IiI111111IIII = OoO0o0000O ( o0oOoO0O , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 31 - 31: i11i + I11i - OoooooooOO . Ii1I
 Oo00OOo00O ( I1iIi1iIiiIiI , O0O0Oooo0o , o00o0 )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 28 - 28: iII111i . ii1IiI1i
elif iII1I == 4 :
 I1iI1iIi111i ( "getFavorites" )
 OOo00Oooo ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 77 - 77: ii1IiI1i % i11i
elif iII1I == 5 :
 I1iI1iIi111i ( "addFavorite" )
 try :
  I1iIi1iIiiIiI = I1iIi1iIiiIiI . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  I1iIi1iIiiIiI = I1iIi1iIiiIiI . split ( '  - ' ) [ 0 ]
 except :
  pass
 OoOO0o0o0 ( I1iIi1iIiiIiI , O0O0Oooo0o , I1oO0oOOOooo , o00o0 , o0OoOo0O00 )
 if 81 - 81: o0 % iII111i / O0 * iIii1I11I1II1 % I1Ii111 . oOooOoO0Oo0O
elif iII1I == 6 :
 I1iI1iIi111i ( "rmFavorite" )
 try :
  I1iIi1iIiiIiI = I1iIi1iIiiIiI . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  I1iIi1iIiiIiI = I1iIi1iIiiIiI . split ( '  - ' ) [ 0 ]
 except :
  pass
 OOOO00 ( I1iIi1iIiiIiI )
 if 90 - 90: i1
elif iII1I == 7 :
 I1iI1iIi111i ( "addSource" )
 oooiIi1i ( O0O0Oooo0o )
 if 44 - 44: i1 / ii1IiI1i . I11i11Ii + o0
elif iII1I == 8 :
 I1iI1iIi111i ( "rmSource" )
 OO0oOOoo ( I1iIi1iIiiIiI )
 if 32 - 32: I1Ii111 - o00O0oo * IiII * Ii1I
elif iII1I == 9 :
 I1iI1iIi111i ( "download_file" )
 o0oOO ( I1iIi1iIiiIiI , O0O0Oooo0o )
 if 84 - 84: iII111i + ii1IiI1i % oOooOoO0Oo0O + i11iIiiIii
elif iII1I == 10 :
 I1iI1iIi111i ( "getCommunitySources" )
 o00oOoOo0 ( )
 if 37 - 37: Ii1I % ii1IiI1i / o00O0oo
elif iII1I == 11 :
 I1iI1iIi111i ( "addSource" )
 oooiIi1i ( O0O0Oooo0o )
 if 94 - 94: Ii1I / i1iIi11iIIi1I . i1
elif iII1I == 12 :
 I1iI1iIi111i ( "setResolvedUrl" )
 if not O0O0Oooo0o . startswith ( "plugin://plugin" ) or not any ( x in O0O0Oooo0o for x in o000O0o ) :
  i1i1IIIIIIIi = xbmcgui . ListItem ( path = O0O0Oooo0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , i1i1IIIIIIIi )
 else :
  print 'Not setting setResolvedUrl'
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + O0O0Oooo0o + ')' )
  if 1 - 1: I11i11Ii . i11i
  if 93 - 93: i11i . i11iIiiIii + i11i % OOooOOo
elif iII1I == 13 :
 I1iI1iIi111i ( "play_playlist" )
 I1I1i1I1I1I1 ( I1iIi1iIiiIiI , I1iiIi111I )
 if 98 - 98: ooOoO0o * OOooOOo * o0 + iII111i * IiII
elif iII1I == 14 :
 I1iI1iIi111i ( "get_xml_database" )
 ooO0o ( O0O0Oooo0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 4 - 4: I1Ii111
elif iII1I == 15 :
 I1iI1iIi111i ( "browse_xml_database" )
 ooO0o ( O0O0Oooo0o , True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 16 - 16: iIii1I11I1II1 * IiII + OOooOOo . O0 . i1
elif iII1I == 16 :
 I1iI1iIi111i ( "browse_community" )
 o00oOoOo0 ( True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 99 - 99: i11iIiiIii - IiII
elif iII1I == 17 :
 I1iI1iIi111i ( "getRegexParsed" )
 O0O0Oooo0o , II1 = OoO0o0000O ( o0oOoO0O , O0O0Oooo0o )
 if O0O0Oooo0o :
  o0o0O0oOooO00 ( O0O0Oooo0o , I1iIi1iIiiIiI , I1oO0oOOOooo , II1 )
 else :
  if 85 - 85: ooOoO0o % ii1IiI1i
  xbmc . executebuiltin ( "XBMC.Notification(Failed to extract regex. - " + "this" + ",4000," + oOO00Oo + ")" )
elif iII1I == 18 :
 I1iI1iIi111i ( "youtubedl" )
 try :
  import youtubedl
 except Exception :
  if 95 - 95: i1iIi11iIIi1I * I11i * IiII . i1
  xbmc . executebuiltin ( "XBMC.Notification(Please [COLOR yellow]install the Youtube Addon[/COLOR] module ,10000," ")" )
 oOOo0OOOOo0Oo = youtubedl . single_YD ( O0O0Oooo0o )
 o0o0O0oOooO00 ( oOOo0OOOOo0Oo , I1iIi1iIiiIiI , I1oO0oOOOooo )
elif iII1I == 19 :
 I1iI1iIi111i ( "Genesiscommonresolvers" )
 o0o0O0oOooO00 ( o00o ( O0O0Oooo0o ) , I1iIi1iIiiIiI , I1oO0oOOOooo , True )
 if 73 - 73: i1iIi11iIIi1I
elif iII1I == 21 :
 I1iI1iIi111i ( "download current file using youtube-dl service" )
 Oo00oo ( '' , I1iIi1iIiiIiI , 'video' )
elif iII1I == 23 :
 I1iI1iIi111i ( "get info then download" )
 Oo00oo ( O0O0Oooo0o , I1iIi1iIiiIiI , 'video' )
elif iII1I == 24 :
 I1iI1iIi111i ( "Audio only youtube download" )
 Oo00oo ( O0O0Oooo0o , I1iIi1iIiiIiI , 'audio' )
elif iII1I == 25 :
 I1iI1iIi111i ( "YouTube/DMotion" )
 OoOo00O0o ( O0O0Oooo0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif iII1I == 26 :
 I1iI1iIi111i ( "YouTube/DMotion From Search History" )
 I1iIi1iIiiIiI = I1iIi1iIiiIiI . split ( ':' )
 OoOo00O0o ( O0O0Oooo0o , search_term = I1iIi1iIiiIiI [ 1 ] )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif iII1I == 27 :
 I1iI1iIi111i ( "Using IMDB id to play in Pulsar" )
 ii11iiII = OoOo00O0o ( O0O0Oooo0o )
 xbmc . Player ( ) . play ( ii11iiII )
elif iII1I == 30 :
 O0oOooo0OOooO ( I1iIi1iIiiIiI , O0O0Oooo0o , I1oO0oOOOooo , o00o0 )
 if 57 - 57: o0 - O0 . OoooooooOO % o00O0oo - iII111i
elif iII1I == 40 :
 oo0OOOoOo ( )
 ii1iii1I1I ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 79 - 79: O0 + Ii1I
elif iII1I == 41 :
 I1iI1iIi111i ( "puxarconf" )
 xbmcaddon . Addon ( ) . openSettings ( )
 xbmcgui . Dialog ( ) . ok ( '[B][COLOR red]AVISO IMPORTANTE![/COLOR][/B]' , '[B]POR FAVOR SAIR DO ADD-ON E ENTRE NOVAMENTE PARA ATUALIZAR AS CONFIGURAÇÕES[/B]' )
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 25 - 25: ooOoO0o - iII111i / O0 . OoooooooOO % oOooOoO0Oo0O . i1IIi
elif iII1I == 42 :
 I1iI1iIi111i ( "infoTORRENT" )
 if 19 - 19: i11i / i11i % ii1IiI1i + OOooOOo + OOooOOo + IiII
 if 4 - 4: i1 + Ii1I / IiII + i1IIi % i1 % IiII
 xbmcgui . Dialog ( ) . ok ( Ii1IOo0o0 , o0O ( oOO00oOO ) )
 if 80 - 80: iII111i
 if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
elif iII1I == 43 :
 O0OO ( True )
 if 59 - 59: ii1IiI1i + Ii1I . OOooOOo
if iII1I == 44 :
 IIOOOO0oo0 ( True )
 if 87 - 87: i1iIi11iIIi1I
elif iII1I == 53 :
 I1iI1iIi111i ( "Requesting JSON-RPC Items" )
 O0O0Oooo0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( O0O0Oooo0o , 'rot_13' ) ) )
 if o0oOoO0O :
  IiI111111IIII = OoO0o0000O ( o0oOoO0O , O0O0Oooo0o )
  O0O0Oooo0o = ''
  if 34 - 34: ooOoO0o . o0 / i11iIiiIii / IiII
 IiII1i11III ( O0O0Oooo0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 46 - 46: I11i11Ii + i11i * oOooOoO0Oo0O + I11i
elif iII1I == 54 :
 ooO ( True )
 if 31 - 31: iII111i * i1 * iII111i + i1iIi11iIIi1I * i1 . ooOoO0o
 if 89 - 89: OoooooooOO * iII111i * oOooOoO0Oo0O . o00O0oo * iII111i / IiII
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
