# -*- coding: utf-8 -*-
import urllib
import urllib2
import datetime
import re
import os
import base64
import codecs
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import traceback
import cookielib
import time
import xbmcgui
import xbmc
import xbmcplugin
import webbrowser
import os
import xbmcaddon
from BeautifulSoup import BeautifulStoneSoup , BeautifulSoup , BeautifulSOAP
if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
o0OO00 = None
try :
 from xml . sax . saxutils import escape
except : traceback . print_exc ( )
if 78 - 78: i11i . oOooOoO0Oo0O
try :
 import json
except :
 import simplejson as json
import SimpleDownloader as downloader
import time
import requests
iI1 = False
if 43 - 43: I11i11Ii
if 65 - 65: i1iIi11iIIi1I
Oo = "12.11.21"
if 2 - 2: o0 * i1 * ii1IiI1i % OOooOOo / I11i / Ii1I
if 48 - 48: iII111i % IiII + I1Ii111 / ooOoO0o * o00O0oo
if 97 - 97: Ii1I - ii1IiI1i . I1Ii111 - OoooooooOO
oO0o = 'aHR0cHM6Ly9hcG9sbG8tYXJxdWl2b3MubWwvQVBPTExPL0JBU0UtUFJJTkNJUEFML0Jhc2UtUHJpbmNpcGFsLmh0bWw='
IIII = base64 . b64decode ( oO0o )
if 59 - 59: i1IIi * i1IIi % I11i + i11i
if 32 - 32: o0 . o00O0oo * i1IIi . ooOoO0o / I1Ii111
o00 = "\x68\x74\x74\x70\x73\x3a\x2f\x2f\x67\x69\x74\x6c\x61\x62\x2e\x63\x6f\x6d\x2f\x73\x69\x6c\x76\x61\x64\x65\x69\x76\x69\x73\x6f\x6e\x35\x36\x36\x2f\x67\x69\x74\x70\x6c\x61\x79\x2f\x2d\x2f\x72\x61\x77\x2f\x6d\x61\x73\x74\x65\x72\x2f\x52\x45\x47\x45\x58\x2e\x52\x45\x44"
if 62 - 62: i11iIiiIii - i11i % ooOoO0o - iIii1I11I1II1 . ii1IiI1i . i11i
if 61 - 61: OOooOOo / o0 / IiII * i1iIi11iIIi1I . i11i
Ii1IIii11 = '[COLOR orange][B]->[/COLOR][/B][COLOR deepskyblue][B] BEM-VINDOS[/COLOR][/B]'
if 55 - 55: iIii1I11I1II1 - oOooOoO0Oo0O . iII111i * I1Ii111 * i1IIi / iIii1I11I1II1
if 79 - 79: OOooOOo + ooOoO0o . o00O0oo * I1Ii111 % Ii1I . oOooOoO0Oo0O
if 94 - 94: IiII * iII111i / I1Ii111 . i1IIi * IiII
iiiii11iII1 = '-> BAIXE E INSTALE!'
if 54 - 54: o00O0oo . o00O0oo / iIii1I11I1II1 / Ii1I + OOooOOo / i1
if 39 - 39: Ii1I / ooOoO0o . Ii1I - Ii1I
if 68 - 68: I11i . oOooOoO0Oo0O / IiII
if 72 - 72: i1iIi11iIIi1I / i1iIi11iIIi1I
i111IiI = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3LzJQTk4xUGpL'
iIIIIiI = base64 . b64decode ( i111IiI )
if 91 - 91: O0 / OOooOOo - IiII + I11i % i1IIi
if 20 - 20: i1IIi
if 48 - 48: i1iIi11iIIi1I . OoooooooOO - o0 % I11i / iII111i . iII111i
if 11 - 11: o00O0oo / O0 - i1IIi
if 85 - 85: I11i % ii1IiI1i * o00O0oo
OO0O00OooO = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3BYR2gyckVu'
OoooooOoo = base64 . b64decode ( OO0O00OooO )
if 70 - 70: i1iIi11iIIi1I . i1iIi11iIIi1I - i1iIi11iIIi1I / ii1IiI1i * I11i
if 86 - 86: i11iIiiIii + iII111i + o00O0oo * Ii1I + i1
if 61 - 61: i1iIi11iIIi1I / i11iIiiIii
IiIiIi = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L1hDdDl6clRm'
II = base64 . b64decode ( IiIiIi )
if 14 - 14: I11i11Ii . oOooOoO0Oo0O / iII111i
if 38 - 38: i11i % i11iIiiIii . o00O0oo - I11i + iII111i
Ooooo0Oo00oO0 = 3000
if 12 - 12: iIii1I11I1II1 * oOooOoO0Oo0O . o00O0oo % Ii1I + O0
if 70 - 70: iII111i . OOooOOo * o00O0oo . iII111i
if 35 - 35: i1 + IiII + IiII
if 11 - 11: IiII - i1iIi11iIIi1I % o00O0oo % IiII / o0 - i1iIi11iIIi1I
if 74 - 74: IiII * O0
oOOo0oo = 'aHR0cHM6Ly91cmxwbGF5LmNvbS9OMHJkTEI='
o0oo0o0O00OO = base64 . b64decode ( oOOo0oo )
if 80 - 80: i1IIi
if 70 - 70: o0 - i1
if 43 - 43: Ii1I / i11i / OoooooooOO . i1 . iII111i
if 19 - 19: Ii1I + o00O0oo
ooo = 'ǭq�{���}���w���'
if 18 - 18: i1
if 28 - 28: I11i - I1Ii111 . I1Ii111 + o0 - OoooooooOO + O0
if 95 - 95: i1iIi11iIIi1I % OOooOOo . O0
I1i1I = 'TORRENT'
oOO00oOO = 'https://i.imgur.com/OKPqt3k.png'
OoOo = 'https://i.imgur.com/By1pLrx.jpg'
if 18 - 18: i11iIiiIii
Ii11I = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JVYk5CWlFB'
OOO0OOO00oo = base64 . b64decode ( Ii11I )
if 31 - 31: i11i - I11i . ooOoO0o % o0 - O0
iii11 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L0JVYk5CWlFB'
O0oo0OO0oOOOo = base64 . b64decode ( iii11 )
if 35 - 35: I1Ii111 % oOooOoO0Oo0O
if 70 - 70: IiII * ii1IiI1i
if 46 - 46: o00O0oo / i1iIi11iIIi1I
if 52 - 52: i1 - OoooooooOO + iII111i + iII111i - i1 / ooOoO0o
I1I = '[COLOR white]Selecione um item:[/COLOR]'
if 24 - 24: ii1IiI1i
o0Oo0O0Oo00oO = '[COLOR white]!!Download em execução!![/COLOR]'
I11i1I1I = '!!Download [COLOR seablue]Audio!![/COLOR]'
if 83 - 83: ii1IiI1i / o00O0oo
if 49 - 49: i1
if 35 - 35: o0 - OoooooooOO / ii1IiI1i % i1IIi
o00OO00OoO = '[COLOR deepskyblue][B] CHECAR POR ATUALIZAÇÃO[/COLOR][/B]'
OOOO0OOoO0O0 = 'https://i.imgur.com/22LSvnr.png'
O0Oo000ooO00 = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L2E5dE1DMEh1'
oO0 = base64 . b64decode ( O0Oo000ooO00 )
if 45 - 45: i11iIiiIii * i11i % iIii1I11I1II1 + ii1IiI1i - iII111i
if 17 - 17: I1Ii111
if 62 - 62: iIii1I11I1II1 * o0
i1OOO = 'BEM-VINDOS'
Oo0oOOo = 'aHR0cHM6Ly9wYXN0ZWJpbi5jb20vcmF3L3F0NmhqV0VY'
Oo0OoO00oOO0o = 'https://i.imgur.com/fHRcl7O.png'
OOO00O = 'https://i.imgur.com/Y4QXRab.jpg'
OOoOO0oo0ooO = base64 . b64decode ( Oo0oOOo )
if 98 - 98: IiII * IiII / IiII + Ii1I
if 34 - 34: o00O0oo
if 15 - 15: Ii1I * o00O0oo * I11i11Ii % i11iIiiIii % o0 - I11i
O0ooo0O0oo0 = '$texto='
oo0oOo = 'orange'
o000O0o = 'itens'
if 42 - 42: o0
if 41 - 41: I11i11Ii . o00O0oo + O0 * i1 % I11i11Ii * I11i11Ii
__addon__ = xbmcaddon . Addon ( )
__addonname__ = __addon__ . getAddonInfo ( 'name' )
__icon__ = __addon__ . getAddonInfo ( 'icon' )
if 19 - 19: IiII
if 46 - 46: ii1IiI1i - iII111i . iIii1I11I1II1 / ii1IiI1i
Ii1i = [ '180upload.com' , 'allmyvideos.net' , 'bestreams.net' , 'clicknupload.com' , 'cloudzilla.to' , 'movshare.net' , 'novamov.com' , 'nowvideo.sx' , 'videoweed.es' , 'daclips.in' , 'datemule.com' , 'fastvideo.in' , 'faststream.in' , 'filehoot.com' , 'filenuke.com' , 'sharesix.com' , 'docs.google.com' , 'plus.google.com' , 'picasaweb.google.com' , 'gorillavid.com' , 'gorillavid.in' , 'grifthost.com' , 'hugefiles.net' , 'ipithos.to' , 'ishared.eu' , 'kingfiles.net' , 'mail.ru' , 'my.mail.ru' , 'videoapi.my.mail.ru' , 'mightyupload.com' , 'mooshare.biz' , 'movdivx.com' , 'movpod.net' , 'movpod.in' , 'movreel.com' , 'mrfile.me' , 'nosvideo.com' , 'openload.io' , 'played.to' , 'bitshare.com' , 'filefactory.com' , 'k2s.cc' , 'oboom.com' , 'rapidgator.net' , 'uploaded.net' , 'primeshare.tv' , 'bitshare.com' , 'filefactory.com' , 'k2s.cc' , 'oboom.com' , 'rapidgator.net' , 'uploaded.net' , 'sharerepo.com' , 'stagevu.com' , 'streamcloud.eu' , 'streamin.to' , 'thefile.me' , 'thevideo.me' , 'tusfiles.net' , 'uploadc.com' , 'zalaa.com' , 'uploadrocket.net' , 'uptobox.com' , 'v-vids.com' , 'veehd.com' , 'vidbull.com' , 'videomega.tv' , 'vidplay.net' , 'vidspot.net' , 'vidto.me' , 'vidzi.tv' , 'vimeo.com' , 'vk.com' , 'vodlocker.com' , 'xfileload.com' , 'xvidstage.com' , 'zettahost.tv' ]
I1 = [ 'plugin.video.dramasonline' , 'plugin.video.f4mTester' , 'plugin.video.shahidmbcnet' , 'plugin.video.SportsDevil' , 'plugin.stream.vaughnlive.tv' , 'plugin.video.ZemTV-shani' ]
if 15 - 15: i11i
class Ii ( urllib2 . HTTPErrorProcessor ) :
 def http_response ( self , request , response ) :
  return response
 https_response = http_response
 if 79 - 79: OoooooooOO / O0
OO0OoO0o00 = False ;
if OO0OoO0o00 :
 if 53 - 53: O0 * i1iIi11iIIi1I + I11i
 if 50 - 50: O0 . O0 - OOooOOo / oOooOoO0Oo0O - i1 * o0
 try :
  import pysrc . pydevd as pydevd
  if 61 - 61: Ii1I
  pydevd . settrace ( 'localhost' , stdoutToServer = True , stderrToServer = True )
 except ImportError :
  sys . stderr . write ( "Error: " +
 "You must add org.python.pydev.debug.pysrc to your PYTHONPATH." )
  sys . exit ( 1 )
  if 86 - 86: Ii1I % o0 / oOooOoO0Oo0O / o0
  if 42 - 42: i1iIi11iIIi1I
o0o = xbmcaddon . Addon ( )
o00OooOO000 = o0o . getAddonInfo ( 'version' )
OOoOoo = xbmc . translatePath ( o0o . getAddonInfo ( 'profile' ) . decode ( 'utf-8' ) )
oO0000OOo00 = xbmc . translatePath ( o0o . getAddonInfo ( 'path' ) . decode ( 'utf-8' ) )
iiIi1IIiIi = os . path . join ( OOoOoo , 'favorites' )
oOO00Oo = os . path . join ( OOoOoo , 'history' )
if 6 - 6: OOooOOo
oOOo0oOo0 = os . path . join ( OOoOoo , 'list_revision' )
IIooooo = os . path . join ( oO0000OOo00 , 'icon.gif' )
II1I = os . path . join ( oO0000OOo00 , 'icon_config.png' )
O0i1II1Iiii1I11 = os . path . join ( oO0000OOo00 , 'favorites.png' )
IIIIiiIiI = os . path . join ( oO0000OOo00 , 'fanart.jpg' )
o00oooO0Oo = os . path . join ( OOoOoo , 'source_file' )
o0O0OOO0Ooo = OOoOoo
if 45 - 45: O0 / i1
downloader = downloader . SimpleDownloader ( )
i1IIIII11I1IiI = o0o . getSetting ( 'debug' )
if os . path . exists ( iiIi1IIiIi ) == True :
 i1I = open ( iiIi1IIiIi ) . read ( )
else : i1I = [ ]
if os . path . exists ( o00oooO0Oo ) == True :
 OoOO = open ( o00oooO0Oo ) . read ( )
else : OoOO = [ ]
if 53 - 53: I11i11Ii
if 29 - 29: ii1IiI1i + OOooOOo % O0
def I1I11 ( url ) :
 try :
  import urllib . request as urllib2
 except ImportError :
  import urllib2
 II1 = urllib2 . build_opener ( )
 II1 . addheaders = [ ( 'User-Agent' , 'Mozilla/5.0' ) ]
 if 70 - 70: ooOoO0o - I11i11Ii / iII111i
 O00OOOOOoo0 = II1 . open ( url )
 ii1 = O00OOOOOoo0 . read ( ) . decode ( 'utf-8' )
 I1iI1iIi111i = ii1
 return I1iI1iIi111i
 if 44 - 44: i1IIi % i11i + Ii1I
def I1I1I ( message , timeShown = 5000 ) :
 xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , message , timeShown , __icon__ ) )
 if 95 - 95: i11i + i1 + IiII * iIii1I11I1II1 % OOooOOo / I1Ii111
 if 56 - 56: IiII
def oo0oO0oOOoo ( string ) :
 if i1IIIII11I1IiI == 'true' :
  if 51 - 51: I11i11Ii * i11iIiiIii
  xbmc . log ( "[APOLLO-%s]: %s" % ( o00OooOO000 , string ) )
  if 94 - 94: iII111i - i11i . I11i % Ii1I . i11iIiiIii + O0
  if 26 - 26: Ii1I - iIii1I11I1II1 - oOooOoO0Oo0O / i1iIi11iIIi1I . o0 % iIii1I11I1II1
  if 91 - 91: i1 . iIii1I11I1II1 / OOooOOo + i1IIi
  if 42 - 42: o00O0oo . i1 . o00O0oo - ii1IiI1i
def i1ii1I1I1 ( msg ) :
 oO = o0o . getSetting ( 'suporte' )
 if oO == 'true' :
  oO0O0o0Oooo ( iiiii11iII1 , o0oo0o0O00OO , 44 , oOO00oOO , IIIIiiIiI , I1Ii1iI1 ( OoooooOoo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if 87 - 87: I11i11Ii . I1Ii111
def O0OO0O ( msg ) :
 xbmcgui . Dialog ( )
 OO = xbmcgui . Dialog ( )
 OoOoO = OO . select ( '[COLOR orange][B]PARA ASSISTIR FILMES EM 4K LINKS ABAIXO![/COLOR][/B]' , [ '[COLOR deepskyblue][B]BAIXAR[/COLOR][/B][COLOR orange][B] ELEMENTUM[/COLOR][/B]' , '[COLOR deepskyblue][B]BAIXAR[/COLOR][/B][COLOR orange][B] ELEMENTUM BURST[/COLOR][/B]' , '' ] )
 if OoOoO == 0 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.83/plugin.video.elementum-0.1.83.zip' ) )
  else :
   webbrowser . open ( 'https://github.com/elgatito/plugin.video.elementum/releases/download/v0.1.83/plugin.video.elementum-0.1.83.zip' )
 if OoOoO == 1 :
  if xbmc . getCondVisibility ( 'system.platform.android' ) :
   xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://github.com/elgatito/script.elementum.burst/releases/download/v0.0.70/script.elementum.burst-0.0.70.zip' ) )
  else :
   webbrowser . open ( 'https://github.com/elgatito/script.elementum.burst/releases/download/v0.0.70/script.elementum.burst-0.0.70.zip' )
   if 43 - 43: i11iIiiIii + I11i11Ii * i11i * ooOoO0o * O0
 if OoOoO == 5 :
  xbmcaddon . Addon ( ) . openSettings ( )
  if 64 - 64: I11i % iIii1I11I1II1 * OOooOOo
  xbmc . executebuiltin ( "XBMC.Container.Refresh(%s?mode=None, replace)" % sys . argv [ 0 ] )
  xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
  if 79 - 79: O0
def oOO00O ( ) :
 OOOoo0OO = o0o . getSetting ( 'username' )
 oO0o0 = o0o . getSetting ( 'password' )
 iI1Ii11iIiI1 = o0o . getSetting ( 'servidor' )
 OO0Oooo0oOO0O = o0o . getSetting ( 'exibirTORRENT' )
 o00O0 = o0o . getSetting ( 'saida' )
 if OO0Oooo0oOO0O == 'true' :
  if iI1Ii11iIiI1 == 'TORRENT' :
   oOO0O00Oo0O0o = 'http://sv1.iptvcasa.online:25461/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % ( OOOoo0OO , oO0o0 , o00O0 )
   oO0O0o0Oooo ( I1i1I , oOO0O00Oo0O0o , 1 , oOO00oOO , OoOo , I1Ii1iI1 ( OOO0OOO00oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if iI1Ii11iIiI1 == 'Nenhum' :
   oO0O0o0Oooo ( I1i1I , '' , 42 , oOO00oOO , OoOo , I1Ii1iI1 ( OOO0OOO00oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 OOOoo0OO = o0o . getSetting ( 'username2' )
 oO0o0 = o0o . getSetting ( 'password2' )
 iI1Ii11iIiI1 = o0o . getSetting ( 'servidor2' )
 OO0Oooo0oOO0O = o0o . getSetting ( 'exibirTORRENT2' )
 o00O0 = o0o . getSetting ( 'saida2' )
 if OO0Oooo0oOO0O == 'true' :
  if iI1Ii11iIiI1 == 'TORRENT' :
   oOO0O00Oo0O0o = 'http://cloudsteam.club:8080/get.php?username=%s&password=%s&type=m3u_plus&output=%s' % ( OOOoo0OO , oO0o0 , o00O0 )
   oO0O0o0Oooo ( titulo_TORRENT2 , oOO0O00Oo0O0o , 1 , thumbnail_TORRENT2 , OoOo , I1Ii1iI1 ( OOO0OOO00oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
  if iI1Ii11iIiI1 == 'Nenhum' :
   oO0O0o0Oooo ( titulo_TORRENT2 , '' , 42 , thumbnail_TORRENT2 , fanart_TORRENT2 , I1Ii1iI1 ( OOO0OOO00oo ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
   if 13 - 13: OoooooooOO
def I111iI ( msg ) :
 oOOo0 = o0o . getSetting ( 'mensagem1' )
 if oOOo0 == 'true' :
  OO = xbmcgui . Dialog ( )
  OoOoO = OO . select ( '[COLOR orange][B]AJUDE O ADD-ON FAÇA SUA[/COLOR][/B][COLOR deepskyblue][B] DOAÇÃO[/COLOR][/B]' , [ '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] SEJA VIP [/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] SITE OFICIAL![/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR lightcyan][B] PIC[/COLOR][/B][COLOR lime][B]PAY [/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR royalblue][B] PAY[/COLOR][/B][COLOR lightcyan][B]PAL [/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR blueviolet][B] NUBANK[/COLOR][/B]' , '[COLOR deepskyblue][B]AJUDE ->[/COLOR][/B][COLOR orange][B] DOAÇÃO PELO[/COLOR][/B][COLOR lightcyan][B] MERCADO[/COLOR][/B][COLOR dodgerblue][B]PAGO [/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] GRUPO TELEGRAM[/COLOR][/B]' , '[COLOR deepskyblue][B]APOLLO ->[/COLOR][/B][COLOR orange][B] GRUPO FACEBOOK[/COLOR][/B]' , '[COLOR deepskyblue][B]ENTRAR NO[/COLOR][/B][COLOR orange][B] ADD-ON[/COLOR][/B]' ] )
  if 16 - 16: OOooOOo % ii1IiI1i * i11iIiiIii % i11iIiiIii
  if OoOoO == 0 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://bit.ly/3kntqYO_QUERO_SER_VIP' ) )
   else :
    webbrowser . open ( 'https://bit.ly/3kntqYO_QUERO_SER_VIP' )
    if 65 - 65: iII111i - OOooOOo + OOooOOo + i11i
    if 96 - 96: I11i % O0 / O0
  if OoOoO == 1 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'http://deus-apollo.tk/' ) )
   else :
    webbrowser . open ( 'http://deus-apollo.tk/' )
    if 44 - 44: OOooOOo / Ii1I / Ii1I
    if 87 - 87: I11i11Ii . oOooOoO0Oo0O - i11i + O0 / I11i11Ii / OOooOOo
  if OoOoO == 2 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://picpay.me/deus.apollo' ) )
   else :
    webbrowser . open ( 'https://picpay.me/deus.apollo' )
    if 25 - 25: oOooOoO0Oo0O . oOooOoO0Oo0O - o0 % o0 - i11iIiiIii / ooOoO0o
    if 51 - 51: I11i11Ii / o0 . I11i * i1 + i1iIi11iIIi1I * I1Ii111
  if OoOoO == 3 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=44A92DUKBAKAN&source=url' ) )
   else :
    webbrowser . open ( 'https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=44A92DUKBAKAN&source=url' )
    if 73 - 73: i1iIi11iIIi1I + OoooooooOO - O0 - iII111i - i11i
    if 99 - 99: o00O0oo . iII111i + ooOoO0o + OoooooooOO % i1
  if OoOoO == 4 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://nubank.com.br/pagar/1djpv6/FJzleug9nF' ) )
   else :
    webbrowser . open ( 'https://nubank.com.br/pagar/1djpv6/FJzleug9nF' )
    if 51 - 51: iIii1I11I1II1
    if 34 - 34: OOooOOo + oOooOoO0Oo0O - OOooOOo
  if OoOoO == 5 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=203668628-f9a8d299-8b36-4cbd-84f4-0eb34ed0be11' ) )
   else :
    webbrowser . open ( 'https://www.mercadopago.com.br/checkout/v1/redirect?pref_id=203668628-f9a8d299-8b36-4cbd-84f4-0eb34ed0be11' )
    if 17 - 17: i11i % IiII + Ii1I - IiII / I11i + o00O0oo
    if 59 - 59: I11i % o0 . iII111i * ii1IiI1i % Ii1I
    if 59 - 59: OOooOOo - IiII
  if OoOoO == 6 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'https://t.me/DeusApollo' ) )
   else :
    webbrowser . open ( 'https://t.me/DeusApollo' )
    if 15 - 15: ooOoO0o . i11iIiiIii . OoooooooOO / i1iIi11iIIi1I % iII111i
  if OoOoO == 7 :
   if xbmc . getCondVisibility ( 'system.platform.android' ) :
    xbmc . executebuiltin ( 'StartAndroidActivity(,android.intent.action.VIEW,,%s)' % ( 'www.facebook.com/groups/Deus.Apollo/' ) )
   else :
    webbrowser . open ( 'www.facebook.com/groups/Deus.Apollo/' )
    if 93 - 93: O0 % i1IIi . I11i / oOooOoO0Oo0O - ooOoO0o / oOooOoO0Oo0O
  if OoOoO == 9 :
   xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
   xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
   if 36 - 36: OOooOOo % OOooOOo % i1IIi / i1IIi - o00O0oo
   if 30 - 30: Ii1I / oOooOoO0Oo0O
  if OoOoO == 9 :
   xbmc . executebuiltin ( "XBMC.Container.Refresh('close()')" )
   xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
   if 35 - 35: i11i % I11i . o00O0oo + o00O0oo % i11i % i11i
   if 72 - 72: i11i + i1IIi + i1
def OOO ( url , ref , useragent = False ) :
 try :
  try :
   import cookielib
  except ImportError :
   import http . cookiejar as cookielib
  try :
   import urllib2
  except ImportError :
   import urllib . request as urllib2
  if ref > '' :
   IIiI1i1i = ref
  else :
   IIiI1i1i = url
  if useragent :
   O00Oo0 = useragent
  else :
   O00Oo0 = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36'
  IiII111i1i11 = cookielib . CookieJar ( )
  II1 = urllib2 . build_opener ( urllib2 . HTTPCookieProcessor ( IiII111i1i11 ) )
  II1 . addheaders = [ ( 'Accept-Language' , 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7' ) , ( 'User-Agent' , O00Oo0 ) , ( 'Accept' , 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9' ) , ( 'Referer' , IIiI1i1i ) ]
  ii1 = II1 . open ( url ) . read ( )
  O00OOOOOoo0 = ii1 . decode ( 'utf-8' )
  return O00OOOOOoo0
 except urllib2 . URLError as i111iIi1i1II1 :
  if hasattr ( i111iIi1i1II1 , 'code' ) :
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( i111iIi1i1II1 . code ) + ",10000," + __icon__ + ")" )
  elif hasattr ( i111iIi1i1II1 , 'reason' ) :
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( i111iIi1i1II1 . reason ) + ",10000," + __icon__ + ")" )
   if 86 - 86: iIii1I11I1II1 / o0 . i11i
  O00OOOOOoo0 = ''
  return O00OOOOOoo0
  if 19 - 19: ii1IiI1i % OoooooooOO % I1Ii111 * i1 % O0
  if 67 - 67: oOooOoO0Oo0O . i1IIi
def i1i1iI1iiiI ( channel ) :
 try :
  if 51 - 51: oOooOoO0Oo0O % ooOoO0o . OOooOOo / iIii1I11I1II1 / Ii1I . OOooOOo
  IIIii11 = str ( channel )
  iiIiIIIiiI = OOO ( o00 , '' ) . replace ( '\n' , '' ) . replace ( '\r' , '' )
  iiI1IIIi = re . compile ( 'player="(.+?)".+?eferer="(.+?)".+?eferer_canal="(.+?)".+?ser_agent="(.+?)"' ) . findall ( iiIiIIIiiI )
  II11IiIi11 = iiI1IIIi [ 0 ] [ 0 ] . replace ( '\n' , '' ) . replace ( '\r' , '' )
  IIOOO0O00O0OOOO = iiI1IIIi [ 0 ] [ 1 ] . replace ( '\n' , '' ) . replace ( '\r' , '' )
  I1iiii1I = iiI1IIIi [ 0 ] [ 2 ] . replace ( '\n' , '' ) . replace ( '\r' , '' )
  OOo0 = iiI1IIIi [ 0 ] [ 3 ] . replace ( '\n' , '' ) . replace ( '\r' , '' )
  ii1 = OOO ( str ( II11IiIi11 ) + IIIii11 , str ( IIOOO0O00O0OOOO ) + IIIii11 , OOo0 )
  oO00ooooO0o = '|Referer=' + I1iiii1I + '&User-Agent=' + urllib . quote_plus ( OOo0 )
  oo0o = re . compile ( 'source.+?"(.+?)"' , re . MULTILINE | re . DOTALL | re . IGNORECASE ) . findall ( ii1 ) [ 0 ] . replace ( '\n' , '' ) . replace ( '\r' , '' )
  o0oO0oooOoo = oo0o + oO00ooooO0o
  return o0oO0oooOoo
 except :
  o0oO0oooOoo = ''
  return o0oO0oooOoo
  if 7 - 7: ooOoO0o * i1iIi11iIIi1I - o00O0oo + I11i * oOooOoO0Oo0O % i1iIi11iIIi1I
  if 15 - 15: o0 % oOooOoO0Oo0O * Ii1I
def O0OoooO0 ( url ) :
 ooo0O0o00O = url . replace ( 'streamtape.com/v/' , 'streamtape.com/e/' )
 ii1 = OOO ( ooo0O0o00O , '' )
 I1i11 = re . compile ( 'videolink.+?style="display:none;">(.*?)&token=' ) . findall ( ii1 )
 IiIi1I1 = re . compile ( "<script>.+?token=(.*?)'.+?</script>" ) . findall ( ii1 )
 if I1i11 != [ ] and IiIi1I1 != [ ] :
  if 39 - 39: i11i + o0 - o00O0oo . o0
  OoOoO = 'https:' + I1i11 [ 0 ] + '&token=' + IiIi1I1 [ 0 ]
 else :
  OoOoO = ''
 return OoOoO
 if 84 - 84: i1iIi11iIIi1I + i1IIi - i11i . ii1IiI1i * OoooooooOO + oOooOoO0Oo0O
 if 38 - 38: I11i + i11i % o00O0oo % o0 - iII111i / OoooooooOO
def oOOoo0000O0o0 ( msg ) :
 oO0O0o0Oooo ( Ii1IIii11 , o0oo0o0O00OO , 1 , IIooooo , IIIIiiIiI , I1Ii1iI1 ( iIIIIiI ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 i1ii1I1I1 ( True )
 oOO00O ( )
 if 1 - 1: OOooOOo + OOooOOo % o0 + i11iIiiIii
 oo0o0000 ( IIII , '' )
 oO0O0o0Oooo ( o00OO00OoO , '' , 54 , OOOO0OOoO0O0 , IIIIiiIiI , I1Ii1iI1 ( oO0 ) , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' , '' )
 if 11 - 11: iIii1I11I1II1
 IiIIII1i11I ( )
 I111iI ( True )
 if 86 - 86: I11i11Ii . O0 - OoooooooOO . i1iIi11iIIi1I + iII111i
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 57 - 57: i1 . i1IIi . I1Ii111 * i11iIiiIii + ooOoO0o . I1Ii111
 if 57 - 57: ooOoO0o
def I11Iiii1I ( msg ) :
 try :
  oo00O0oO0O0 = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/version.txt" ) . read ( ) . replace ( '' , '' ) . replace ( '\r' , '' )
  oo00O0oO0O0 = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( oo00O0oO0O0 ) [ 0 ]
  if 96 - 96: i11iIiiIii % o00O0oo / o0
  if oo00O0oO0O0 != Oo :
   I1IiI11 ( )
   if 9 - 9: Ii1I
  elif msg == True :
   if 64 - 64: iIii1I11I1II1 / oOooOoO0Oo0O . i11i + OoooooooOO . i1iIi11iIIi1I
   I111iI ( True )
   if 56 - 56: I11i11Ii . ii1IiI1i . oOooOoO0Oo0O
 except urllib2 . URLError , i111iIi1i1II1 :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( 'Apollo' , "Não foi possível checar" )
   if 39 - 39: O0 + ooOoO0o
def OoOooOoO ( msg ) :
 try :
  oo00O0oO0O0 = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/version.txt" ) . read ( ) . replace ( '' , '' ) . replace ( '\r' , '' )
  oo00O0oO0O0 = re . compile ( '[a-zA-Z\.\d]+' ) . findall ( oo00O0oO0O0 ) [ 0 ]
  if 43 - 43: i11i . OOooOOo / ii1IiI1i
  if oo00O0oO0O0 != Oo :
   I1IiI11 ( )
   if 20 - 20: oOooOoO0Oo0O
  elif msg == True :
   xbmcgui . Dialog ( ) . ok ( '[COLOR orange][B]APOLLO[/COLOR][/B]' , "[COLOR deepskyblue][B] O ADD-ON JÁ ESTÁ NA ÚLTIMA VERSÃO![/COLOR][/B][COLOR orange][B] 1.5.9[/COLOR][/B] " + Oo + "[COLOR deepskyblue][B] ATUALIZAÇÕES SÃO AUTOMÁTICAS SE NÃO ATUALIZA ENTRE NO SITE[/COLOR][/B][COLOR orange][B] http://deus-apollo.ml[/COLOR][/B]" )
   if 95 - 95: IiII - oOooOoO0Oo0O
 except urllib2 . URLError , i111iIi1i1II1 :
  if msg == True :
   xbmcgui . Dialog ( ) . ok ( 'Apollo' , "Não foi possível checar" )
   if 34 - 34: o00O0oo * oOooOoO0Oo0O . i1IIi * o00O0oo / o00O0oo
   if 30 - 30: ii1IiI1i + I11i11Ii / I11i11Ii % ii1IiI1i . ii1IiI1i
def I1IiI11 ( ) :
 O0O0Oo00 = xbmc . translatePath ( xbmcaddon . Addon ( ) . getAddonInfo ( 'path' ) ) . decode ( "utf-8" )
 try :
  oOoO00o = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/apollo.py" ) . read ( ) . replace ( '' , '' )
  oO00O0 = re . compile ( 'checkintegrity' ) . findall ( oOoO00o )
  if oO00O0 :
   IIi1IIIi = os . path . join ( O0O0Oo00 , "apollo.py" )
   file = open ( IIi1IIIi , "w" )
   file . write ( oOoO00o )
   file . close ( )
  oOoO00o = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/resources/settings.xml" ) . read ( ) . replace ( '' , '' )
  oO00O0 = re . compile ( '</settings>' ) . findall ( oOoO00o )
  if oO00O0 :
   IIi1IIIi = os . path . join ( O0O0Oo00 , "resources/settings.xml" )
   file = open ( IIi1IIIi , "w" )
   file . write ( oOoO00o )
   file . close ( )
  oOoO00o = urllib2 . urlopen ( "https://github.com/Tiagotj/repo.apollo/raw/master/plugin.video.apollo/addon.xml" ) . read ( ) . replace ( '' , '' )
  oO00O0 = re . compile ( '</addon>' ) . findall ( oOoO00o )
  if oO00O0 :
   IIi1IIIi = os . path . join ( O0O0Oo00 , "addon.xml" )
   file = open ( IIi1IIIi , "w" )
   file . write ( oOoO00o )
   file . close ( )
  xbmcgui . Dialog ( ) . ok ( '[COLOR deepskyblue][B]APOLLO[/COLOR][/B]' , "OBS: ADD-ON ESTÁ DESATUALIZADO! CLIQUE EM OK PARA ELE SE ALTO ATUALIZAR! CASO O ADD-ON NÃO SE ATUALIZE FAÇA O DOWNLOAD NO SITE OFICIAL! [COLOR deepskyblue][B]->[/COLOR][/B][COLOR orange][COLOR orange][B] https://deus-apollo.ml[/COLOR][/B]" ) . xbmc . executebuiltin
 except :
  xbmc . executebuiltin ( "Notification({0}, {1}, 9000, {2})" . format ( __addonname__ , "[COLOR orange][B]Atualizando o addon. Por favor aguarde 5 segundos e Pode Continuar![/COLOR][/B]" , __icon__ ) )
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 99 - 99: iII111i + i1iIi11iIIi1I * i11i . i1 - ii1IiI1i
OoOooOoO ( False )
if 58 - 58: iII111i + i1 - oOooOoO0Oo0O
def i1i1ii ( ) :
 import platform
 if platform . system ( ) == 'Linux' :
  iII1ii1 = 'Android 9; Mobile; rv:68.0'
 elif platform . system ( ) == 'Windows' :
  iII1ii1 = 'Windows NT 6.1; WOW64; rv:54.0'
 elif platform . system ( ) == 'IOS' :
  iII1ii1 = 'iPhone; CPU iPhone OS 12_2 like Mac OS X'
 else :
  iII1ii1 = ''
 I1i1iiiI1 = {
 "Accept-Language" : "en-US,en;q=0.5" ,
 "\x55\x73\x65\x72\x2d\x61\x67\x65\x6e\x74" : iII1ii1 ,
 "Accept" : "text/html,application/xhtml+xml,application/xml;q=0.9,/;q=0.8" ,
 "Referer" : "APOLLO 1.5.8" ,
 "Connection" : "keep-alive"
 }
 iIIi = urllib2 . Request ( "https://whos.amung.us/pingjs/?k=c4302b" , headers = I1i1iiiI1 )
 O00OOOOOoo0 = urllib2 . urlopen ( iIIi ) . read ( )
 if 62 - 62: I11i11Ii - Ii1I
 if 21 - 21: O0 % I1Ii111 . oOooOoO0Oo0O / i11i + I1Ii111
 OOOO0O00o = 0
 xbmc . sleep ( OOOO0O00o * 0 )
i1i1ii ( )
if 62 - 62: iIii1I11I1II1
def i1II ( url , headers = None ) :
 try :
  if headers is None :
   if 14 - 14: OOooOOo / OOooOOo % o00O0oo
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
   headers = { 'User-agent' : '�}q�|{�\�~1�|{�\�}�ߜ{�\Ǯqߌ{�\�~q߼{�\�~�߬{�\ǭq߼{�\ǭ�ߌ{�\�~�߼{�\�}�ߌ{�\�1ߜ{�\�qߜ{�' }
  ooO = urllib2 . Request ( url , None , headers )
  O00OOOOOoo0 = urllib2 . urlopen ( ooO )
  ii1 = O00OOOOOoo0 . read ( )
  O00OOOOOoo0 . close ( )
  return ii1
 except urllib2 . URLError , i111iIi1i1II1 :
  oo0oO0oOOoo ( 'URL: ' + url )
  if hasattr ( i111iIi1i1II1 , 'code' ) :
   oo0oO0oOOoo ( 'Falha com o código de erro - %s.' % i111iIi1i1II1 . code )
   if 6 - 6: iIii1I11I1II1 . o00O0oo % i1
   if 50 - 50: IiII + O0 + iII111i . i11i / i1
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( i111iIi1i1II1 . code ) + ",10000," + IIooooo + ")" )
  elif hasattr ( i111iIi1i1II1 , 'reason' ) :
   oo0oO0oOOoo ( 'Falha ao acessar um servidor.' )
   oo0oO0oOOoo ( 'Razão: %s' % i111iIi1i1II1 . reason )
   if 17 - 17: iII111i % iIii1I11I1II1 - iIii1I11I1II1
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( i111iIi1i1II1 . reason ) + ",10000," + IIooooo + ")" )
   if 78 - 78: IiII + Ii1I . o00O0oo - IiII . iII111i
def I1Ii1iI1 ( url ) :
 II1 = urllib2 . build_opener ( )
 if 30 - 30: oOooOoO0Oo0O + i1iIi11iIIi1I % iII111i * IiII / I11i11Ii - Ii1I
 II1 . addheaders = [ ( 'User-Agent' , ooo ) ]
 O00OOOOOoo0 = II1 . open ( url )
 oooiIi1i = O00OOOOOoo0 . read ( )
 return oooiIi1i
 if 27 - 27: I11i * o00O0oo . ooOoO0o % I1Ii111 * I1Ii111 . i1IIi
 if 72 - 72: I11i % ii1IiI1i + i1iIi11iIIi1I / OOooOOo + I1Ii111
def IiIIII1i11I ( ) :
 I1I1i = o0o . getSetting ( 'mensagem2' )
 if I1I1i == 'true' :
  II1 = urllib2 . build_opener ( )
  if 1 - 1: Ii1I % I11i + O0 + i1IIi - i1iIi11iIIi1I
  II1 . addheaders = [ ( 'User-Agent' , ooo ) ]
  if 22 - 22: oOooOoO0Oo0O % ii1IiI1i
  O00OOOOOoo0 = II1 . open ( II )
  o0oo0O = O00OOOOOoo0 . read ( )
  if 13 - 13: i11iIiiIii + i1IIi * iIii1I11I1II1 % OoooooooOO - i11i * I11i
  time = Ooooo0Oo00oO0
  xbmc . executebuiltin ( 'Notification(%s, %s, %d, %s)' % ( __addonname__ , o0oo0O , time , __icon__ ) )
  if 26 - 26: OoooooooOO * oOooOoO0Oo0O + I11i
  if 24 - 24: i11iIiiIii % iIii1I11I1II1 + I11i / i11iIiiIii
def OOooO0oo0o00o ( ) :
 xbmc . executebuiltin ( "XBMC.Container.Refresh()" )
 if 100 - 100: i1
def I1IiI11iII1iiiiIII ( ) :
 if os . path . exists ( iiIi1IIiIi ) == True :
  oO0O0o0Oooo ( 'Favorites' , 'url' , 4 , os . path . join ( oO0000OOo00 , 'resources' , 'favorite.png' ) , IIIIiiIiI , '' , '' , '' , '' )
 if o0o . getSetting ( "browse_xml_database" ) == "true" :
  oO0O0o0Oooo ( 'XML Database' , 'http://xbmcplus.xb.funpic.de/www-data/filesystem/' , 15 , IIooooo , IIIIiiIiI , '' , '' , '' , '' )
 if o0o . getSetting ( "browse_community" ) == "true" :
  oO0O0o0Oooo ( 'Community Files' , 'community_files' , 16 , IIooooo , IIIIiiIiI , '' , '' , '' , '' )
 if os . path . exists ( oOO00Oo ) == True :
  oO0O0o0Oooo ( 'Search History' , 'history' , 25 , os . path . join ( oO0000OOo00 , 'resources' , 'favorite.png' ) , IIIIiiIiI , '' , '' , '' , '' )
 if o0o . getSetting ( "searchyt" ) == "true" :
  oO0O0o0Oooo ( 'Search:Youtube' , 'youtube' , 25 , IIooooo , IIIIiiIiI , '' , '' , '' , '' )
 if o0o . getSetting ( "searchDM" ) == "true" :
  oO0O0o0Oooo ( 'Search:dailymotion' , 'dmotion' , 25 , IIooooo , IIIIiiIiI , '' , '' , '' , '' )
 if o0o . getSetting ( "PulsarM" ) == "true" :
  oO0O0o0Oooo ( 'Pulsar:IMDB' , 'IMDBidplay' , 27 , IIooooo , IIIIiiIiI , '' , '' , '' , '' )
  if os . path . exists ( o00oooO0Oo ) == True :
   OOoOO0oo00Oo = json . loads ( open ( o00oooO0Oo , "r" ) . read ( ) )
   if 50 - 50: o00O0oo - ooOoO0o * I1Ii111 . ii1IiI1i
  if len ( OOoOO0oo00Oo ) > 1 :
   for I11iiiii1II in OOoOO0oo00Oo :
    if 51 - 51: O0 % OOooOOo - i11i
    if isinstance ( I11iiiii1II , list ) :
     oO0O0o0Oooo ( I11iiiii1II [ 0 ] . encode ( 'utf-8' ) , I11iiiii1II [ 1 ] . encode ( 'utf-8' ) , 1 , IIooooo , IIIIiiIiI , '' , '' , '' , '' , 'source' )
    else :
     I1II = IIooooo
     Oo000ooOOO = IIIIiiIiI
     Ii11i1I11i = ''
     I11i1 = ''
     credits = ''
     iIiIIIIIii = ''
     OOo0ii11I1 = ''
     oO0oo = ''
     Ii111iIi1iIi = ''
     IIIII = ''
     o0ooOoO000oO = ''
     OOo = ''
     i1i11I1I1iii1 = ''
     I1iii11 = ''
     ooo0O = ''
     iII1iii = ''
     i11i1iiiII = ''
     if I11iiiii1II . has_key ( 'thumbnail' ) :
      I1II = I11iiiii1II [ 'thumbnail' ]
     if I11iiiii1II . has_key ( 'fanart' ) :
      Oo000ooOOO = I11iiiii1II [ 'fanart' ]
     if I11iiiii1II . has_key ( 'description' ) :
      Ii11i1I11i = I11iiiii1II [ 'description' ]
     if I11iiiii1II . has_key ( 'date' ) :
      I11i1 = I11iiiii1II [ 'date' ]
     if I11iiiii1II . has_key ( 'genre' ) :
      ooOO0oO0oo00o = I11iiiii1II [ 'genre' ]
     if I11iiiii1II . has_key ( 'credits' ) :
      credits = I11iiiii1II [ 'credits' ]
     if I11iiiii1II . has_key ( 'year' ) :
      iIiIIIIIii = I11iiiii1II [ 'year' ]
     if I11iiiii1II . has_key ( 'director' ) :
      OOo0ii11I1 = I11iiiii1II [ 'director' ]
     if I11iiiii1II . has_key ( 'duration' ) :
      oO0oo = I11iiiii1II [ 'duration' ]
     if I11iiiii1II . has_key ( 'premiered' ) :
      Ii111iIi1iIi = I11iiiii1II [ 'premiered' ]
     if I11iiiii1II . has_key ( 'studio' ) :
      IIIII = I11iiiii1II [ 'studio' ]
     if I11iiiii1II . has_key ( 'rate' ) :
      o0ooOoO000oO = I11iiiii1II [ 'rate' ]
     if I11iiiii1II . has_key ( 'originaltitle' ) :
      OOo = I11iiiii1II [ 'originaltitle' ]
     if I11iiiii1II . has_key ( 'country' ) :
      i1i11I1I1iii1 = I11iiiii1II [ 'country' ]
     if I11iiiii1II . has_key ( 'rating' ) :
      I1iii11 = I11iiiii1II [ 'rating' ]
     if I11iiiii1II . has_key ( 'userrating' ) :
      ooo0O = I11iiiii1II [ 'userrating' ]
     if I11iiiii1II . has_key ( 'votes' ) :
      iII1iii = I11iiiii1II [ 'votes' ]
     if I11iiiii1II . has_key ( 'aired' ) :
      i11i1iiiII = I11iiiii1II [ 'aired' ]
     oO0O0o0Oooo ( I11iiiii1II [ 'title' ] . encode ( 'utf-8' ) , I11iiiii1II [ 'url' ] . encode ( 'utf-8' ) , 1 , I1II , Oo000ooOOO , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , credits , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , 'source' )
     if 83 - 83: OOooOOo - i11i - IiII
  else :
   if len ( OOoOO0oo00Oo ) == 1 :
    if isinstance ( OOoOO0oo00Oo [ 0 ] , list ) :
     oo0o0000 ( OOoOO0oo00Oo [ 0 ] [ 1 ] . encode ( 'utf-8' ) , IIIIiiIiI )
    else :
     oo0o0000 ( OOoOO0oo00Oo [ 0 ] [ 'url' ] , OOoOO0oo00Oo [ 0 ] [ 'fanart' ] )
     if 3 - 3: ooOoO0o
     if 45 - 45: ooOoO0o
def oOIIi1iiii1iI ( url = None ) :
 if url is None :
  if not o0o . getSetting ( "new_file_source" ) == "" :
   iIiiii = o0o . getSetting ( 'new_file_source' ) . decode ( 'utf-8' )
  elif not o0o . getSetting ( "new_url_source" ) == "" :
   iIiiii = o0o . getSetting ( 'new_url_source' ) . decode ( 'utf-8' )
 else :
  iIiiii = url
 if iIiiii == '' or iIiiii is None :
  return
 oo0oO0oOOoo ( 'Adding New Source: ' + iIiiii . encode ( 'utf-8' ) )
 if 89 - 89: IiII - o00O0oo % I11i11Ii % i1
 IIiii11i = None
 if 100 - 100: o00O0oo % iIii1I11I1II1 * i11i - IiII
 ii1 = oo00O00oO000o ( iIiiii )
 print 'source_url' , iIiiii
 if isinstance ( ii1 , BeautifulSOAP ) :
  if ii1 . find ( 'channels_info' ) :
   IIiii11i = ii1 . channels_info
  elif ii1 . find ( 'items_info' ) :
   IIiii11i = ii1 . items_info
 if IIiii11i :
  OOo00OoO = { }
  OOo00OoO [ 'url' ] = iIiiii
  try : OOo00OoO [ 'title' ] = IIiii11i . title . string
  except : pass
  try : OOo00OoO [ 'thumbnail' ] = IIiii11i . thumbnail . string
  except : pass
  try : OOo00OoO [ 'fanart' ] = IIiii11i . fanart . string
  except : pass
  try : OOo00OoO [ 'genre' ] = IIiii11i . genre . string
  except : pass
  try : OOo00OoO [ 'description' ] = IIiii11i . description . string
  except : pass
  try : OOo00OoO [ 'date' ] = IIiii11i . date . string
  except : pass
  try : OOo00OoO [ 'credits' ] = IIiii11i . credits . string
  except : pass
  try : OOo00OoO [ 'year' ] = IIiii11i . year . string
  except : pass
  try : OOo00OoO [ 'director' ] = IIiii11i . director . string
  except : pass
  try : OOo00OoO [ 'premiered' ] = IIiii11i . premiered . string
  except : pass
  try : OOo00OoO [ 'studio' ] = IIiii11i . studio . string
  except : pass
  try : OOo00OoO [ 'rate' ] = IIiii11i . rate . string
  except : pass
  try : OOo00OoO [ 'originaltitle' ] = IIiii11i . originaltitle . string
  except : pass
  try : OOo00OoO [ 'country' ] = IIiii11i . country . string
  except : pass
  try : OOo00OoO [ 'rating' ] = IIiii11i . rating . string
  except : pass
  try : OOo00OoO [ 'userrating' ] = IIiii11i . userrating . string
  except : pass
  try : OOo00OoO [ 'votes' ] = IIiii11i . votes . string
  except : pass
  try : OOo00OoO [ 'aired' ] = IIiii11i . aired . string
  except : pass
 else :
  if '/' in iIiiii :
   iIi1 = iIiiii . split ( '/' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '\\' in iIiiii :
   iIi1 = iIiiii . split ( '\\' ) [ - 1 ] . split ( '.' ) [ 0 ]
  if '%' in iIi1 :
   iIi1 = urllib . unquote_plus ( iIi1 )
  i11iiI1111 = xbmc . Keyboard ( iIi1 , 'Displayed Name, Rename?' )
  i11iiI1111 . doModal ( )
  if ( i11iiI1111 . isConfirmed ( ) == False ) :
   return
  oOoooo000Oo00 = i11iiI1111 . getText ( )
  if len ( oOoooo000Oo00 ) == 0 :
   return
  OOo00OoO = { }
  OOo00OoO [ 'title' ] = oOoooo000Oo00
  OOo00OoO [ 'url' ] = iIiiii
  OOo00OoO [ 'fanart' ] = Oo000ooOOO
  if 93 - 93: ii1IiI1i / oOooOoO0Oo0O / iIii1I11I1II1 % ooOoO0o % ooOoO0o
 if os . path . exists ( o00oooO0Oo ) == False :
  IiI11iI1i1i1i = [ ]
  IiI11iI1i1i1i . append ( OOo00OoO )
  oO0Ooooooo = open ( o00oooO0Oo , "w" )
  oO0Ooooooo . write ( json . dumps ( IiI11iI1i1i1i ) )
  oO0Ooooooo . close ( )
 else :
  OOoOO0oo00Oo = json . loads ( open ( o00oooO0Oo , "r" ) . read ( ) )
  OOoOO0oo00Oo . append ( OOo00OoO )
  oO0Ooooooo = open ( o00oooO0Oo , "w" )
  oO0Ooooooo . write ( json . dumps ( OOoOO0oo00Oo ) )
  oO0Ooooooo . close ( )
 o0o . setSetting ( 'new_url_source' , "" )
 o0o . setSetting ( 'new_file_source' , "" )
 if 39 - 39: I1Ii111 * I11i11Ii + iIii1I11I1II1 - I1Ii111 + I11i
 xbmc . executebuiltin ( "XBMC.Notification(New source added.,5000," + IIooooo + ")" )
 if not url is None :
  if 'xbmcplus.xb.funpic.de' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=14,replace)" % sys . argv [ 0 ] )
  elif 'community-links' in url :
   xbmc . executebuiltin ( "XBMC.Container.Update(%s?mode=10,replace)" % sys . argv [ 0 ] )
 else : o0o . openSettings ( )
 if 69 - 69: O0
 if 85 - 85: o00O0oo / O0
def iI1iIIIi1i ( name ) :
 OOoOO0oo00Oo = json . loads ( open ( o00oooO0Oo , "r" ) . read ( ) )
 for oooOooooO0oOO in range ( len ( OOoOO0oo00Oo ) ) :
  if isinstance ( OOoOO0oo00Oo [ oooOooooO0oOO ] , list ) :
   if OOoOO0oo00Oo [ oooOooooO0oOO ] [ 0 ] == name :
    del OOoOO0oo00Oo [ oooOooooO0oOO ]
    oO0Ooooooo = open ( o00oooO0Oo , "w" )
    oO0Ooooooo . write ( json . dumps ( OOoOO0oo00Oo ) )
    oO0Ooooooo . close ( )
    break
  else :
   if OOoOO0oo00Oo [ oooOooooO0oOO ] [ 'title' ] == name :
    del OOoOO0oo00Oo [ oooOooooO0oOO ]
    oO0Ooooooo = open ( o00oooO0Oo , "w" )
    oO0Ooooooo . write ( json . dumps ( OOoOO0oo00Oo ) )
    oO0Ooooooo . close ( )
    break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 30 - 30: OoooooooOO - OoooooooOO . O0 / IiII
 if 31 - 31: I11i + i1 . OoooooooOO
 if 89 - 89: i11i + i1IIi + i11i
def IiII1II11I ( url , browse = False ) :
 if url is None :
  url = 'http://xbmcplus.xb.funpic.de/www-data/filesystem/'
 O0Oo00O = BeautifulSoup ( i1II ( url ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 for I11iiiii1II in O0Oo00O ( 'a' ) :
  OOo0o000oO = I11iiiii1II [ 'href' ]
  if not OOo0o000oO . startswith ( '?' ) :
   oO0o00oOOooO0 = I11iiiii1II . string
   if oO0o00oOOooO0 not in [ 'Parent Directory' , 'recycle_bin/' ] :
    if OOo0o000oO . endswith ( '/' ) :
     if browse :
      oO0O0o0Oooo ( oO0o00oOOooO0 , url + OOo0o000oO , 15 , IIooooo , Oo000ooOOO , '' , '' , '' )
     else :
      oO0O0o0Oooo ( oO0o00oOOooO0 , url + OOo0o000oO , 14 , IIooooo , Oo000ooOOO , '' , '' , '' )
    elif OOo0o000oO . endswith ( '.xml' ) :
     if browse :
      oO0O0o0Oooo ( oO0o00oOOooO0 , url + OOo0o000oO , 1 , IIooooo , Oo000ooOOO , '' , '' , '' , '' , 'download' )
     else :
      if os . path . exists ( o00oooO0Oo ) == True :
       if oO0o00oOOooO0 in OoOO :
        oO0O0o0Oooo ( oO0o00oOOooO0 + ' (in use)' , url + OOo0o000oO , 11 , IIooooo , Oo000ooOOO , '' , '' , '' , '' , 'download' )
       else :
        oO0O0o0Oooo ( oO0o00oOOooO0 , url + OOo0o000oO , 11 , IIooooo , Oo000ooOOO , '' , '' , '' , '' , 'download' )
      else :
       oO0O0o0Oooo ( oO0o00oOOooO0 , url + OOo0o000oO , 11 , IIooooo , Oo000ooOOO , '' , '' , '' , '' , 'download' )
       if 79 - 79: i1iIi11iIIi1I - iIii1I11I1II1 + iII111i - ooOoO0o
       if 93 - 93: i11i . oOooOoO0Oo0O - I11i11Ii + o0
def ooO0o ( browse = False ) :
 oOO0O00Oo0O0o = 'http://community-links.googlecode.com/svn/trunk/'
 O0Oo00O = BeautifulSoup ( i1II ( oOO0O00Oo0O0o ) , convertEntities = BeautifulSoup . HTML_ENTITIES )
 o000 = O0Oo00O ( 'ul' ) [ 0 ] ( 'li' ) [ 1 : ]
 for I11iiiii1II in o000 :
  oO0o00oOOooO0 = I11iiiii1II ( 'a' ) [ 0 ] [ 'href' ]
  if browse :
   oO0O0o0Oooo ( oO0o00oOOooO0 , oOO0O00Oo0O0o + oO0o00oOOooO0 , 1 , IIooooo , Oo000ooOOO , '' , '' , '' , '' , 'download' )
  else :
   oO0O0o0Oooo ( oO0o00oOOooO0 , oOO0O00Oo0O0o + oO0o00oOOooO0 , 11 , IIooooo , Oo000ooOOO , '' , '' , '' , '' , 'download' )
   if 3 - 3: i11i / I11i + I1Ii111 . o00O0oo . i1iIi11iIIi1I
   if 83 - 83: OOooOOo + OoooooooOO
def oo00O00oO000o ( url , data = None ) :
 global o0OO00 , iI1
 iI1 = False
 if url . startswith ( 'http://' ) or url . startswith ( 'https://' ) :
  I111IiiIi1 = False
  if '$$TSDOWNLOADER$$' in url :
   iI1 = True
   url = url . replace ( "$$TSDOWNLOADER$$" , "" )
  if '$$LSProEncKey=' in url :
   I111IiiIi1 = url . split ( '$$LSProEncKey=' ) [ 1 ] . split ( '$$' ) [ 0 ]
   o00o = '$$LSProEncKey=%s$$' % I111IiiIi1
   url = url . replace ( o00o , "" )
  try :
   print 'myRequest' , url , data
   data = i1II ( url )
   import gzip , binascii
   from StringIO import StringIO
   if 'tgjds' [ : : - 1 ] in data :
    data = data . split ( 'tgjds' [ : : - 1 ] )
    Ii1IIiiIIi = StringIO ( binascii . unhexlify ( data [ 0 ] ) )
    Oo000o = gzip . GzipFile ( fileobj = Ii1IIiiIIi )
    data = Oo000o . read ( )
  except :
   data = i1II ( url )
  if I111IiiIi1 :
   import pyaes
   I111IiiIi1 = I111IiiIi1 . encode ( "ascii" )
   print I111IiiIi1
   i11I1iIi = 16 - len ( I111IiiIi1 )
   I111IiiIi1 = I111IiiIi1 + ( chr ( 0 ) * ( i11I1iIi ) )
   print repr ( I111IiiIi1 )
   data = base64 . b64decode ( data )
   O0Oo = pyaes . new ( I111IiiIi1 , pyaes . MODE_ECB , IV = None )
   data = O0Oo . decrypt ( data ) . split ( '\0' ) [ 0 ]
   if 81 - 81: OOooOOo * i1iIi11iIIi1I
  if re . search ( "#EXTM3U" , data ) or 'm3u' in url :
   if 38 - 38: o0 / IiII % I11i11Ii
   return data
 elif data == None :
  if not '/' in url or not '\\' in url :
   if 11 - 11: IiII - OOooOOo + i11i - iIii1I11I1II1
   url = os . path . join ( communityfiles , url )
  if xbmcvfs . exists ( url ) :
   if url . startswith ( "smb://" ) or url . startswith ( "nfs://" ) :
    I1i11ii11 = xbmcvfs . copy ( url , os . path . join ( OOoOoo , 'temp' , 'sorce_temp.txt' ) )
    if I1i11ii11 :
     data = open ( os . path . join ( OOoOoo , 'temp' , 'sorce_temp.txt' ) , "r" ) . read ( )
     xbmcvfs . delete ( os . path . join ( OOoOoo , 'temp' , 'sorce_temp.txt' ) )
    else :
     oo0oO0oOOoo ( "failed to copy from smb:" )
   else :
    data = open ( url , 'r' ) . read ( )
    if re . match ( "#EXTM3U" , data ) or 'm3u' in url :
     if 81 - 81: I11i - Ii1I % o00O0oo - i1iIi11iIIi1I / I11i11Ii
     return data
  else :
   oo0oO0oOOoo ( "Soup Data not found!" )
   return
 if '<SetViewMode>' in data :
  try :
   o0OO00 = re . findall ( '<SetViewMode>(.*?)<' , data ) [ 0 ]
   xbmc . executebuiltin ( "Container.SetViewMode(%s)" % o0OO00 )
   print 'done setview' , o0OO00
  except : pass
 return BeautifulSOAP ( data , convertEntities = BeautifulStoneSoup . XML_ENTITIES )
 if 4 - 4: OoooooooOO - i1IIi % iII111i - I11i * i1
 if 85 - 85: OoooooooOO * iIii1I11I1II1 . IiII / OoooooooOO % oOooOoO0Oo0O % O0
def oo0o0000 ( url , fanart , data = None ) :
 if 36 - 36: iII111i / i11i / I1Ii111 / I1Ii111 + ii1IiI1i
 oO0Ooo0ooOO0 = "List"
 if 46 - 46: iII111i % o0
 O0Oo00O = oo00O00oO000o ( url , data )
 if 64 - 64: i11iIiiIii - i11i
 if isinstance ( O0Oo00O , BeautifulSOAP ) :
  if len ( O0Oo00O ( 'layoutype' ) ) > 0 :
   oO0Ooo0ooOO0 = "thumbnail"
   if 77 - 77: o0 % iII111i
  if len ( O0Oo00O ( 'channels' ) ) > 0 :
   II1IiiIii = O0Oo00O ( 'channel' )
   for oOo0OoOOo0 in II1IiiIii :
    if 30 - 30: ii1IiI1i % oOooOoO0Oo0O
    if 89 - 89: ooOoO0o + OoooooooOO + ooOoO0o * i1IIi + iIii1I11I1II1 % Ii1I
    oOo0oO = ''
    IIi1IIIIi = 0
    try :
     oOo0oO = oOo0OoOOo0 ( 'externallink' ) [ 0 ] . string
     IIi1IIIIi = len ( oOo0OoOOo0 ( 'externallink' ) )
    except : pass
    if 70 - 70: I11i / i11i - iIii1I11I1II1 - IiII
    if IIi1IIIIi > 1 : oOo0oO = ''
    if 11 - 11: iIii1I11I1II1 . OoooooooOO . i11i / i1IIi - Ii1I
    oO0o00oOOooO0 = oOo0OoOOo0 ( 'name' ) [ 0 ] . string
    ii1ii11 = oOo0OoOOo0 ( 'thumbnail' ) [ 0 ] . string
    if ii1ii11 == None :
     ii1ii11 = ''
     if 84 - 84: O0 . Ii1I - i11i . o00O0oo / i11i
    try :
     if not oOo0OoOOo0 ( 'fanart' ) :
      if o0o . getSetting ( 'use_thumb' ) == "true" :
       iii1 = ii1ii11
      else :
       iii1 = fanart
     else :
      iii1 = oOo0OoOOo0 ( 'fanart' ) [ 0 ] . string
     if iii1 == None :
      raise
    except :
     iii1 = fanart
     if 32 - 32: iII111i . I1Ii111 . OoooooooOO - i1iIi11iIIi1I + OOooOOo
    try :
     Ii11i1I11i = oOo0OoOOo0 ( 'info' ) [ 0 ] . string
     if Ii11i1I11i == None :
      raise
    except :
     Ii11i1I11i = ''
     if 88 - 88: IiII
    try :
     ooOO0oO0oo00o = oOo0OoOOo0 ( 'genre' ) [ 0 ] . string
     if ooOO0oO0oo00o == None :
      raise
    except :
     ooOO0oO0oo00o = ''
     if 19 - 19: i11i * I1Ii111 + iII111i
    try :
     I11i1 = oOo0OoOOo0 ( 'date' ) [ 0 ] . string
     if I11i1 == None :
      raise
    except :
     I11i1 = ''
     if 65 - 65: I11i . ooOoO0o . i1iIi11iIIi1I . IiII - I11i
    try :
     credits = oOo0OoOOo0 ( 'credits' ) [ 0 ] . string
     if credits == None :
      raise
    except :
     credits = ''
     if 19 - 19: i11iIiiIii + IiII % o00O0oo
    try :
     iIiIIIIIii = oOo0OoOOo0 ( 'year' ) [ 0 ] . string
     if iIiIIIIIii == None :
      raise
    except :
     iIiIIIIIii = ''
     if 14 - 14: i1iIi11iIIi1I . i11i . Ii1I / iII111i % ii1IiI1i - o00O0oo
    try :
     OOo0ii11I1 = oOo0OoOOo0 ( 'director' ) [ 0 ] . string
     if OOo0ii11I1 == None :
      raise
    except :
     OOo0ii11I1 = ''
     if 67 - 67: Ii1I - I11i . i1IIi
    try :
     oO0oo = oOo0OoOOo0 ( 'duration' ) [ 0 ] . string
     if oO0oo == None :
      raise
    except :
     oO0oo = ''
     if 35 - 35: IiII + o00O0oo - OOooOOo . IiII . I1Ii111
    try :
     Ii111iIi1iIi = oOo0OoOOo0 ( 'premiered' ) [ 0 ] . string
     if Ii111iIi1iIi == None :
      raise
    except :
     Ii111iIi1iIi = ''
     if 87 - 87: o0
    try :
     IIIII = oOo0OoOOo0 ( 'studio' ) [ 0 ] . string
     if IIIII == None :
      raise
    except :
     IIIII = ''
     if 25 - 25: i1IIi . i1iIi11iIIi1I - o0 / i1iIi11iIIi1I % i1iIi11iIIi1I * iIii1I11I1II1
    try :
     o0ooOoO000oO = oOo0OoOOo0 ( 'rate' ) [ 0 ] . string
     if o0ooOoO000oO == None :
      raise
    except :
     o0ooOoO000oO = ''
     if 50 - 50: i1iIi11iIIi1I . i11iIiiIii - OOooOOo . OOooOOo
    try :
     OOo = oOo0OoOOo0 ( 'originaltitle' ) [ 0 ] . string
     if OOo == None :
      raise
    except :
     OOo = ''
     if 31 - 31: I11i / I11i11Ii * i1IIi . o0
    try :
     i1i11I1I1iii1 = oOo0OoOOo0 ( 'country' ) [ 0 ] . string
     if i1i11I1I1iii1 == None :
      raise
    except :
     i1i11I1I1iii1 = ''
     if 57 - 57: I11i + iIii1I11I1II1 % i1IIi % oOooOoO0Oo0O
    try :
     OO0oo = oOo0OoOOo0 ( 'mediatype' ) [ 0 ] . string
     if OO0oo == None :
      raise
    except :
     OO0oo = ''
     if 15 - 15: iIii1I11I1II1 % OoooooooOO - I11i11Ii * iII111i + Ii1I
    try :
     I1iii11 = oOo0OoOOo0 ( 'rating' ) [ 0 ] . string
     if I1iii11 == None :
      raise
    except :
     I1iii11 = ''
     if 11 - 11: IiII * iII111i - o0
    try :
     ooo0O = oOo0OoOOo0 ( 'userrating' ) [ 0 ] . string
     if ooo0O == None :
      raise
    except :
     ooo0O = ''
     if 66 - 66: o0 . i11iIiiIii - IiII * i1 + OoooooooOO * ii1IiI1i
    try :
     iII1iii = oOo0OoOOo0 ( 'votes' ) [ 0 ] . string
     if iII1iii == None :
      raise
    except :
     iII1iii = ''
     if 74 - 74: I11i11Ii
    try :
     i11i1iiiII = oOo0OoOOo0 ( 'aired' ) [ 0 ] . string
     if i11i1iiiII == None :
      raise
    except :
     i11i1iiiII = ''
     if 61 - 61: I11i11Ii - ooOoO0o * i11i % o00O0oo * iIii1I11I1II1 + i1iIi11iIIi1I
    try :
     if oOo0oO == '' :
      oO0O0o0Oooo ( oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 2 , ii1ii11 , iii1 , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , credits , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , True )
     else :
      if 71 - 71: Ii1I / Ii1I * OOooOOo * OOooOOo / i11i
      oO0O0o0Oooo ( oO0o00oOOooO0 . encode ( 'utf-8' ) , oOo0oO . encode ( 'utf-8' ) , 1 , ii1ii11 , iii1 , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , None , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , 'source' )
    except :
     oo0oO0oOOoo ( 'There was a problem adding directory from getData(): ' + oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) )
  else :
   oo0oO0oOOoo ( 'No Channels: getItems' )
   II1I1iiIII1I1 ( O0Oo00O ( 'item' ) , fanart )
 else :
  o0Ooo0o0ooo0 ( O0Oo00O )
  if 70 - 70: i11iIiiIii % IiII
 if oO0Ooo0ooOO0 == "thumbnail" :
  I11Ii11iI1 ( )
  if 39 - 39: oOooOoO0Oo0O * i11iIiiIii - OOooOOo / I1Ii111 % ooOoO0o % Ii1I
  if 65 - 65: OOooOOo - o00O0oo % OoooooooOO / OoooooooOO % OoooooooOO
  if 52 - 52: ii1IiI1i + ii1IiI1i . i11i
def o0Ooo0o0ooo0 ( data ) :
 Iii = data . rstrip ( )
 IIIII1iii = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\r\n]+)' ) . findall ( Iii )
 IIiiii = len ( IIIII1iii )
 print 'tsdownloader' , iI1
 if 37 - 37: i1 % o00O0oo
 for O0II11i11II , II1Ii1iI1i1 , o0OoO000O in IIIII1iii :
  if 94 - 94: o0 . O0 / iII111i . ii1IiI1i - i1IIi
  if 'tvg-logo' in O0II11i11II :
   ii1ii11 = iIi1III1I ( O0II11i11II , 'tvg-logo=[\'"](.*?)[\'"]' )
   if ii1ii11 :
    if ii1ii11 . startswith ( 'http' ) :
     ii1ii11 = ii1ii11
     if 71 - 71: ooOoO0o
    elif not o0o . getSetting ( 'logo-folderPath' ) == "" :
     Ii1II = o0o . getSetting ( 'logo-folderPath' )
     ii1ii11 = Ii1II + ii1ii11
     if 67 - 67: iIii1I11I1II1 - iII111i + i1
    else :
     ii1ii11 = ii1ii11
     if 97 - 97: I11i
     if 92 - 92: I11i11Ii % ii1IiI1i * iIii1I11I1II1 - ii1IiI1i . i1
  else :
   ii1ii11 = ''
   if 95 - 95: ooOoO0o % oOooOoO0Oo0O
  if 'type' in O0II11i11II :
   Iii1ii11 = iIi1III1I ( O0II11i11II , 'type=[\'"](.*?)[\'"]' )
   if Iii1ii11 == 'yt-dl' :
    o0OoO000O = o0OoO000O + "&mode=18"
   elif Iii1ii11 == 'regex' :
    oOO0O00Oo0O0o = o0OoO000O . split ( '&regexs=' )
    if 86 - 86: o0 * i11i - O0 . o0 % iIii1I11I1II1 / I11i
    IiIIiIIIiIii = I1i11II ( oo00O00oO000o ( '' , data = oOO0O00Oo0O0o [ 1 ] ) )
    if 31 - 31: OOooOOo / I1Ii111 * i1 . i11i
    oo ( oOO0O00Oo0O0o [ 0 ] , II1Ii1iI1i1 , ii1ii11 , '' , '' , '' , '' , '' , None , IiIIiIIIiIii , IIiiii )
    continue
   elif Iii1ii11 == 'ftv' :
    o0OoO000O = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( II1Ii1iI1i1 ) + '&url=' + o0OoO000O + '&mode=125&ch_fanart=na'
  elif iI1 and '.ts' in o0OoO000O :
   o0OoO000O = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( o0OoO000O ) + '&amp;streamtype=TSDOWNLOADER&name=' + urllib . quote ( II1Ii1iI1i1 )
  oOO0OO0O ( o0OoO000O , II1Ii1iI1i1 , ii1ii11 , '' , '' , '' , '' , '' , None , '' , IIiiii )
  if 78 - 78: iII111i / i11i % o0
def oO00OoOO ( name , url , fanart ) :
 O0Oo00O = oo00O00oO000o ( url )
 I11IIiIiI = O0Oo00O . find ( 'channel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 iIIIi1i1I11i = I11IIiIiI ( 'item' )
 try :
  iii1 = I11IIiIiI ( 'fanart' ) [ 0 ] . string
  if iii1 == None :
   raise
 except :
  iii1 = fanart
 for oOo0OoOOo0 in I11IIiIiI ( 'subchannel' ) :
  name = oOo0OoOOo0 ( 'name' ) [ 0 ] . string
  try :
   ii1ii11 = oOo0OoOOo0 ( 'thumbnail' ) [ 0 ] . string
   if ii1ii11 == None :
    raise
  except :
   ii1ii11 = ''
  try :
   if not oOo0OoOOo0 ( 'fanart' ) :
    if o0o . getSetting ( 'use_thumb' ) == "true" :
     iii1 = ii1ii11
   else :
    iii1 = oOo0OoOOo0 ( 'fanart' ) [ 0 ] . string
   if iii1 == None :
    raise
  except :
   pass
  try :
   Ii11i1I11i = oOo0OoOOo0 ( 'info' ) [ 0 ] . string
   if Ii11i1I11i == None :
    raise
  except :
   Ii11i1I11i = ''
   if 55 - 55: I11i11Ii - I11i
  try :
   ooOO0oO0oo00o = oOo0OoOOo0 ( 'genre' ) [ 0 ] . string
   if ooOO0oO0oo00o == None :
    raise
  except :
   ooOO0oO0oo00o = ''
   if 84 - 84: ooOoO0o + I11i11Ii - o0 * o0
  try :
   I11i1 = oOo0OoOOo0 ( 'date' ) [ 0 ] . string
   if I11i1 == None :
    raise
  except :
   I11i1 = ''
   if 61 - 61: OoooooooOO . OOooOOo . OoooooooOO / I11i11Ii
  try :
   credits = oOo0OoOOo0 ( 'credits' ) [ 0 ] . string
   if credits == None :
    raise
  except :
   credits = ''
   if 72 - 72: i1IIi
  try :
   iIiIIIIIii = oOo0OoOOo0 ( 'year' ) [ 0 ] . string
   if iIiIIIIIii == None :
    raise
  except :
   iIiIIIIIii = ''
   if 82 - 82: o0 + OoooooooOO / i11iIiiIii * ii1IiI1i . OoooooooOO
  try :
   OOo0ii11I1 = oOo0OoOOo0 ( 'director' ) [ 0 ] . string
   if OOo0ii11I1 == None :
    raise
  except :
   OOo0ii11I1 = ''
   if 63 - 63: ii1IiI1i
  try :
   oO0oo = oOo0OoOOo0 ( 'duration' ) [ 0 ] . string
   if oO0oo == None :
    raise
  except :
   oO0oo = ''
   if 6 - 6: o00O0oo / ii1IiI1i
  try :
   Ii111iIi1iIi = oOo0OoOOo0 ( 'premiered' ) [ 0 ] . string
   if Ii111iIi1iIi == None :
    raise
  except :
   Ii111iIi1iIi = ''
   if 57 - 57: Ii1I
  try :
   IIIII = oOo0OoOOo0 ( 'studio' ) [ 0 ] . string
   if IIIII == None :
    raise
  except :
   IIIII = ''
   if 67 - 67: i1iIi11iIIi1I . o00O0oo
  try :
   o0ooOoO000oO = oOo0OoOOo0 ( 'rate' ) [ 0 ] . string
   if o0ooOoO000oO == None :
    raise
  except :
   o0ooOoO000oO = ''
   if 87 - 87: OOooOOo % iII111i
  try :
   OOo = oOo0OoOOo0 ( 'originaltitle' ) [ 0 ] . string
   if OOo == None :
    raise
  except :
   OOo = ''
   if 83 - 83: i11i - Ii1I
  try :
   i1i11I1I1iii1 = oOo0OoOOo0 ( 'country' ) [ 0 ] . string
   if i1i11I1I1iii1 == None :
    raise
  except :
   i1i11I1I1iii1 = ''
   if 35 - 35: i1IIi - iIii1I11I1II1 + i1IIi
  try :
   I1iii11 = oOo0OoOOo0 ( 'rating' ) [ 0 ] . string
   if I1iii11 == None :
    raise
  except :
   I1iii11 = ''
   if 86 - 86: iIii1I11I1II1 + o0 . i11iIiiIii - iII111i
  try :
   ooo0O = oOo0OoOOo0 ( 'userrating' ) [ 0 ] . string
   if ooo0O == None :
    raise
  except :
   ooo0O = ''
   if 51 - 51: o0
  try :
   iII1iii = oOo0OoOOo0 ( 'votes' ) [ 0 ] . string
   if iII1iii == None :
    raise
  except :
   iII1iii = ''
   if 14 - 14: I1Ii111 % OOooOOo % I11i11Ii - i11iIiiIii
  try :
   i11i1iiiII = oOo0OoOOo0 ( 'aired' ) [ 0 ] . string
   if i11i1iiiII == None :
    raise
  except :
   i11i1iiiII = ''
   if 53 - 53: iII111i % I11i11Ii
  try :
   oO0O0o0Oooo ( name . encode ( 'utf-8' , 'ignore' ) , url . encode ( 'utf-8' ) , 3 , ii1ii11 , iii1 , Ii11i1I11i , ooOO0oO0oo00o , credits , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII )
  except :
   oo0oO0oOOoo ( 'There was a problem adding directory - ' + name . encode ( 'utf-8' , 'ignore' ) )
 II1I1iiIII1I1 ( iIIIi1i1I11i , iii1 )
 if 59 - 59: I11i % iIii1I11I1II1 . i1IIi + i11i * I1Ii111
 if 41 - 41: iII111i % ii1IiI1i
def i1iIiIi1I ( name , url , fanart ) :
 O0Oo00O = oo00O00oO000o ( url )
 I11IIiIiI = O0Oo00O . find ( 'subchannel' , attrs = { 'name' : name . decode ( 'utf-8' ) } )
 iIIIi1i1I11i = I11IIiIiI ( 'subitem' )
 II1I1iiIII1I1 ( iIIIi1i1I11i , fanart )
 if 37 - 37: iII111i % i1iIi11iIIi1I
 if 79 - 79: ii1IiI1i + oOooOoO0Oo0O / oOooOoO0Oo0O
def OO0O0ooOOO00 ( name , url , iconimage , fanart ) :
 IiIiiiiI1 = [ ] ; OO00OOoO0o = [ ] ; Iiiiiii1 = 0
 oOO0oo = II1iIi1IiIii ( url , 'sublink:' , '#' )
 for I111I11I111 in oOO0oo :
  iiiiI11ii = I111I11I111 . replace ( 'sublink:' , '' ) . replace ( '#' , '' )
  if 96 - 96: IiII . O0 / IiII % O0
  if len ( iiiiI11ii ) > 10 :
   Iiiiiii1 = Iiiiiii1 + 1 ; IiIiiiiI1 . append ( name + ' Source [' + str ( Iiiiiii1 ) + ']' ) ; OO00OOoO0o . append ( iiiiI11ii )
   if 94 - 94: I1Ii111 + ooOoO0o / I11i
 if Iiiiiii1 == 1 :
  try :
   if 91 - 91: Ii1I / i1IIi * i1IIi
   Ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; Ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
   O0OoOOO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = OO00OOoO0o [ 0 ] , listitem = Ii1 )
   xbmc . Player ( ) . play ( o0ooOo0OOOO0o ( OO00OOoO0o [ 0 ] ) , Ii1 )
  except :
   pass
 else :
  OO = xbmcgui . Dialog ( )
  if 98 - 98: I11i + i1IIi . oOooOoO0Oo0O - i11i - i1
  iIIi1I1ii = OO . select ( 'Select A Source' , IiIiiiiI1 )
  if iIIi1I1ii >= 0 :
   Iiii = name
   i1i = str ( OO00OOoO0o [ iIIi1I1ii ] )
   if 81 - 81: o00O0oo + IiII
   try :
    Ii1 = xbmcgui . ListItem ( name , iconImage = iconimage , thumbnailImage = iconimage ) ; Ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name } )
    O0OoOOO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = i1i , listitem = Ii1 )
    xbmc . Player ( ) . play ( o0ooOo0OOOO0o ( i1i ) , Ii1 )
   except :
    pass
    if 52 - 52: oOooOoO0Oo0O % ii1IiI1i - I11i + IiII . o0
    if 63 - 63: I11i11Ii + ooOoO0o - i11i
def i1II ( url , headers = None ) :
 try :
  if headers is None :
   if 2 - 2: I1Ii111
   headers = { 'User-agent' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0) Gecko/20100101 Firefox/19.0' }
   headers = { 'User-agent' : '\xbd\xbf\xef\xbd\xbf\xef\x38\x62\x55\xbd\xbf\xef\xbd\xbf\xef\xbd\xbf\xef\x19' }
  ooO = urllib2 . Request ( url , None , headers )
  O00OOOOOoo0 = urllib2 . urlopen ( ooO )
  ii1 = O00OOOOOoo0 . read ( )
  O00OOOOOoo0 . close ( )
  return ii1
 except urllib2 . URLError , i111iIi1i1II1 :
  oo0oO0oOOoo ( 'URL: ' + url )
  if hasattr ( i111iIi1i1II1 , 'code' ) :
   oo0oO0oOOoo ( 'Falha com o código de erro - %s.' % i111iIi1i1II1 . code )
   if 97 - 97: OOooOOo - OoooooooOO
   if 79 - 79: o0 % I1Ii111 % I11i11Ii
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( i111iIi1i1II1 . code ) + ",10000," + IIooooo + ")" )
  elif hasattr ( i111iIi1i1II1 , 'reason' ) :
   oo0oO0oOOoo ( 'Falha ao acessar um servidor.' )
   oo0oO0oOOoo ( 'Razão: %s' % i111iIi1i1II1 . reason )
   if 29 - 29: OoooooooOO . oOooOoO0Oo0O % ii1IiI1i - IiII
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( i111iIi1i1II1 . reason ) + ",10000," + IIooooo + ")" )
   if 8 - 8: i1IIi
   if 32 - 32: OOooOOo / i11i
def II1Iii ( ) :
 if 73 - 73: Ii1I * OoooooooOO . O0 . I1Ii111
 o0oooO = 'Name of channel show or movie'
 ooOo = ''
 i11iiI1111 = xbmc . Keyboard ( ooOo , o0oooO )
 i11iiI1111 . doModal ( )
 if i11iiI1111 . isConfirmed ( ) :
  ooOo = i11iiI1111 . getText ( ) . replace ( '\n' , '' ) . strip ( )
  if len ( ooOo ) == 0 :
   xbmcgui . Dialog ( ) . ok ( 'RobinHood' , 'Nothing Entered' )
   return
   if 84 - 84: I11i
 ooOo = ooOo . lower ( )
 IiIiiiiI1 = [ ]
 IiIiiiiI1 . append ( plugin_name )
 o0OoO00 = 0
 IIIIIiII1 = 1
 iii11i1 = 0
 oOiI = 0
 Ii1IIi = xbmcgui . DialogProgress ( )
 if 43 - 43: ooOoO0o % IiII
 Ii1IIi . create ( 'Searching Please wait' , ' ' )
 if 69 - 69: IiII % i1iIi11iIIi1I
 while IIIIIiII1 <> iii11i1 :
  oOOoO = IiIiiiiI1 [ iii11i1 ] . strip ( )
  print 'read this one from file list (' + str ( iii11i1 ) + ')'
  iii11i1 = iii11i1 + 1
  if 19 - 19: i11iIiiIii
  oo0 = ''
  try :
   oo0 = net . http_GET ( oOOoO ) . content
   oo0 = oo0 . encode ( 'ascii' , 'ignore' ) . decode ( 'ascii' )
   if 73 - 73: o0 . oOooOoO0Oo0O
  except :
   pass
   if 32 - 32: o0 * oOooOoO0Oo0O % o00O0oo * iII111i . O0
  if len ( oo0 ) < 10 :
   oo0 = ''
   o0OoO00 = o0OoO00 + 1
   print '*** PASSED ****' + oOOoO + '  ************* Total Passed Urls: ' + str ( o0OoO00 )
   time . sleep ( .5 )
   if 48 - 48: IiII * IiII
  I1I1 = int ( ( iii11i1 / 300 ) * 100 )
  iI1I1iiIi1I = '     Pages Read: ' + str ( iii11i1 ) + '        Matches Found: ' + str ( oOiI )
  Ii1IIi . update ( I1I1 , "" , iI1I1iiIi1I , "" )
  if 26 - 26: I1Ii111 / i1IIi * OOooOOo . oOooOoO0Oo0O
  if Ii1IIi . iscanceled ( ) :
   return
   if 17 - 17: iII111i . i11iIiiIii
  if len ( oo0 ) > 10 :
   IIIiiiI = II1iIi1IiIii ( oo0 , '<channel>' , '</channel>' )
   for I111I11I111 in IIIiiiI :
    iiiiI11ii = OoO00oo00 ( I111I11I111 , '<externallink>' , '</externallink>' )
    if 76 - 76: OoooooooOO + I11i11Ii % I1Ii111 . i1iIi11iIIi1I + i11i
    if 70 - 70: oOooOoO0Oo0O / Ii1I
    if len ( iiiiI11ii ) > 5 :
     IIIIIiII1 = IIIIIiII1 + 1
     IiIiiiiI1 . append ( iiiiI11ii )
     if 28 - 28: ii1IiI1i * OoooooooOO . i11i / i11iIiiIii + OOooOOo
     if 38 - 38: I1Ii111 . iII111i
   IIIIIIIiI = II1iIi1IiIii ( oo0 , '<item>' , '</item>' )
   for I111I11I111 in IIIIIIIiI :
    iiiiI11ii = OoO00oo00 ( I111I11I111 , '<link>' , '</link>' )
    oO0o00oOOooO0 = OoO00oo00 ( I111I11I111 , '<title>' , '</title>' )
    I1IIiI = '  ' + oO0o00oOOooO0 . lower ( ) + '  '
    if 84 - 84: Ii1I - I11i11Ii / O0 - ooOoO0o
    if len ( iiiiI11ii ) > 5 and I1IIiI . find ( ooOo ) > 0 :
     oOiI = oOiI + 1
     Oo000ooOOO = ''
     ii1ii11 = OoO00oo00 ( I111I11I111 , '<thumbnail>' , '</thumbnail>' )
     Oo000ooOOO = OoO00oo00 ( I111I11I111 , '<fanart>' , '</fanart>' )
     if len ( Oo000ooOOO ) < 5 :
      Oo000ooOOO = IIooooo
     if iiiiI11ii . find ( 'sublink' ) > 0 :
      oO0O0o0Oooo ( oO0o00oOOooO0 , iiiiI11ii , 30 , ii1ii11 , Oo000ooOOO , '' , '' , '' , '' )
     else :
      oo ( str ( iiiiI11ii ) , oO0o00oOOooO0 , ii1ii11 , Oo000ooOOO , '' , '' , '' , True , None , '' , 1 )
      if 21 - 21: O0 * O0 % ii1IiI1i
      if 94 - 94: Ii1I + i11i % i11iIiiIii
 Ii1IIi . close ( )
 xbmc . executebuiltin ( "Container.SetViewMode(50)" )
 if 8 - 8: o00O0oo * O0
def OOoO ( data , Searchkey ) :
 Iii = data . rstrip ( )
 IIIII1iii = re . compile ( r'#EXTINF:(.+?),(.*?)[\n\r]+([^\n]+)' ) . findall ( Iii )
 IIiiii = len ( IIIII1iii )
 print 'total m3u links' , IIiiii
 for O0II11i11II , II1Ii1iI1i1 , o0OoO000O in IIIII1iii :
  if 'tvg-logo' in O0II11i11II :
   ii1ii11 = iIi1III1I ( O0II11i11II , 'tvg-logo=[\'"](.*?)[\'"]' )
   if ii1ii11 :
    if ii1ii11 . startswith ( 'http' ) :
     ii1ii11 = ii1ii11
     if 18 - 18: iIii1I11I1II1 + I11i11Ii - I11i + OoooooooOO * OoooooooOO
    elif not o0o . getSetting ( 'logo-folderPath' ) == "" :
     Ii1II = o0o . getSetting ( 'logo-folderPath' )
     ii1ii11 = Ii1II + ii1ii11
     if 41 - 41: o00O0oo . I11i11Ii + oOooOoO0Oo0O
    else :
     ii1ii11 = ii1ii11
     if 100 - 100: iII111i + i1iIi11iIIi1I
     if 73 - 73: i1IIi - ooOoO0o % o00O0oo / i1iIi11iIIi1I
  else :
   ii1ii11 = ''
  if 'type' in O0II11i11II :
   Iii1ii11 = iIi1III1I ( O0II11i11II , 'type=[\'"](.*?)[\'"]' )
   if Iii1ii11 == 'yt-dl' :
    o0OoO000O = o0OoO000O + "&mode=18"
   elif Iii1ii11 == 'regex' :
    oOO0O00Oo0O0o = o0OoO000O . split ( '&regexs=' )
    if 40 - 40: ii1IiI1i * o00O0oo - oOooOoO0Oo0O / I1Ii111 / i11iIiiIii
    IiIIiIIIiIii = I1i11II ( oo00O00oO000o ( '' , data = oOO0O00Oo0O0o [ 1 ] ) )
    if 83 - 83: ii1IiI1i / ooOoO0o - i11iIiiIii . iIii1I11I1II1 + I11i11Ii
    oo ( oOO0O00Oo0O0o [ 0 ] , II1Ii1iI1i1 , ii1ii11 , '' , '' , '' , '' , '' , None , IiIIiIIIiIii , IIiiii )
    continue
  oo ( o0OoO000O , II1Ii1iI1i1 , ii1ii11 , '' , '' , '' , '' , '' , None , '' , IIiiii )
  if 59 - 59: O0 % I11i11Ii
def O0o00O0Oo0 ( text , pattern ) :
 o0I11iII = ""
 try :
  IiiIiI = re . findall ( pattern , text , flags = re . DOTALL )
  o0I11iII = IiiIiI [ 0 ]
 except :
  o0I11iII = ""
  if 23 - 23: Ii1I
 return o0I11iII
 if 40 - 40: i1 - i11i / I11i11Ii
def II1iIi1IiIii ( text , start_with , end_with ) :
 iiIiI1ii = re . findall ( "(?i)(" + start_with + "[\S\s]+?" + end_with + ")" , text )
 return iiIiI1ii
 if 56 - 56: OoooooooOO - Ii1I - i1IIi
def OoO00oo00 ( text , from_string , to_string , excluding = True ) :
 if excluding :
  try : iiIiI1ii = re . search ( "(?i)" + from_string + "([\S\s]+?)" + to_string , text ) . group ( 1 )
  except : iiIiI1ii = ''
 else :
  try : iiIiI1ii = re . search ( "(?i)(" + from_string + "[\S\s]+?" + to_string + ")" , text ) . group ( 1 )
  except : iiIiI1ii = ''
 return iiIiI1ii
 if 8 - 8: ooOoO0o / I11i . oOooOoO0Oo0O + ii1IiI1i / i11iIiiIii
def II1I1iiIII1I1 ( items , fanart , dontLink = False ) :
 IIiiii = len ( items )
 oo0oO0oOOoo ( 'Total Items: %s' % IIiiii )
 I1Iii1iI1 = o0o . getSetting ( 'add_playlist' )
 o0Oo0oOooOoOo = o0o . getSetting ( 'ask_playlist_items' )
 I1i = o0o . getSetting ( 'use_thumb' )
 OoIiIiIi1I1 = o0o . getSetting ( 'parentalblocked' )
 OoIiIiIi1I1 = ''
 OoIiIiIi1I1 = OoIiIiIi1I1 == "true"
 for IiI1ii1Ii in items :
  oooOOOoOOOo0O = False
  O00oOoo0OoO0 = False
  if 62 - 62: i1IIi / o00O0oo . oOooOoO0Oo0O * i1
  i11i1Ii1 = 'false'
  try :
   i11i1Ii1 = IiI1ii1Ii ( 'parentalblock' ) [ 0 ] . string
  except :
   oo0oO0oOOoo ( 'parentalblock Error' )
   i11i1Ii1 = ''
  if i11i1Ii1 == 'true' and OoIiIiIi1I1 : continue
  if 98 - 98: ooOoO0o
  try :
   oO0o00oOOooO0 = IiI1ii1Ii ( 'title' ) [ 0 ] . string
   if oO0o00oOOooO0 is None :
    oO0o00oOOooO0 = 'unknown?'
  except :
   oo0oO0oOOoo ( 'Name Error' )
   oO0o00oOOooO0 = ''
   if 92 - 92: ooOoO0o - iIii1I11I1II1
   if 32 - 32: iII111i % i1iIi11iIIi1I * i1iIi11iIIi1I + I1Ii111 * i11i * iII111i
  try :
   if IiI1ii1Ii ( 'epg' ) :
    if IiI1ii1Ii . epg_url :
     oo0oO0oOOoo ( 'Get EPG Regex' )
     iIiIii1I1II = IiI1ii1Ii . epg_url . string
     O0Oooo = IiI1ii1Ii . epg_regex . string
     oO000 = I1IiIiIi1IiI1 ( iIiIii1I1II , O0Oooo )
     if oO000 :
      oO0o00oOOooO0 += ' - ' + oO000
    elif IiI1ii1Ii ( 'epg' ) [ 0 ] . string > 1 :
     oO0o00oOOooO0 += O0OO0o0OO0OO ( IiI1ii1Ii ( 'epg' ) [ 0 ] . string )
   else :
    pass
  except :
   oo0oO0oOOoo ( 'EPG Error' )
  try :
   oOO0O00Oo0O0o = [ ]
   if len ( IiI1ii1Ii ( 'link' ) ) > 0 :
    if 64 - 64: i11i
    if 40 - 40: o0 % i1iIi11iIIi1I
    for I11iiiii1II in IiI1ii1Ii ( 'link' ) :
     if not I11iiiii1II . string == None :
      oOO0O00Oo0O0o . append ( I11iiiii1II . string )
      if 62 - 62: i1
   elif len ( IiI1ii1Ii ( 'sportsdevil' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'sportsdevil' ) :
     if not I11iiiii1II . string == None :
      I1i111i = 'plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url=' + I11iiiii1II . string
      IIOOO0O00O0OOOO = IiI1ii1Ii ( 'referer' ) [ 0 ] . string
      if IIOOO0O00O0OOOO :
       if 42 - 42: ii1IiI1i / i1IIi % o0
       I1i111i = I1i111i + '%26referer=' + IIOOO0O00O0OOOO
      oOO0O00Oo0O0o . append ( I1i111i )
   elif len ( IiI1ii1Ii ( 'p2p' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'p2p' ) :
     if not I11iiiii1II . string == None :
      if 'sop://' in I11iiiii1II . string :
       I11iiIIII1I1 = 'plugin://plugin.video.p2p-streams/?mode=2url=' + I11iiiii1II . string + '&' + 'name=' + oO0o00oOOooO0
       oOO0O00Oo0O0o . append ( I11iiIIII1I1 )
      else :
       i1IIi1i1Ii1 = 'plugin://plugin.video.p2p-streams/?mode=1&url=' + I11iiiii1II . string + '&' + 'name=' + oO0o00oOOooO0
       oOO0O00Oo0O0o . append ( i1IIi1i1Ii1 )
   elif len ( IiI1ii1Ii ( 'vaughn' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'vaughn' ) :
     if not I11iiiii1II . string == None :
      Iiio0Oo0oO = 'plugin://plugin.stream.vaughnlive.tv/?mode=PlayLiveStream&amp;channel=' + I11iiiii1II . string
      oOO0O00Oo0O0o . append ( Iiio0Oo0oO )
   elif len ( IiI1ii1Ii ( 'ilive' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'ilive' ) :
     if not I11iiiii1II . string == None :
      if not 'http' in I11iiiii1II . string :
       iI = 'plugin://plugin.video.tbh.ilive/?url=http://www.streamlive.to/view/' + I11iiiii1II . string + '&amp;link=99&amp;mode=iLivePlay'
      else :
       iI = 'plugin://plugin.video.tbh.ilive/?url=' + I11iiiii1II . string + '&amp;link=99&amp;mode=iLivePlay'
   elif len ( IiI1ii1Ii ( 'yt-dl' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'yt-dl' ) :
     if not I11iiiii1II . string == None :
      II1iiIi11 = I11iiiii1II . string + '&mode=18'
      oOO0O00Oo0O0o . append ( II1iiIi11 )
   elif len ( IiI1ii1Ii ( 'dm' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'dm' ) :
     if not I11iiiii1II . string == None :
      ooOo0O0O0oOO0 = "plugin://plugin.video.dailymotion_com/?mode=playVideo&url=" + I11iiiii1II . string
      oOO0O00Oo0O0o . append ( ooOo0O0O0oOO0 )
   elif len ( IiI1ii1Ii ( 'dmlive' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'dmlive' ) :
     if not I11iiiii1II . string == None :
      ooOo0O0O0oOO0 = "plugin://plugin.video.dailymotion_com/?mode=playLiveVideo&url=" + I11iiiii1II . string
      oOO0O00Oo0O0o . append ( ooOo0O0O0oOO0 )
   elif len ( IiI1ii1Ii ( 'utube' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'utube' ) :
     if not I11iiiii1II . string == None :
      if ' ' in I11iiiii1II . string :
       iIiIIi = 'plugin://plugin.video.youtube/search/?q=' + urllib . quote_plus ( I11iiiii1II . string )
       O00oOoo0OoO0 = iIiIIi
      elif len ( I11iiiii1II . string ) == 11 :
       iIiIIi = 'plugin://plugin.video.youtube/play/?video_id=' + I11iiiii1II . string
      elif ( I11iiiii1II . string . startswith ( 'PL' ) and not '&order=' in I11iiiii1II . string ) or I11iiiii1II . string . startswith ( 'UU' ) :
       iIiIIi = 'plugin://plugin.video.youtube/play/?&order=default&playlist_id=' + I11iiiii1II . string
      elif I11iiiii1II . string . startswith ( 'PL' ) or I11iiiii1II . string . startswith ( 'UU' ) :
       iIiIIi = 'plugin://plugin.video.youtube/play/?playlist_id=' + I11iiiii1II . string
      elif I11iiiii1II . string . startswith ( 'UC' ) and len ( I11iiiii1II . string ) > 12 :
       iIiIIi = 'plugin://plugin.video.youtube/channel/' + I11iiiii1II . string + '/'
       O00oOoo0OoO0 = iIiIIi
      elif not I11iiiii1II . string . startswith ( 'UC' ) and not ( I11iiiii1II . string . startswith ( 'PL' ) ) :
       iIiIIi = 'plugin://plugin.video.youtube/user/' + I11iiiii1II . string + '/'
       O00oOoo0OoO0 = iIiIIi
     oOO0O00Oo0O0o . append ( iIiIIi )
     if 14 - 14: i1 / I11i - iIii1I11I1II1 - OOooOOo % o00O0oo
   elif len ( IiI1ii1Ii ( 'gdrive' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'gdrive' ) :
     if not I11iiiii1II . string == None :
      if len ( I11iiiii1II . string ) == 33 :
       I1iIiI1IiIIII = 'plugin://plugin.video.gdrive?mode=streamURL&amp;url=https://drive.google.com/open?id=' + I11iiiii1II . string
       if 18 - 18: o00O0oo % i11iIiiIii . iIii1I11I1II1 - IiII
     oOO0O00Oo0O0o . append ( I1iIiI1IiIIII )
     if 80 - 80: oOooOoO0Oo0O + OOooOOo - i1IIi . iII111i / i1 / oOooOoO0Oo0O
   elif len ( IiI1ii1Ii ( 'imdb' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'imdb' ) :
     if not I11iiiii1II . string == None :
      if o0o . getSetting ( 'genesisorpulsar' ) == '0' :
       I1Iiii = 'plugin://plugin.video.genesis/?action=play&imdb=' + I11iiiii1II . string
      else :
       I1Iiii = 'plugin://plugin.video.pulsar/movie/tt' + I11iiiii1II . string + '/play'
      oOO0O00Oo0O0o . append ( I1Iiii )
   elif len ( IiI1ii1Ii ( 'f4m' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'f4m' ) :
     if not I11iiiii1II . string == None :
      if '.f4m' in I11iiiii1II . string :
       I1III1II1I11 = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( I11iiiii1II . string )
      elif '.m3u8' in I11iiiii1II . string :
       I1III1II1I11 = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( I11iiiii1II . string ) + '&amp;streamtype=HLS'
       if 30 - 30: i1 / I11i / I1Ii111 % o00O0oo + i11i
      else :
       I1III1II1I11 = 'plugin://plugin.video.f4mTester/?url=' + urllib . quote_plus ( I11iiiii1II . string ) + '&amp;streamtype=SIMPLE'
     oOO0O00Oo0O0o . append ( I1III1II1I11 )
   elif len ( IiI1ii1Ii ( 'ftv' ) ) > 0 :
    for I11iiiii1II in IiI1ii1Ii ( 'ftv' ) :
     if not I11iiiii1II . string == None :
      I1III111i = 'plugin://plugin.video.F.T.V/?name=' + urllib . quote ( oO0o00oOOooO0 ) + '&url=' + I11iiiii1II . string + '&mode=125&ch_fanart=na'
     oOO0O00Oo0O0o . append ( I1III111i )
   elif len ( IiI1ii1Ii ( 'urlsolve' ) ) > 0 :
    if 4 - 4: i1IIi + o00O0oo + i1IIi
    for I11iiiii1II in IiI1ii1Ii ( 'urlsolve' ) :
     if not I11iiiii1II . string == None :
      i11IiIIi11I = I11iiiii1II . string + '&mode=19'
      oOO0O00Oo0O0o . append ( i11IiIIi11I )
   if len ( oOO0O00Oo0O0o ) < 1 :
    raise
  except :
   oo0oO0oOOoo ( 'Error <link> element, Passing:' + oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) )
   continue
  try :
   oooOOOoOOOo0O = IiI1ii1Ii ( 'externallink' ) [ 0 ] . string
  except : pass
  if 78 - 78: I1Ii111
  if oooOOOoOOOo0O :
   Oo0O0Oo00O = [ oooOOOoOOOo0O ]
   oooOOOoOOOo0O = True
  else :
   oooOOOoOOOo0O = False
  try :
   O00oOoo0OoO0 = IiI1ii1Ii ( 'jsonrpc' ) [ 0 ] . string
  except : pass
  if O00oOoo0OoO0 :
   if 9 - 9: i1 . oOooOoO0Oo0O - ii1IiI1i
   Oo0O0Oo00O = [ O00oOoo0OoO0 ]
   if 32 - 32: OoooooooOO / oOooOoO0Oo0O / iIii1I11I1II1 + i11i . OOooOOo . i1
   O00oOoo0OoO0 = True
  else :
   O00oOoo0OoO0 = False
  try :
   ii1ii11 = IiI1ii1Ii ( 'thumbnail' ) [ 0 ] . string
   if ii1ii11 == None :
    raise
  except :
   ii1ii11 = ''
  try :
   if not IiI1ii1Ii ( 'fanart' ) :
    if o0o . getSetting ( 'use_thumb' ) == "true" :
     iii1 = ii1ii11
    else :
     iii1 = fanart
   else :
    iii1 = IiI1ii1Ii ( 'fanart' ) [ 0 ] . string
   if iii1 == None :
    raise
  except :
   iii1 = fanart
  try :
   Ii11i1I11i = IiI1ii1Ii ( 'info' ) [ 0 ] . string
   if Ii11i1I11i == None :
    raise
  except :
   Ii11i1I11i = ''
   if 21 - 21: iIii1I11I1II1 / i11i % i1IIi
  try :
   ooOO0oO0oo00o = IiI1ii1Ii ( 'genre' ) [ 0 ] . string
   if ooOO0oO0oo00o == None :
    raise
  except :
   ooOO0oO0oo00o = ''
   if 8 - 8: i1iIi11iIIi1I + o0 . iIii1I11I1II1 % O0
  try :
   I11i1 = IiI1ii1Ii ( 'date' ) [ 0 ] . string
   if I11i1 == None :
    raise
  except :
   I11i1 = ''
   if 43 - 43: ii1IiI1i - IiII
  try :
   iIiIIIIIii = IiI1ii1Ii ( 'year' ) [ 0 ] . string
   if I11i1 == None :
    raise
  except :
   iIiIIIIIii = ''
   if 70 - 70: IiII / I11i % o00O0oo - iII111i
  try :
   OOo0ii11I1 = IiI1ii1Ii ( 'director' ) [ 0 ] . string
   if OOo0ii11I1 == None :
    raise
  except :
   OOo0ii11I1 = ''
   if 47 - 47: IiII
  try :
   oO0oo = IiI1ii1Ii ( 'duration' ) [ 0 ] . string
   if oO0oo == None :
    raise
  except :
   oO0oo = ''
   if 92 - 92: I11i + o0 % i1IIi
  try :
   Ii111iIi1iIi = IiI1ii1Ii ( 'premiered' ) [ 0 ] . string
   if Ii111iIi1iIi == None :
    raise
  except :
   Ii111iIi1iIi = ''
   if 23 - 23: ooOoO0o - I11i + iII111i - o0 * o0 . I11i11Ii
  try :
   IIIII = IiI1ii1Ii ( 'studio' ) [ 0 ] . string
   if IIIII == None :
    raise
  except :
   IIIII = ''
   if 47 - 47: OOooOOo % iIii1I11I1II1
  try :
   o0ooOoO000oO = IiI1ii1Ii ( 'rate' ) [ 0 ] . string
   if o0ooOoO000oO == None :
    raise
  except :
   o0ooOoO000oO = ''
   if 11 - 11: oOooOoO0Oo0O % iII111i - i1iIi11iIIi1I - OOooOOo + i1
  try :
   OOo = channel ( 'originaltitle' ) [ 0 ] . string
   if OOo == None :
    raise
  except :
   OOo = ''
   if 98 - 98: IiII + iII111i - i1iIi11iIIi1I
  try :
   i1i11I1I1iii1 = channel ( 'country' ) [ 0 ] . string
   if i1i11I1I1iii1 == None :
    raise
  except :
   i1i11I1I1iii1 = ''
   if 79 - 79: I11i / ooOoO0o . o0 - ii1IiI1i
  try :
   I1iii11 = channel ( 'rating' ) [ 0 ] . string
   if I1iii11 == None :
    raise
  except :
   I1iii11 = ''
   if 47 - 47: OoooooooOO % O0 * IiII . iII111i
  try :
   ooo0O = channel ( 'userrating' ) [ 0 ] . string
   if ooo0O == None :
    raise
  except :
   ooo0O = ''
   if 38 - 38: O0 - I1Ii111 % ooOoO0o
  try :
   iII1iii = channel ( 'votes' ) [ 0 ] . string
   if iII1iii == None :
    raise
  except :
   iII1iii = ''
   if 64 - 64: iIii1I11I1II1
  try :
   i11i1iiiII = channel ( 'aired' ) [ 0 ] . string
   if i11i1iiiII == None :
    raise
  except :
   i11i1iiiII = ''
   if 15 - 15: ii1IiI1i + I11i / ii1IiI1i / ooOoO0o
  IiIIiIIIiIii = None
  if IiI1ii1Ii ( 'regex' ) :
   try :
    I1Iii1I = IiI1ii1Ii ( 'regex' )
    IiIIiIIIiIii = I1i11II ( I1Iii1I )
   except :
    pass
  try :
   if 13 - 13: i1 + O0
   if len ( oOO0O00Oo0O0o ) > 1 :
    O00o0O = 0
    iIIIiI = [ ]
    for I11iiiii1II in oOO0O00Oo0O0o :
     if I1Iii1iI1 == "false" :
      O00o0O += 1
      oo ( I11iiiii1II , '%s) %s' % ( O00o0O , oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) ) , ii1ii11 , iii1 , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , True , iIIIiI , IiIIiIIIiIii , IIiiii )
     elif I1Iii1iI1 == "true" and o0Oo0oOooOoOo == 'true' :
      if IiIIiIIIiIii :
       iIIIiI . append ( I11iiiii1II + '&regexs=' + IiIIiIIIiIii )
      elif any ( x in I11iiiii1II for x in Ii1i ) and I11iiiii1II . startswith ( 'http' ) :
       iIIIiI . append ( I11iiiii1II + '&mode=19' )
      else :
       iIIIiI . append ( I11iiiii1II )
     else :
      iIIIiI . append ( I11iiiii1II )
    if len ( iIIIiI ) > 1 :
     oo ( '' , oO0o00oOOooO0 , ii1ii11 , iii1 , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , True , iIIIiI , IiIIiIIIiIii , IIiiii )
   else :
    if 93 - 93: o00O0oo . iIii1I11I1II1 % i11iIiiIii . o0 % o00O0oo + O0
    if dontLink :
     return oO0o00oOOooO0 , oOO0O00Oo0O0o [ 0 ] , IiIIiIIIiIii
    if oooOOOoOOOo0O :
     if not IiIIiIIIiIii == None :
      oO0O0o0Oooo ( oO0o00oOOooO0 . encode ( 'utf-8' ) , Oo0O0Oo00O [ 0 ] . encode ( 'utf-8' ) , 1 , ii1ii11 , fanart , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , None , '!!update' , IiIIiIIIiIii , oOO0O00Oo0O0o [ 0 ] . encode ( 'utf-8' ) )
      if 65 - 65: iII111i + i1iIi11iIIi1I - OoooooooOO
     else :
      oO0O0o0Oooo ( oO0o00oOOooO0 . encode ( 'utf-8' ) , Oo0O0Oo00O [ 0 ] . encode ( 'utf-8' ) , 1 , ii1ii11 , fanart , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , None , 'source' , None , None )
      if 51 - 51: I11i11Ii + OOooOOo / IiII - i1IIi
    elif O00oOoo0OoO0 :
     oO0O0o0Oooo ( oO0o00oOOooO0 . encode ( 'utf-8' ) , Oo0O0Oo00O [ 0 ] , 53 , ii1ii11 , fanart , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , None , 'source' )
     if 51 - 51: I11i11Ii - ii1IiI1i * Ii1I
    else :
     if 12 - 12: iIii1I11I1II1 % o00O0oo % o00O0oo
     oo ( oOO0O00Oo0O0o [ 0 ] , oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) , ii1ii11 , iii1 , Ii11i1I11i , ooOO0oO0oo00o , I11i1 , iIiIIIIIii , OOo0ii11I1 , oO0oo , Ii111iIi1iIi , IIIII , o0ooOoO000oO , OOo , i1i11I1I1iii1 , I1iii11 , ooo0O , iII1iii , i11i1iiiII , True , None , IiIIiIIIiIii , IIiiii )
     if 78 - 78: I1Ii111 . o0 . Ii1I
  except :
   oo0oO0oOOoo ( 'There was a problem adding item - ' + oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) )
   if 97 - 97: OOooOOo
def I1i11II ( reg_item ) :
 try :
  IiIIiIIIiIii = { }
  for I11iiiii1II in reg_item :
   IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] = { }
   IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'name' ] = I11iiiii1II ( 'name' ) [ 0 ] . string
   if 80 - 80: oOooOoO0Oo0O . iII111i
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'expres' ] = I11iiiii1II ( 'expres' ) [ 0 ] . string
    if not IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'expres' ] :
     IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'expres' ] = ''
   except :
    oo0oO0oOOoo ( "Regex: -- No Referer --" )
   IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'page' ] = I11iiiii1II ( 'page' ) [ 0 ] . string
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'referer' ] = I11iiiii1II ( 'referer' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No Referer --" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'connection' ] = I11iiiii1II ( 'connection' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No connection --" )
    if 47 - 47: Ii1I + o00O0oo + i11i % i11iIiiIii
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'notplayable' ] = I11iiiii1II ( 'notplayable' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No notplayable --" )
    if 93 - 93: ii1IiI1i % o0 . O0 / IiII * OOooOOo
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'noredirect' ] = I11iiiii1II ( 'noredirect' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No noredirect --" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'origin' ] = I11iiiii1II ( 'origin' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No origin --" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'accept' ] = I11iiiii1II ( 'accept' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No accept --" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'includeheaders' ] = I11iiiii1II ( 'includeheaders' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No includeheaders --" )
    if 29 - 29: i1
    if 86 - 86: i11i . I1Ii111
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'listrepeat' ] = I11iiiii1II ( 'listrepeat' ) [ 0 ] . string
    if 2 - 2: OoooooooOO
   except :
    oo0oO0oOOoo ( "Regex: -- No listrepeat --" )
    if 60 - 60: i1iIi11iIIi1I
    if 81 - 81: o0 % iII111i
    if 87 - 87: iIii1I11I1II1 . OoooooooOO * o0
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'proxy' ] = I11iiiii1II ( 'proxy' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No proxy --" )
    if 100 - 100: i1iIi11iIIi1I / i1IIi - oOooOoO0Oo0O % iII111i - iIii1I11I1II1
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'x-req' ] = I11iiiii1II ( 'x-req' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No x-req --" )
    if 17 - 17: Ii1I / i1 % I11i11Ii
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'x-addr' ] = I11iiiii1II ( 'x-addr' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No x-addr --" )
    if 71 - 71: I1Ii111 . ooOoO0o . i1iIi11iIIi1I
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'x-forward' ] = I11iiiii1II ( 'x-forward' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No x-forward --" )
    if 68 - 68: i11iIiiIii % OOooOOo * i1iIi11iIIi1I * I1Ii111 * i11i + O0
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'agent' ] = I11iiiii1II ( 'agent' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- No User Agent --" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'post' ] = I11iiiii1II ( 'post' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- Not a post" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'rawpost' ] = I11iiiii1II ( 'rawpost' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- Not a rawpost" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'htmlunescape' ] = I11iiiii1II ( 'htmlunescape' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- Not a htmlunescape" )
    if 66 - 66: Ii1I % ii1IiI1i % OoooooooOO
    if 34 - 34: i1 / IiII % O0 . i1iIi11iIIi1I . i1IIi
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'readcookieonly' ] = I11iiiii1II ( 'readcookieonly' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- Not a readCookieOnly" )
    if 29 - 29: O0 . ooOoO0o
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = I11iiiii1II ( 'cookiejar' ) [ 0 ] . string
    if not IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] :
     IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'cookiejar' ] = ''
   except :
    oo0oO0oOOoo ( "Regex: -- Not a cookieJar" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'setcookie' ] = I11iiiii1II ( 'setcookie' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- Not a setcookie" )
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'appendcookie' ] = I11iiiii1II ( 'appendcookie' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- Not a appendcookie" )
    if 66 - 66: OOooOOo * iIii1I11I1II1 % iIii1I11I1II1 * I1Ii111 - o00O0oo - I1Ii111
   try :
    IiIIiIIIiIii [ I11iiiii1II ( 'name' ) [ 0 ] . string ] [ 'ignorecache' ] = I11iiiii1II ( 'ignorecache' ) [ 0 ] . string
   except :
    oo0oO0oOOoo ( "Regex: -- no ignorecache" )
    if 70 - 70: ooOoO0o + OOooOOo
    if 93 - 93: ooOoO0o + iII111i
    if 33 - 33: O0
    if 78 - 78: O0 / i11i * i1iIi11iIIi1I
    if 50 - 50: OoooooooOO - iIii1I11I1II1 + i1IIi % ooOoO0o - iIii1I11I1II1 % O0
  IiIIiIIIiIii = urllib . quote ( repr ( IiIIiIIIiIii ) )
  return IiIIiIIIiIii
  if 58 - 58: I1Ii111 + iIii1I11I1II1
 except :
  IiIIiIIIiIii = None
  oo0oO0oOOoo ( 'regex Error: ' + oO0o00oOOooO0 . encode ( 'utf-8' , 'ignore' ) )
  if 65 - 65: i11i - ooOoO0o % i1 - o0 * IiII + iII111i
  if 79 - 79: o00O0oo . o0 % ooOoO0o - I11i11Ii
def o0oO0oO0O ( url ) :
 try :
  for I11iiiii1II in range ( 1 , 51 ) :
   o0I11iII = ii11II ( url )
   if "EXT-X-STREAM-INF" in o0I11iII : return url
   if not "EXTM3U" in o0I11iII : return
   xbmc . sleep ( 2000 )
  return
 except :
  return
  if 9 - 9: iIii1I11I1II1 % Ii1I / o0 - O0
def o0O0oo0o ( regexs , url , cookieJar = None , forCookieJarOnly = False , recursiveCall = False , cachedPages = { } , rawPost = False , cookie_jar_file = None ) :
 if not recursiveCall :
  regexs = eval ( urllib . unquote ( regexs ) )
  if 12 - 12: o0 % I1Ii111 % ii1IiI1i . i11iIiiIii * iIii1I11I1II1
  if 66 - 66: i11iIiiIii * iIii1I11I1II1 % OoooooooOO
 iIiI1iI1i1I = re . compile ( '\$doregex\[([^\]]*)\]' ) . findall ( url )
 if 82 - 82: oOooOoO0Oo0O % ii1IiI1i * IiII . iII111i % oOooOoO0Oo0O - iIii1I11I1II1
 iII1ii1I1i = True
 for iiI1 in iIiI1iI1i1I :
  if iiI1 in regexs :
   if 42 - 42: I11i % OOooOOo / i1iIi11iIIi1I - OOooOOo * i11iIiiIii
   iI1IiiiIiI1Ii = regexs [ iiI1 ]
   if 78 - 78: OoooooooOO / I11i % o0 * OoooooooOO
   ooOO00o00 = False
   if 'cookiejar' in iI1IiiiIiI1Ii :
    if 18 - 18: iIii1I11I1II1 + Ii1I * oOooOoO0Oo0O - I11i / oOooOoO0Oo0O
    ooOO00o00 = iI1IiiiIiI1Ii [ 'cookiejar' ]
    if '$doregex' in ooOO00o00 :
     cookieJar = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'cookiejar' ] , cookieJar , True , True , cachedPages )
     ooOO00o00 = True
    else :
     ooOO00o00 = True
     if 78 - 78: Ii1I . I1Ii111
   if ooOO00o00 :
    if cookieJar == None :
     if 38 - 38: o0 + I1Ii111
     cookie_jar_file = None
     if 'open[' in iI1IiiiIiI1Ii [ 'cookiejar' ] :
      cookie_jar_file = iI1IiiiIiI1Ii [ 'cookiejar' ] . split ( 'open[' ) [ 1 ] . split ( ']' ) [ 0 ]
      if 15 - 15: I11i11Ii + Ii1I . o00O0oo - iIii1I11I1II1 / O0 % iIii1I11I1II1
      if 86 - 86: oOooOoO0Oo0O / OOooOOo * iII111i
     cookieJar = O00o ( cookie_jar_file )
     if 86 - 86: ii1IiI1i * i11i * Ii1I
     if cookie_jar_file :
      oO0Oo ( cookieJar , cookie_jar_file )
      if 58 - 58: o00O0oo
      if 5 - 5: i11iIiiIii % o0 - iII111i
      if 83 - 83: ii1IiI1i / Ii1I . ooOoO0o
    elif 'save[' in iI1IiiiIiI1Ii [ 'cookiejar' ] :
     cookie_jar_file = iI1IiiiIiI1Ii [ 'cookiejar' ] . split ( 'save[' ) [ 1 ] . split ( ']' ) [ 0 ]
     iiIi111iI = os . path . join ( OOoOoo , cookie_jar_file )
     if 78 - 78: iII111i + o0 + I1Ii111 - I1Ii111 . i11iIiiIii / i1iIi11iIIi1I
     oO0Oo ( cookieJar , cookie_jar_file )
   if iI1IiiiIiI1Ii [ 'page' ] and '$doregex' in iI1IiiiIiI1Ii [ 'page' ] :
    I11i11i1 = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'page' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if len ( I11i11i1 ) == 0 :
     I11i11i1 = 'http://regexfailed'
    iI1IiiiIiI1Ii [ 'page' ] = I11i11i1
    if 68 - 68: I11i11Ii . I11i11Ii - ii1IiI1i / Ii1I . o00O0oo / i1IIi
   if 'setcookie' in iI1IiiiIiI1Ii and iI1IiiiIiI1Ii [ 'setcookie' ] and '$doregex' in iI1IiiiIiI1Ii [ 'setcookie' ] :
    iI1IiiiIiI1Ii [ 'setcookie' ] = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'setcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if 'appendcookie' in iI1IiiiIiI1Ii and iI1IiiiIiI1Ii [ 'appendcookie' ] and '$doregex' in iI1IiiiIiI1Ii [ 'appendcookie' ] :
    iI1IiiiIiI1Ii [ 'appendcookie' ] = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'appendcookie' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 12 - 12: ii1IiI1i * i1IIi * Ii1I
    if 23 - 23: I11i / O0 / oOooOoO0Oo0O
   if 'post' in iI1IiiiIiI1Ii and '$doregex' in iI1IiiiIiI1Ii [ 'post' ] :
    iI1IiiiIiI1Ii [ 'post' ] = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'post' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
    if 49 - 49: Ii1I . i1 % OOooOOo / iII111i
    if 95 - 95: O0 * o0 * I1Ii111 . o00O0oo / iIii1I11I1II1
   if 'rawpost' in iI1IiiiIiI1Ii and '$doregex' in iI1IiiiIiI1Ii [ 'rawpost' ] :
    iI1IiiiIiI1Ii [ 'rawpost' ] = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'rawpost' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages , rawPost = True )
    if 28 - 28: I1Ii111 + OOooOOo - o00O0oo / iIii1I11I1II1 - oOooOoO0Oo0O
    if 45 - 45: O0 / i1IIi * OOooOOo * i1iIi11iIIi1I
   if 'rawpost' in iI1IiiiIiI1Ii and '$epoctime$' in iI1IiiiIiI1Ii [ 'rawpost' ] :
    iI1IiiiIiI1Ii [ 'rawpost' ] = iI1IiiiIiI1Ii [ 'rawpost' ] . replace ( '$epoctime$' , II11I ( ) )
    if 31 - 31: iII111i
   if 'rawpost' in iI1IiiiIiI1Ii and '$epoctime2$' in iI1IiiiIiI1Ii [ 'rawpost' ] :
    iI1IiiiIiI1Ii [ 'rawpost' ] = iI1IiiiIiI1Ii [ 'rawpost' ] . replace ( '$epoctime2$' , i11iIIi ( ) )
    if 93 - 93: o00O0oo / I11i * OoooooooOO - i11iIiiIii / oOooOoO0Oo0O
    if 13 - 13: ii1IiI1i / i11iIiiIii
   OoOoO = ''
   if iI1IiiiIiI1Ii [ 'page' ] and iI1IiiiIiI1Ii [ 'page' ] in cachedPages and not 'ignorecache' in iI1IiiiIiI1Ii and forCookieJarOnly == False :
    if 32 - 32: i1 + oOooOoO0Oo0O . ooOoO0o
    OoOoO = cachedPages [ iI1IiiiIiI1Ii [ 'page' ] ]
   else :
    if iI1IiiiIiI1Ii [ 'page' ] and not iI1IiiiIiI1Ii [ 'page' ] == '' and iI1IiiiIiI1Ii [ 'page' ] . startswith ( 'http' ) :
     if '$epoctime$' in iI1IiiiIiI1Ii [ 'page' ] :
      iI1IiiiIiI1Ii [ 'page' ] = iI1IiiiIiI1Ii [ 'page' ] . replace ( '$epoctime$' , II11I ( ) )
     if '$epoctime2$' in iI1IiiiIiI1Ii [ 'page' ] :
      iI1IiiiIiI1Ii [ 'page' ] = iI1IiiiIiI1Ii [ 'page' ] . replace ( '$epoctime2$' , i11iIIi ( ) )
      if 41 - 41: o0 . i11iIiiIii / Ii1I
      if 98 - 98: o0 % i11i
     OoO0O000 = iI1IiiiIiI1Ii [ 'page' ] . split ( '|' )
     II1Ii = OoO0O000 [ 0 ]
     Ii1iiII1i = None
     if len ( OoO0O000 ) > 1 :
      Ii1iiII1i = OoO0O000 [ 1 ]
      if 52 - 52: OOooOOo / ooOoO0o
      if 91 - 91: I1Ii111 . I11i11Ii + i11i
      if 36 - 36: O0 * i1iIi11iIIi1I % IiII * IiII / i1iIi11iIIi1I * I1Ii111
      if 14 - 14: i1IIi . I1Ii111 + O0 * o00O0oo
      if 76 - 76: i1iIi11iIIi1I
      if 92 - 92: Ii1I - iIii1I11I1II1 % OoooooooOO
      if 39 - 39: IiII . oOooOoO0Oo0O * o0 - i11iIiiIii
      if 1 - 1: IiII * o0
      if 66 - 66: o0 + i1IIi % i11i . O0 * ii1IiI1i % ii1IiI1i
      if 87 - 87: I11i + i1 . IiII - OoooooooOO
     iiiiI1IiI1I1 = urllib2 . ProxyHandler ( urllib2 . getproxies ( ) )
     if 19 - 19: iII111i
     if 55 - 55: I11i % I11i / O0 % IiII - i1 . I11i11Ii
     if 49 - 49: iIii1I11I1II1 * i1IIi . OoooooooOO
     ooO = urllib2 . Request ( II1Ii )
     if 'proxy' in iI1IiiiIiI1Ii :
      OOOO0oOo00O = iI1IiiiIiI1Ii [ 'proxy' ]
      if 32 - 32: I1Ii111 % iII111i - oOooOoO0Oo0O
      if 71 - 71: IiII
      if II1Ii [ : 5 ] == "https" :
       Iiii1i11ii1Ii = urllib2 . ProxyHandler ( { 'https' : OOOO0oOo00O } )
       if 12 - 12: I11i . iII111i
      else :
       Iiii1i11ii1Ii = urllib2 . ProxyHandler ( { 'http' : OOOO0oOo00O } )
       if 79 - 79: ooOoO0o / I11i11Ii / IiII . ooOoO0o * OoooooooOO + i1
      II1 = urllib2 . build_opener ( Iiii1i11ii1Ii )
      urllib2 . install_opener ( II1 )
      if 73 - 73: O0 - ii1IiI1i
      if 2 - 2: i11i / ooOoO0o
     ooO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
     OOOO0oOo00O = None
     if 54 - 54: i1IIi . Ii1I - ii1IiI1i + o00O0oo + I11i11Ii / I11i11Ii
     if 'referer' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'Referer' , iI1IiiiIiI1Ii [ 'referer' ] )
     if 'accept' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'Accept' , iI1IiiiIiI1Ii [ 'accept' ] )
     if 'agent' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'User-agent' , iI1IiiiIiI1Ii [ 'agent' ] )
     if 'x-req' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'X-Requested-With' , iI1IiiiIiI1Ii [ 'x-req' ] )
     if 'x-addr' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'x-addr' , iI1IiiiIiI1Ii [ 'x-addr' ] )
     if 'x-forward' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'X-Forwarded-For' , iI1IiiiIiI1Ii [ 'x-forward' ] )
     if 'setcookie' in iI1IiiiIiI1Ii :
      if 22 - 22: o00O0oo . iIii1I11I1II1
      ooO . add_header ( 'Cookie' , iI1IiiiIiI1Ii [ 'setcookie' ] )
     if 'appendcookie' in iI1IiiiIiI1Ii :
      if 12 - 12: iII111i
      Ooii1IIi1ii = iI1IiiiIiI1Ii [ 'appendcookie' ]
      Ooii1IIi1ii = Ooii1IIi1ii . split ( ';' )
      for oo0OoOOooO in Ooii1IIi1ii :
       o0o0OO0o00o0O , IIIIIIi1i = oo0OoOOooO . split ( '=' )
       iiiii11I1 , o0o0OO0o00o0O = o0o0OO0o00o0O . split ( ':' )
       Ii1OOOo = cookielib . Cookie ( version = 0 , name = o0o0OO0o00o0O , value = IIIIIIi1i , port = None , port_specified = False , domain = iiiii11I1 , domain_specified = False , domain_initial_dot = False , path = '/' , path_specified = True , secure = False , expires = None , discard = True , comment = None , comment_url = None , rest = { 'HttpOnly' : None } , rfc2109 = False )
       cookieJar . set_cookie ( Ii1OOOo )
     if 'origin' in iI1IiiiIiI1Ii :
      ooO . add_header ( 'Origin' , iI1IiiiIiI1Ii [ 'origin' ] )
     if Ii1iiII1i :
      Ii1iiII1i = Ii1iiII1i . split ( '&' )
      for oo0OoOOooO in Ii1iiII1i :
       o0o0OO0o00o0O , IIIIIIi1i = oo0OoOOooO . split ( '=' )
       ooO . add_header ( o0o0OO0o00o0O , IIIIIIi1i )
       if 35 - 35: o00O0oo - i1iIi11iIIi1I . I11i11Ii * I11i11Ii / i11iIiiIii + ii1IiI1i
     if not cookieJar == None :
      if 87 - 87: o0 % iIii1I11I1II1
      o0O = urllib2 . HTTPCookieProcessor ( cookieJar )
      II1 = urllib2 . build_opener ( o0O , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      II1 = urllib2 . install_opener ( II1 )
      if 69 - 69: I1Ii111 + I11i11Ii - o00O0oo + OOooOOo
      if 36 - 36: i11iIiiIii / IiII . Ii1I + I1Ii111 . O0 + oOooOoO0Oo0O
      if 'noredirect' in iI1IiiiIiI1Ii :
       II1 = urllib2 . build_opener ( o0O , Ii , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
       II1 = urllib2 . install_opener ( II1 )
     elif 'noredirect' in iI1IiiiIiI1Ii :
      II1 = urllib2 . build_opener ( Ii , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
      II1 = urllib2 . install_opener ( II1 )
      if 36 - 36: i1IIi - ii1IiI1i - ooOoO0o
      if 7 - 7: i11iIiiIii + oOooOoO0Oo0O
     if 'connection' in iI1IiiiIiI1Ii :
      if 47 - 47: ooOoO0o - I11i / o00O0oo - I11i11Ii + IiII - iIii1I11I1II1
      from keepalive import HTTPHandler
      o0OOOOO0 = HTTPHandler ( )
      II1 = urllib2 . build_opener ( o0OOOOO0 )
      urllib2 . install_opener ( II1 )
      if 79 - 79: i11i - o00O0oo . i1IIi + O0 % O0 * oOooOoO0Oo0O
      if 7 - 7: i1IIi + I11i % IiII / i1 + i1IIi
      if 41 - 41: iII111i + i11iIiiIii / I1Ii111 % ii1IiI1i
     II1II1IIII = None
     if 37 - 37: OoooooooOO
     if 'post' in iI1IiiiIiI1Ii :
      oo0ooO0 = iI1IiiiIiI1Ii [ 'post' ]
      if 65 - 65: i1iIi11iIIi1I - iIii1I11I1II1
      if 20 - 20: o0 % ii1IiI1i
      if 44 - 44: OoooooooOO . i11i . I11i % OoooooooOO
      if 86 - 86: i11iIiiIii + O0 * I1Ii111 - i1iIi11iIIi1I * I11i + O0
      Oo0 = oo0ooO0 . split ( ',' ) ;
      II1II1IIII = { }
      for O00o0oo0oOO in Oo0 :
       o0o0OO0o00o0O = O00o0oo0oOO . split ( ':' ) [ 0 ] ;
       IIIIIIi1i = O00o0oo0oOO . split ( ':' ) [ 1 ] ;
       II1II1IIII [ o0o0OO0o00o0O ] = IIIIIIi1i
      II1II1IIII = urllib . urlencode ( II1II1IIII )
      if 75 - 75: iIii1I11I1II1 + OoooooooOO
     if 'rawpost' in iI1IiiiIiI1Ii :
      II1II1IIII = iI1IiiiIiI1Ii [ 'rawpost' ]
      if 97 - 97: ii1IiI1i / I11i11Ii + ooOoO0o
      if 32 - 32: o00O0oo % ooOoO0o * I11i11Ii
      if 72 - 72: o00O0oo . IiII - ooOoO0o - iII111i % i1IIi
      if 56 - 56: I11i11Ii * IiII
     OoOoO = ''
     try :
      if 13 - 13: I11i11Ii * I11i11Ii * i11i * IiII . i1IIi / I1Ii111
      if II1II1IIII :
       O00OOOOOoo0 = urllib2 . urlopen ( ooO , II1II1IIII )
      else :
       O00OOOOOoo0 = urllib2 . urlopen ( ooO )
      if O00OOOOOoo0 . info ( ) . get ( 'Content-Encoding' ) == 'gzip' :
       from StringIO import StringIO
       import gzip
       Ii1IIiiIIi = StringIO ( O00OOOOOoo0 . read ( ) )
       Oo000o = gzip . GzipFile ( fileobj = Ii1IIiiIIi )
       OoOoO = Oo000o . read ( )
      else :
       OoOoO = O00OOOOOoo0 . read ( )
       if 92 - 92: iII111i * i11iIiiIii + IiII * ooOoO0o
       if 48 - 48: Ii1I * IiII * IiII
       if 70 - 70: OOooOOo + Ii1I % i11iIiiIii + O0
      if 'proxy' in iI1IiiiIiI1Ii and not iiiiI1IiI1I1 is None :
       urllib2 . install_opener ( urllib2 . build_opener ( iiiiI1IiI1I1 ) )
       if 65 - 65: iIii1I11I1II1 % OOooOOo + O0 / OoooooooOO
      OoOoO = O0000oO0o00 ( OoOoO )
      if 80 - 80: OoooooooOO + I1Ii111
      if 95 - 95: ooOoO0o / OOooOOo * ooOoO0o - OoooooooOO * OoooooooOO % i1iIi11iIIi1I
      if 'includeheaders' in iI1IiiiIiI1Ii :
       if 43 - 43: I11i11Ii . ooOoO0o
       OoOoO += '$$HEADERS_START$$:'
       for oO0Ooooooo in O00OOOOOoo0 . headers :
        OoOoO += oO0Ooooooo + ':' + O00OOOOOoo0 . headers . get ( oO0Ooooooo ) + '\n'
       OoOoO += '$$HEADERS_END$$:'
       if 12 - 12: ooOoO0o + I11i + Ii1I . I1Ii111 / iII111i
      oo0oO0oOOoo ( OoOoO )
      oo0oO0oOOoo ( cookieJar )
      if 29 - 29: I1Ii111 . o00O0oo - i11i
      O00OOOOOoo0 . close ( )
     except :
      pass
     cachedPages [ iI1IiiiIiI1Ii [ 'page' ] ] = OoOoO
     if 68 - 68: iIii1I11I1II1 + i11i / OOooOOo
     if 91 - 91: o0 % iIii1I11I1II1 . oOooOoO0Oo0O
     if 70 - 70: Ii1I % i11i % O0 . i1IIi / ooOoO0o
     if forCookieJarOnly :
      return cookieJar
    elif iI1IiiiIiI1Ii [ 'page' ] and not iI1IiiiIiI1Ii [ 'page' ] . startswith ( 'http' ) :
     if iI1IiiiIiI1Ii [ 'page' ] . startswith ( '$pyFunction:' ) :
      OO0ooOoOO0OOo = OooOoooo0000 ( iI1IiiiIiI1Ii [ 'page' ] . split ( '$pyFunction:' ) [ 1 ] , '' , cookieJar , iI1IiiiIiI1Ii )
      if forCookieJarOnly :
       return cookieJar
      OoOoO = OO0ooOoOO0OOo
      OoOoO = O0000oO0o00 ( OoOoO )
     else :
      OoOoO = iI1IiiiIiI1Ii [ 'page' ]
   if '$pyFunction:playmedia(' in iI1IiiiIiI1Ii [ 'expres' ] or 'ActivateWindow' in iI1IiiiIiI1Ii [ 'expres' ] or '$PLAYERPROXY$=' in url or any ( x in url for x in I1 ) :
    iII1ii1I1i = False
   if '$doregex' in iI1IiiiIiI1Ii [ 'expres' ] :
    iI1IiiiIiI1Ii [ 'expres' ] = o0O0oo0o ( regexs , iI1IiiiIiI1Ii [ 'expres' ] , cookieJar , recursiveCall = True , cachedPages = cachedPages )
   if not iI1IiiiIiI1Ii [ 'expres' ] == '' :
    if 29 - 29: iII111i - oOooOoO0Oo0O / oOooOoO0Oo0O * iII111i * I1Ii111 . I11i
    if '$LiveStreamCaptcha' in iI1IiiiIiI1Ii [ 'expres' ] :
     OO0ooOoOO0OOo = oooI11iI1I ( iI1IiiiIiI1Ii , OoOoO , cookieJar )
     if 50 - 50: iIii1I11I1II1 * I1Ii111 . OoooooooOO / i11i - ii1IiI1i * ii1IiI1i
     url = url . replace ( "$doregex[" + iiI1 + "]" , OO0ooOoOO0OOo )
     if 98 - 98: i1iIi11iIIi1I - iII111i . I1Ii111 % i11iIiiIii
    elif iI1IiiiIiI1Ii [ 'expres' ] . startswith ( '$pyFunction:' ) or '#$pyFunction' in iI1IiiiIiI1Ii [ 'expres' ] :
     if 69 - 69: ii1IiI1i + IiII * O0 . I11i % o0
     OO0ooOoOO0OOo = ''
     if iI1IiiiIiI1Ii [ 'expres' ] . startswith ( '$pyFunction:' ) :
      OO0ooOoOO0OOo = OooOoooo0000 ( iI1IiiiIiI1Ii [ 'expres' ] . split ( '$pyFunction:' ) [ 1 ] , OoOoO , cookieJar , iI1IiiiIiI1Ii )
     else :
      OO0ooOoOO0OOo = O0O000O ( iI1IiiiIiI1Ii [ 'expres' ] , OoOoO , cookieJar , iI1IiiiIiI1Ii )
     if 'ActivateWindow' in iI1IiiiIiI1Ii [ 'expres' ] : return
     if 22 - 22: OOooOOo
     if 33 - 33: O0
     if 96 - 96: OoooooooOO + I1Ii111 * O0
     try :
      url = url . replace ( u"$doregex[" + iiI1 + "]" , OO0ooOoOO0OOo )
     except : url = url . replace ( "$doregex[" + iiI1 + "]" , OO0ooOoOO0OOo . decode ( "utf-8" ) )
    else :
     if 'listrepeat' in iI1IiiiIiI1Ii :
      oo0OoOO0o0o = iI1IiiiIiI1Ii [ 'listrepeat' ]
      OO0OOO00 = re . findall ( iI1IiiiIiI1Ii [ 'expres' ] , OoOoO )
      return oo0OoOO0o0o , OO0OOO00 , iI1IiiiIiI1Ii , regexs
      if 62 - 62: i11iIiiIii + o0 + i1IIi
     OO0ooOoOO0OOo = ''
     if not OoOoO == '' :
      if 69 - 69: o0
      OO0Oo = re . compile ( iI1IiiiIiI1Ii [ 'expres' ] ) . search ( OoOoO )
      try :
       OO0ooOoOO0OOo = OO0Oo . group ( 1 ) . strip ( )
      except : traceback . print_exc ( )
      if iI1IiiiIiI1Ii [ 'page' ] == '' :
       OO0ooOoOO0OOo = iI1IiiiIiI1Ii [ 'expres' ]
       if 13 - 13: i1 * i11iIiiIii / i11iIiiIii . i1iIi11iIIi1I . I11i . ii1IiI1i
     if rawPost :
      if 26 - 26: i1 . iIii1I11I1II1
      OO0ooOoOO0OOo = urllib . quote_plus ( OO0ooOoOO0OOo )
     if 'htmlunescape' in iI1IiiiIiI1Ii :
      if 67 - 67: I11i11Ii / O0
      import HTMLParser
      OO0ooOoOO0OOo = HTMLParser . HTMLParser ( ) . unescape ( OO0ooOoOO0OOo )
     try :
      url = url . replace ( "$doregex[" + iiI1 + "]" , OO0ooOoOO0OOo )
     except : url = url . replace ( "$doregex[" + iiI1 + "]" , OO0ooOoOO0OOo . decode ( "utf-8" ) )
     if 88 - 88: o0 - I11i
     if 63 - 63: I1Ii111 * OoooooooOO
   else :
    url = url . replace ( "$doregex[" + iiI1 + "]" , '' )
 if '$epoctime$' in url :
  url = url . replace ( '$epoctime$' , II11I ( ) )
 if '$epoctime2$' in url :
  url = url . replace ( '$epoctime2$' , i11iIIi ( ) )
  if 19 - 19: I1Ii111 - i1 . iIii1I11I1II1 . o0 / I11i
 if '$GUID$' in url :
  import uuid
  url = url . replace ( '$GUID$' , str ( uuid . uuid1 ( ) ) . upper ( ) )
 if '$get_cookies$' in url :
  url = url . replace ( '$get_cookies$' , OOO0O00Oo ( cookieJar ) )
  if 13 - 13: iIii1I11I1II1
 if recursiveCall : return url
 if 2 - 2: i1IIi * OOooOOo - OOooOOo + OoooooooOO % o0 / o0
 if url == "" :
  return
 else :
  return url , iII1ii1I1i
  if 3 - 3: OoooooooOO
def O0OoO0o ( t ) :
 import hashlib
 oo0OoOOooO = hashlib . md5 ( )
 oo0OoOOooO . update ( t )
 return oo0OoOOooO . hexdigest ( )
 if 1 - 1: o00O0oo % Ii1I * ii1IiI1i - i11i
def iI11I1IIi ( encrypted ) :
 III1I1i = ""
 for OO0ooOoOO0OOo in encrypted . split ( ':' ) :
  III1I1i += chr ( int ( OO0ooOoOO0OOo . replace ( "0m0" , "" ) ) / 84 / 5 )
 return III1I1i
 if 29 - 29: i1IIi + i1IIi
def o0Ooo0000 ( media_url ) :
 try :
  import CustomPlayer
  II11IiIi11 = CustomPlayer . MyXBMCPlayer ( )
  O0Oo00ooOoO = xbmcgui . ListItem ( label = str ( oO0o00oOOooO0 ) , iconImage = "DefaultVideo.png" , thumbnailImage = xbmc . getInfoImage ( "ListItem.Thumb" ) , path = media_url )
  II11IiIi11 . play ( media_url , O0Oo00ooOoO )
  xbmc . sleep ( 1000 )
  while II11IiIi11 . is_active :
   xbmc . sleep ( 200 )
 except :
  traceback . print_exc ( )
 return ''
 if 100 - 100: i11iIiiIii / i11iIiiIii
def o00iIiiiII ( params ) :
 ii1 = json . dumps ( params )
 iIIi = xbmc . executeJSONRPC ( ii1 )
 if 5 - 5: OoooooooOO / i1 % Ii1I % i1iIi11iIIi1I * IiII + iIii1I11I1II1
 try :
  O00OOOOOoo0 = json . loads ( iIIi )
 except UnicodeDecodeError :
  O00OOOOOoo0 = json . loads ( iIIi . decode ( 'utf-8' , 'ignore' ) )
  if 11 - 11: ooOoO0o % i11iIiiIii % OOooOOo . I1Ii111
 try :
  if 'result' in O00OOOOOoo0 :
   return O00OOOOOoo0 [ 'result' ]
  return None
 except KeyError :
  logger . warn ( "[%s] %s" % ( params [ 'method' ] , O00OOOOOoo0 [ 'error' ] [ 'message' ] ) )
  return None
  if 92 - 92: i11i
  if 45 - 45: O0 % oOooOoO0Oo0O - IiII . i1iIi11iIIi1I
def I1IIiIIi1Ii1III ( proxysettings = None ) :
 if 86 - 86: i11iIiiIii + i11iIiiIii . ooOoO0o % oOooOoO0Oo0O . o00O0oo
 if proxysettings == None :
  if 17 - 17: iII111i
  xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy", "value":false}, "id":1}' )
 else :
  if 67 - 67: O0 * Ii1I - i1 - i11i
  Ii11iiI1 = proxysettings . split ( ':' )
  oO0O = Ii11iiI1 [ 0 ]
  OOoooO00o0o = Ii11iiI1 [ 1 ]
  I1ii1Ii1 = Ii11iiI1 [ 2 ]
  OoO = None
  oOiI111I1III = None
  if 36 - 36: Ii1I % I11i
  if len ( Ii11iiI1 ) > 3 and '@' in Ii11iiI1 [ 3 ] :
   OoO = Ii11iiI1 [ 3 ] . split ( '@' ) [ 0 ]
   oOiI111I1III = Ii11iiI1 [ 3 ] . split ( '@' ) [ 1 ]
   if 72 - 72: oOooOoO0Oo0O / IiII - O0 + Ii1I
   if 83 - 83: O0
  xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.usehttpproxy", "value":true}, "id":1}' )
  xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxytype", "value":' + str ( I1ii1Ii1 ) + '}, "id":1}' )
  xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyserver", "value":"' + str ( oO0O ) + '"}, "id":1}' )
  xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyport", "value":' + str ( OOoooO00o0o ) + '}, "id":1}' )
  if 89 - 89: I11i11Ii + ii1IiI1i - i1
  if 40 - 40: i1iIi11iIIi1I + i1iIi11iIIi1I
  if not OoO == None :
   xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxyusername", "value":"' + str ( OoO ) + '"}, "id":1}' )
   xbmc . executeJSONRPC ( '{"jsonrpc":"2.0", "method":"Settings.SetSettingValue", "params":{"setting":"network.httpproxypassword", "value":"' + str ( oOiI111I1III ) + '"}, "id":1}' )
   if 94 - 94: IiII * iIii1I11I1II1 . Ii1I
   if 13 - 13: iIii1I11I1II1 * o0 / ooOoO0o % o00O0oo + OOooOOo
def iiiI1iI1 ( ) :
 I1oOoO0OOO00O = o00iIiiiII ( { 'jsonrpc' : '2.0' , "method" : "Settings.GetSettingValue" , "params" : { "setting" : "network.usehttpproxy" } , 'id' : 1 } ) [ 'value' ]
 if 73 - 73: i1 % i1iIi11iIIi1I + I1Ii111 + oOooOoO0Oo0O
 I1ii1Ii1 = o00iIiiiII ( { 'jsonrpc' : '2.0' , "method" : "Settings.GetSettingValue" , "params" : { "setting" : "network.httpproxytype" } , 'id' : 1 } ) [ 'value' ]
 if 80 - 80: i1IIi + i1 + I1Ii111 * Ii1I
 if I1oOoO0OOO00O :
  oO0O = o00iIiiiII ( { 'jsonrpc' : '2.0' , "method" : "Settings.GetSettingValue" , "params" : { "setting" : "network.httpproxyserver" } , 'id' : 1 } ) [ 'value' ]
  OOoooO00o0o = unicode ( o00iIiiiII ( { 'jsonrpc' : '2.0' , "method" : "Settings.GetSettingValue" , "params" : { "setting" : "network.httpproxyport" } , 'id' : 1 } ) [ 'value' ] )
  OoO = o00iIiiiII ( { 'jsonrpc' : '2.0' , "method" : "Settings.GetSettingValue" , "params" : { "setting" : "network.httpproxyusername" } , 'id' : 1 } ) [ 'value' ]
  oOiI111I1III = o00iIiiiII ( { 'jsonrpc' : '2.0' , "method" : "Settings.GetSettingValue" , "params" : { "setting" : "network.httpproxypassword" } , 'id' : 1 } ) [ 'value' ]
  if 65 - 65: ii1IiI1i % Ii1I % iIii1I11I1II1 - OoooooooOO - ii1IiI1i - O0
  if OoO and oOiI111I1III and oO0O and OOoooO00o0o :
   return oO0O + ':' + str ( OOoooO00o0o ) + ':' + str ( I1ii1Ii1 ) + ':' + OoO + '@' + oOiI111I1III
  elif oO0O and OOoooO00o0o :
   return oO0O + ':' + str ( OOoooO00o0o ) + ':' + str ( I1ii1Ii1 )
 else :
  return None
  if 58 - 58: I1Ii111 + iIii1I11I1II1
  if 94 - 94: iII111i . i1IIi
def O0OOo0o ( media_url , name , iconImage , proxyip , port , proxyuser = None , proxypass = None ) :
 if 44 - 44: oOooOoO0Oo0O * iIii1I11I1II1 / O0
 Ii1IIi = xbmcgui . DialogProgress ( )
 Ii1IIi . create ( 'Progress' , 'Playing with custom proxy' )
 Ii1IIi . update ( 10 , "" , "setting proxy.." , "" )
 iiiIi = False
 ooiiI1ii = ''
 if 76 - 76: iII111i + iIii1I11I1II1 + o0 . i1iIi11iIIi1I
 try :
  if 49 - 49: I1Ii111 / o00O0oo / I11i
  ooiiI1ii = iiiI1iI1 ( )
  print 'existing_proxy' , ooiiI1ii
  if 25 - 25: oOooOoO0Oo0O % O0 + i1IIi - o00O0oo
  if 38 - 38: i1 % ooOoO0o + i11iIiiIii + IiII + o00O0oo / i11iIiiIii
  if not proxyuser == None :
   I1IIiIIi1Ii1III ( proxyip + ':' + port + ':0:' + proxyuser + '@' + proxypass )
  else :
   I1IIiIIi1Ii1III ( proxyip + ':' + port + ':0' )
   if 94 - 94: IiII - I11i11Ii + OOooOOo
   if 59 - 59: Ii1I . oOooOoO0Oo0O - iIii1I11I1II1 + iIii1I11I1II1
  iiiIi = True
  Ii1IIi . update ( 80 , "" , "setting proxy complete, now playing" , "" )
  if 56 - 56: OOooOOo + o00O0oo
  Ii1IIi . close ( )
  Ii1IIi = None
  import CustomPlayer
  II11IiIi11 = CustomPlayer . MyXBMCPlayer ( )
  O0Oo00ooOoO = xbmcgui . ListItem ( label = str ( name ) , iconImage = iconImage , thumbnailImage = xbmc . getInfoImage ( "ListItem.Thumb" ) , path = media_url )
  II11IiIi11 . play ( media_url , O0Oo00ooOoO )
  xbmc . sleep ( 1000 )
  while II11IiIi11 . is_active :
   xbmc . sleep ( 200 )
 except :
  traceback . print_exc ( )
 if Ii1IIi :
  Ii1IIi . close ( )
 if iiiIi :
  if 32 - 32: i11i + o0 % o00O0oo / o0 + ii1IiI1i
  I1IIiIIi1Ii1III ( ooiiI1ii )
  if 2 - 2: i11iIiiIii - ooOoO0o + i1iIi11iIIi1I % Ii1I * iII111i
 return ''
 if 54 - 54: O0 - IiII . I11i % IiII + IiII
 if 36 - 36: I11i % i11iIiiIii
def Iiii1Ii ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  ooOOo00oo0 = page_value
  page_value = ii11II ( page_value , headers = referer )
  if 40 - 40: o0 - I11i - I11i - O0 - O0 . i11i
 o0o000Oo = "(eval\(function\(p,a,c,k,e,(?:r|d).*)"
 if 57 - 57: OOooOOo * O0 * ooOoO0o
 I1II1 = re . compile ( o0o000Oo ) . findall ( page_value )
 iiIiI1ii = ""
 if I1II1 and len ( I1II1 ) > 0 :
  for IIIIIIi1i in I1II1 :
   oOOoo = I1oo ( IIIIIIi1i )
   iiI1IIIii = iIi1III1I ( oOOoo , '\'(.*?)\'' )
   if 'unescape' in oOOoo :
    oOOoo = urllib . unquote ( iiI1IIIii )
   iiIiI1ii += oOOoo + '\n'
   if 24 - 24: oOooOoO0Oo0O . ooOoO0o % iII111i
   if 62 - 62: ii1IiI1i - O0 . oOooOoO0Oo0O . O0 * iIii1I11I1II1
  ooOOo00oo0 = iIi1III1I ( iiIiI1ii , 'src="(.*?)"' )
  if 92 - 92: OOooOOo / I11i . ii1IiI1i
  page_value = ii11II ( ooOOo00oo0 , headers = referer )
  if 30 - 30: iII111i . ii1IiI1i / I11i
  if 2 - 2: I1Ii111 % oOooOoO0Oo0O - ooOoO0o
  if 79 - 79: OoooooooOO / ii1IiI1i . O0
 oOoO0Oo0 = iIi1III1I ( page_value , 'streamer\'.*?\'(.*?)\'\)' )
 i11i11i = iIi1III1I ( page_value , 'file\',\s\'(.*?)\'' )
 if 31 - 31: i11iIiiIii + I11i - O0
 if 51 - 51: i1iIi11iIIi1I * i1IIi / iII111i * I11i + o00O0oo % ii1IiI1i
 return oOoO0Oo0 + ' playpath=' + i11i11i + ' pageUrl=' + ooOOo00oo0
 if 34 - 34: OOooOOo * OoooooooOO + iII111i + i11iIiiIii
def iiIi ( page_value , referer = None ) :
 if referer :
  referer = [ ( 'Referer' , referer ) ]
 if page_value . startswith ( "http" ) :
  page_value = ii11II ( page_value , headers = referer )
 o0o000Oo = "var a = (.*?);\s*var b = (.*?);\s*var c = (.*?);\s*var d = (.*?);\s*var f = (.*?);\s*var v_part = '(.*?)';"
 I1II1 = re . compile ( o0o000Oo ) . findall ( page_value ) [ 0 ]
 if 74 - 74: Ii1I / OoooooooOO / I11i11Ii * i11iIiiIii . i11i . OoooooooOO
 I111I11I111 , oO0Ooooooo , Iiiiiii1 , Ooi1IIii11i1I1 , Oo000o , IIIIIIi1i = ( I1II1 )
 Oo000o = int ( Oo000o )
 I111I11I111 = int ( I111I11I111 ) / Oo000o
 oO0Ooooooo = int ( oO0Ooooooo ) / Oo000o
 Iiiiiii1 = int ( Iiiiiii1 ) / Oo000o
 Ooi1IIii11i1I1 = int ( Ooi1IIii11i1I1 ) / Oo000o
 if 12 - 12: i1IIi / I11i % o00O0oo * I1Ii111 * O0 * iIii1I11I1II1
 OO0OOO00 = 'rtmp://' + str ( I111I11I111 ) + '.' + str ( oO0Ooooooo ) + '.' + str ( Iiiiiii1 ) + '.' + str ( Ooi1IIii11i1I1 ) + IIIIIIi1i ;
 return OO0OOO00
 if 93 - 93: I11i11Ii / ii1IiI1i + i1IIi * OOooOOo . OoooooooOO
def Oo000 ( url , useragent = None ) :
 str = '#EXTM3U'
 str += '\n#EXT-X-STREAM-INF:PROGRAM-ID=1,BANDWIDTH=361816'
 str += '\n' + url + '&bytes=0-200000'
 o00oooO0Oo = os . path . join ( OOoOoo , 'testfile.m3u' )
 str += '\n'
 OoOOIIIIIiI11Ii ( o00oooO0Oo , str )
 if 41 - 41: i11iIiiIii - i1IIi / I11i11Ii * I1Ii111 / ooOoO0o - I11i11Ii
 return o00oooO0Oo
 if 56 - 56: O0
def OoOOIIIIIiI11Ii ( file_name , page_data , append = False ) :
 if append :
  Oo000o = open ( file_name , 'a' )
  Oo000o . write ( page_data )
  Oo000o . close ( )
 else :
  Oo000o = open ( file_name , 'wb' )
  Oo000o . write ( page_data )
  Oo000o . close ( )
  return ''
  if 45 - 45: o0 - i1iIi11iIIi1I - o0
def IIiiI ( file_name ) :
 Oo000o = open ( file_name , 'rb' )
 Ooi1IIii11i1I1 = Oo000o . read ( )
 Oo000o . close ( )
 return Ooi1IIii11i1I1
 if 36 - 36: IiII
def O0ooooooo00 ( page_data ) :
 import re , base64 , urllib ;
 I1111ii11IIII = page_data
 while 'geh(' in I1111ii11IIII :
  if I1111ii11IIII . startswith ( 'lol(' ) : I1111ii11IIII = I1111ii11IIII [ 5 : - 1 ]
  if 48 - 48: iIii1I11I1II1 % i1IIi + o0 % i1
  I1111ii11IIII = re . compile ( '"(.*?)"' ) . findall ( I1111ii11IIII ) [ 0 ] ;
  I1111ii11IIII = base64 . b64decode ( I1111ii11IIII ) ;
  I1111ii11IIII = urllib . unquote ( I1111ii11IIII ) ;
 print I1111ii11IIII
 return I1111ii11IIII
 if 79 - 79: o0 % oOooOoO0Oo0O % iII111i / i1IIi % i1iIi11iIIi1I
def oo0o00OO ( page_data ) :
 print 'get_dag_url2' , page_data
 oOoo00o0oOO = ii11II ( page_data ) ;
 OoOOooOO0ooOo = '(http.*)'
 import uuid
 oo0oIi = str ( uuid . uuid1 ( ) ) . upper ( )
 oOooOOo00ooO = re . compile ( OoOOooOO0ooOo ) . findall ( oOoo00o0oOO )
 o0OO0oooo = [ ( 'X-Playback-Session-Id' , oo0oIi ) ]
 for I11II1i1 in oOooOOo00ooO :
  try :
   IiI1ii11I1 = ii11II ( I11II1i1 , headers = o0OO0oooo ) ;
   if 19 - 19: ooOoO0o + I1Ii111 / OOooOOo / i11i
  except : pass
  if 92 - 92: i1IIi % o00O0oo + o00O0oo - iIii1I11I1II1 . iII111i
 return page_data + '|&X-Playback-Session-Id=' + oo0oIi
 if 33 - 33: i1 / O0 + I11i
 if 75 - 75: I1Ii111 % i11iIiiIii + iIii1I11I1II1
def oOoOo0o00o ( page_data ) :
 print 'get_dag_url' , page_data
 if page_data . startswith ( 'http://dag.total-stream.net' ) :
  o0OO0oooo = [ ( 'User-Agent' , 'Verismo-BlackUI_(2.4.7.5.8.0.34)' ) ]
  page_data = ii11II ( page_data , headers = o0OO0oooo ) ;
  if 2 - 2: i11i
 if '127.0.0.1' in page_data :
  return o0ooo0o0 ( page_data )
 elif iIi1III1I ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  O00Oooo00 = iIi1III1I ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + iIi1III1I ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + iIi1III1I ( page_data , '\\?y=([^&]+)&' )
 else :
  O00Oooo00 = iIi1III1I ( page_data , 'href="([^"]+)"[^"]+$' )
  if len ( O00Oooo00 ) == 0 :
   O00Oooo00 = page_data
 O00Oooo00 = O00Oooo00 . replace ( ' ' , '%20' )
 return O00Oooo00
 if 93 - 93: O0 / o00O0oo + oOooOoO0Oo0O
def iIi1III1I ( data , re_patten ) :
 IIIII1iii = ''
 iI1IiiiIiI1Ii = re . search ( re_patten , data )
 if iI1IiiiIiI1Ii != None :
  IIIII1iii = iI1IiiiIiI1Ii . group ( 1 )
 else :
  IIIII1iii = ''
 return IIIII1iii
 if 20 - 20: I1Ii111 / IiII % OoooooooOO / iIii1I11I1II1 + oOooOoO0Oo0O
def o0ooo0o0 ( page_data ) :
 O00Oooo00 = ''
 if '127.0.0.1' in page_data :
  O00Oooo00 = iIi1III1I ( page_data , '&ver_t=([^&]+)&' ) + ' live=true timeout=15 playpath=' + iIi1III1I ( page_data , '\\?y=([a-zA-Z0-9-_\\.@]+)' )
  if 57 - 57: i1 / ooOoO0o
 if iIi1III1I ( page_data , 'token=([^&]+)&' ) != '' :
  O00Oooo00 = O00Oooo00 + '?token=' + iIi1III1I ( page_data , 'token=([^&]+)&' )
 elif iIi1III1I ( page_data , 'wmsAuthSign%3D([^%&]+)' ) != '' :
  O00Oooo00 = iIi1III1I ( page_data , '&ver_t=([^&]+)&' ) + '?wmsAuthSign=' + iIi1III1I ( page_data , 'wmsAuthSign%3D([^%&]+)' ) + '==/mp4:' + iIi1III1I ( page_data , '\\?y=([^&]+)&' )
 else :
  O00Oooo00 = iIi1III1I ( page_data , 'HREF="([^"]+)"' )
  if 13 - 13: OoooooooOO + i1iIi11iIIi1I
 if 'dag1.asx' in O00Oooo00 :
  return oOoOo0o00o ( O00Oooo00 )
  if 32 - 32: O0 + OOooOOo % I11i11Ii
 if 'devinlivefs.fplive.net' not in O00Oooo00 :
  O00Oooo00 = O00Oooo00 . replace ( 'devinlive' , 'flive' )
 if 'permlivefs.fplive.net' not in O00Oooo00 :
  O00Oooo00 = O00Oooo00 . replace ( 'permlive' , 'flive' )
 return O00Oooo00
 if 7 - 7: ii1IiI1i / o00O0oo
 if 11 - 11: I1Ii111 * o00O0oo / o00O0oo - I11i
def OoO0o0OOOO ( str_eval ) :
 II1i = ""
 try :
  O00Oo = "w,i,s,e=(" + str_eval + ')'
  exec ( O00Oo )
  II1i = iii ( w , I11iiiii1II , I1111ii11IIII , e )
 except : traceback . print_exc ( file = sys . stdout )
 if 93 - 93: Ii1I * i11i / iII111i - i1
 return II1i
 if 98 - 98: i11iIiiIii / oOooOoO0Oo0O * i1 / ooOoO0o
def iii ( w , i , s , e ) :
 o0OOoOo0oo = 0 ;
 ooO0 = 0 ;
 o0Iiii = 0 ;
 I1i1Ii1111iI1 = [ ] ;
 Oo0oOOOOo = [ ] ;
 while True :
  if ( o0OOoOo0oo < 5 ) :
   Oo0oOOOOo . append ( w [ o0OOoOo0oo ] )
  elif ( o0OOoOo0oo < len ( w ) ) :
   I1i1Ii1111iI1 . append ( w [ o0OOoOo0oo ] ) ;
  o0OOoOo0oo += 1 ;
  if ( ooO0 < 5 ) :
   Oo0oOOOOo . append ( i [ ooO0 ] )
  elif ( ooO0 < len ( i ) ) :
   I1i1Ii1111iI1 . append ( i [ ooO0 ] )
  ooO0 += 1 ;
  if ( o0Iiii < 5 ) :
   Oo0oOOOOo . append ( s [ o0Iiii ] )
  elif ( o0Iiii < len ( s ) ) :
   I1i1Ii1111iI1 . append ( s [ o0Iiii ] ) ;
  o0Iiii += 1 ;
  if ( len ( w ) + len ( i ) + len ( s ) + len ( e ) == len ( I1i1Ii1111iI1 ) + len ( Oo0oOOOOo ) + len ( e ) ) :
   break ;
   if 14 - 14: OoooooooOO . i1 . Ii1I
 I1IIIIIi1IIiI = '' . join ( I1i1Ii1111iI1 )
 III11I11ii = '' . join ( Oo0oOOOOo )
 ooO0 = 0 ;
 O0OoO0oO00 = [ ] ;
 for o0OOoOo0oo in range ( 0 , len ( I1i1Ii1111iI1 ) , 2 ) :
  if 2 - 2: ooOoO0o - ii1IiI1i + i1 * i1iIi11iIIi1I / IiII
  iIIiI11iI1Ii1 = - 1 ;
  if ( ord ( III11I11ii [ ooO0 ] ) % 2 ) :
   iIIiI11iI1Ii1 = 1 ;
   if 94 - 94: o00O0oo / i11iIiiIii % O0
  O0OoO0oO00 . append ( chr ( int ( I1IIIIIi1IIiI [ o0OOoOo0oo : o0OOoOo0oo + 2 ] , 36 ) - iIIiI11iI1Ii1 ) ) ;
  ooO0 += 1 ;
  if ( ooO0 >= len ( Oo0oOOOOo ) ) :
   ooO0 = 0 ;
 OO0OOO00 = '' . join ( O0OoO0oO00 )
 if 'eval(function(w,i,s,e)' in OO0OOO00 :
  if 70 - 70: Ii1I - I11i11Ii / OoooooooOO % OoooooooOO
  OO0OOO00 = re . compile ( 'eval\(function\(w,i,s,e\).*}\((.*?)\)' ) . findall ( OO0OOO00 ) [ 0 ]
  return OoO0o0OOOO ( OO0OOO00 )
 else :
  if 95 - 95: OoooooooOO % OoooooooOO . iII111i
  return OO0OOO00
  if 26 - 26: OOooOOo + I1Ii111 - i11i . i11i + ii1IiI1i + o0
  if 68 - 68: O0
def I1oo ( page_value , regex_for_text = '' , iterations = 1 , total_iteration = 1 ) :
 try :
  o0oOoO00 = None
  if page_value . startswith ( "http" ) :
   page_value = ii11II ( page_value )
   if 94 - 94: i1iIi11iIIi1I + I1Ii111 + o00O0oo
  if regex_for_text and len ( regex_for_text ) > 0 :
   try :
    page_value = re . compile ( regex_for_text ) . findall ( page_value ) [ 0 ]
   except : return 'NOTPACKED'
   if 82 - 82: I11i11Ii - I11i11Ii . iIii1I11I1II1 / I11i + I1Ii111 % iIii1I11I1II1
  page_value = O00OO ( page_value , iterations , total_iteration )
 except :
  page_value = 'UNPACKEDFAILED'
  traceback . print_exc ( file = sys . stdout )
  if 66 - 66: OoooooooOO + o00O0oo * IiII
 if 'sav1live.tv' in page_value :
  page_value = page_value . replace ( 'sav1live.tv' , 'sawlive.tv' )
  if 2 - 2: IiII . i1iIi11iIIi1I / OOooOOo
 return page_value
 if 41 - 41: i1iIi11iIIi1I . ooOoO0o * I1Ii111 * ooOoO0o
 if 74 - 74: iIii1I11I1II1 / i1
def O00OO ( sJavascript , iteration = 1 , totaliterations = 2 ) :
 if 58 - 58: iIii1I11I1II1 - oOooOoO0Oo0O % i1 % OoooooooOO * iIii1I11I1II1 + I11i
 if sJavascript . startswith ( 'var _0xcb8a=' ) :
  iIiI1i111ii = sJavascript . split ( 'var _0xcb8a=' )
  O00Oo = "myarray=" + iIiI1i111ii [ 1 ] . split ( "eval(" ) [ 0 ]
  exec ( O00Oo )
  IiI = 62
  o000OOO00O = int ( iIiI1i111ii [ 1 ] . split ( ",62," ) [ 1 ] . split ( ',' ) [ 0 ] )
  O0oooo000oO0 = myarray [ 0 ]
  OoOoO00OOoOOOo0 = myarray [ 3 ]
  with open ( 'temp file' + str ( iteration ) + '.js' , "wb" ) as oOoO00O :
   oOoO00O . write ( str ( OoOoO00OOoOOOo0 ) )
   if 31 - 31: o00O0oo . o0 % o0 % I11i11Ii % oOooOoO0Oo0O * IiII
 else :
  if 22 - 22: Ii1I % I1Ii111 . o0 / o00O0oo + I11i
  if "rn p}('" in sJavascript :
   iIiI1i111ii = sJavascript . split ( "rn p}('" )
  else :
   iIiI1i111ii = sJavascript . split ( "rn A}('" )
   if 85 - 85: oOooOoO0Oo0O - o00O0oo % I11i11Ii % i11i - OoooooooOO % I1Ii111
   if 40 - 40: iII111i
  O0oooo000oO0 , IiI , o000OOO00O , OoOoO00OOoOOOo0 = ( '' , '0' , '0' , '' )
  if 59 - 59: Ii1I * OoooooooOO + I11i . iIii1I11I1II1 / i1IIi
  O00Oo = "p1,a1,c1,k1=('" + iIiI1i111ii [ 1 ] . split ( ".spli" ) [ 0 ] + ')'
  exec ( O00Oo )
 OoOoO00OOoOOOo0 = OoOoO00OOoOOOo0 . split ( '|' )
 iIiI1i111ii = iIiI1i111ii [ 1 ] . split ( "))'" )
 if 75 - 75: Ii1I . I11i - iIii1I11I1II1 * i1iIi11iIIi1I * IiII
 if 93 - 93: o00O0oo
 if 18 - 18: o00O0oo
 if 66 - 66: OOooOOo * i11iIiiIii + o0 / I11i
 if 96 - 96: I11i + I11i % I1Ii111 % I11i
 if 28 - 28: iIii1I11I1II1 + o0 . i1 % i11iIiiIii
 if 58 - 58: Ii1I / OoooooooOO % OOooOOo + i1iIi11iIIi1I
 if 58 - 58: O0
 if 91 - 91: IiII / ii1IiI1i . IiII - i1 + ii1IiI1i
 if 72 - 72: iII111i . I1Ii111 * ii1IiI1i / ii1IiI1i / IiII
 if 13 - 13: i1IIi
 if 17 - 17: i11iIiiIii * i1 * i1 + i1iIi11iIIi1I
 if 95 - 95: oOooOoO0Oo0O
 if 95 - 95: I11i % ii1IiI1i + i1 % o00O0oo
 if 36 - 36: O0 / i1IIi % i11i / IiII
 if 96 - 96: I11i11Ii / OOooOOo . i11i . I11i11Ii
 if 91 - 91: i11i . I11i + i1
 if 8 - 8: I11i * I11i11Ii / IiII - i1iIi11iIIi1I - OoooooooOO
 if 100 - 100: OOooOOo . iIii1I11I1II1 . iIii1I11I1II1
 if 55 - 55: OOooOOo
 if 37 - 37: I1Ii111 / i11iIiiIii / I11i11Ii
 if 97 - 97: ooOoO0o . Ii1I / oOooOoO0Oo0O
 i111iIi1i1II1 = ''
 Ooi1IIii11i1I1 = ''
 if 83 - 83: Ii1I - ii1IiI1i * OOooOOo
 if 90 - 90: I11i11Ii * oOooOoO0Oo0O
 OO0OooOo = str ( ii111iI1i1 ( O0oooo000oO0 , IiI , o000OOO00O , OoOoO00OOoOOOo0 , i111iIi1i1II1 , Ooi1IIii11i1I1 , iteration ) )
 if 80 - 80: i1iIi11iIIi1I / I1Ii111 * oOooOoO0Oo0O % I1Ii111
 if 95 - 95: O0 / Ii1I . ooOoO0o
 if 17 - 17: Ii1I
 if 56 - 56: o00O0oo * i1 + Ii1I
 if 48 - 48: I1Ii111 * i1iIi11iIIi1I % ooOoO0o - Ii1I
 if iteration >= totaliterations :
  if 72 - 72: i1IIi % o00O0oo % I1Ii111 % OOooOOo - OOooOOo
  return OO0OooOo
 else :
  if 97 - 97: i1 * O0 / i1 * i1iIi11iIIi1I * I11i11Ii
  return O00OO ( OO0OooOo , iteration + 1 )
  if 38 - 38: ooOoO0o
def ii111iI1i1 ( p , a , c , k , e , d , iteration , v = 1 ) :
 if 25 - 25: iIii1I11I1II1 % i11i / Ii1I / ii1IiI1i
 if 22 - 22: OOooOOo * IiII
 if 4 - 4: o0 - OOooOOo + oOooOoO0Oo0O
 while ( c >= 1 ) :
  c = c - 1
  if ( k [ c ] ) :
   iiIiIiIiiIiI = str ( iIi1i ( c , a ) )
   if v == 1 :
    p = re . sub ( '\\b' + iiIiIiIiiIiI + '\\b' , k [ c ] , p )
   else :
    p = III ( p , iiIiIiIiiIiI , k [ c ] )
    if 36 - 36: OoooooooOO / I11i11Ii . ooOoO0o % OoooooooOO . I11i + i11i
    if 43 - 43: Ii1I % iII111i / i1 * ooOoO0o
    if 85 - 85: iIii1I11I1II1 . OoooooooOO . i1
    if 77 - 77: oOooOoO0Oo0O % o00O0oo
    if 74 - 74: o0 / i1IIi % OoooooooOO
    if 52 - 52: I1Ii111 % o00O0oo
 return p
 if 25 - 25: Ii1I / Ii1I % OoooooooOO - ii1IiI1i * OOooOOo
 if 23 - 23: i11iIiiIii
 if 100 - 100: OOooOOo + O0 . oOooOoO0Oo0O + i1IIi - o0 + i1
def III ( source_str , word_to_find , replace_with ) :
 ooOOo = None
 ooOOo = source_str . split ( word_to_find )
 if len ( ooOOo ) > 1 :
  i1iii1IiiiI1i1 = [ ]
  IIIiI1i1 = 0
  for IIi11iII11i1 in ooOOo :
   if 5 - 5: i11i - I1Ii111
   i1iii1IiiiI1i1 . append ( IIi11iII11i1 )
   OO0ooOoOO0OOo = word_to_find
   if 86 - 86: I1Ii111 * Ii1I + O0 * ooOoO0o + i11iIiiIii - ii1IiI1i
   if 70 - 70: i11iIiiIii
   if IIIiI1i1 == len ( ooOOo ) - 1 :
    OO0ooOoOO0OOo = ''
   else :
    if len ( IIi11iII11i1 ) == 0 :
     if ( len ( ooOOo [ IIIiI1i1 + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( ooOOo [ IIIiI1i1 + 1 ] ) > 0 and ooOOo [ IIIiI1i1 + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) :
      OO0ooOoOO0OOo = replace_with
      if 57 - 57: Ii1I % I11i + o00O0oo * iII111i . I11i11Ii
    else :
     if ( ooOOo [ IIIiI1i1 ] [ - 1 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) and ( ( len ( ooOOo [ IIIiI1i1 + 1 ] ) == 0 and word_to_find [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) or ( len ( ooOOo [ IIIiI1i1 + 1 ] ) > 0 and ooOOo [ IIIiI1i1 + 1 ] [ 0 ] . lower ( ) not in 'abcdefghijklmnopqrstuvwxyz1234567890_' ) ) :
      OO0ooOoOO0OOo = replace_with
      if 78 - 78: OoooooooOO / i1IIi . I11i
   i1iii1IiiiI1i1 . append ( OO0ooOoOO0OOo )
   IIIiI1i1 += 1
   if 88 - 88: Ii1I + oOooOoO0Oo0O - Ii1I / OoooooooOO - i11iIiiIii
  source_str = '' . join ( i1iii1IiiiI1i1 )
 return source_str
 if 24 - 24: iIii1I11I1II1
def O0Oo0 ( num , radix ) :
 if 54 - 54: oOooOoO0Oo0O
 o0I11iII = ""
 if num == 0 : return '0'
 while num > 0 :
  o0I11iII = "0123456789abcdefghijklmnopqrstuvwxyz" [ num % radix ] + o0I11iII
  num /= radix
 return o0I11iII
 if 61 - 61: Ii1I . Ii1I - i1iIi11iIIi1I
def iIi1i ( cc , a ) :
 iiIiIiIiiIiI = "" if cc < a else iIi1i ( int ( cc / a ) , a )
 cc = ( cc % a )
 o0oo0O000o0OO0O = chr ( cc + 29 ) if cc > 35 else str ( O0Oo0 ( cc , 36 ) )
 return iiIiIiIiiIiI + o0oo0O000o0OO0O
 if 56 - 56: i11i / IiII - OoooooooOO % Ii1I / I11i11Ii
 if 91 - 91: OoooooooOO
def i1II ( url , headers = None ) :
 try :
  if headers is None :
   if 19 - 19: o0 / OOooOOo % OoooooooOO . I11i11Ii / O0 - O0
   if 25 - 25: iIii1I11I1II1 * Ii1I - OOooOOo % i11iIiiIii + iII111i % OOooOOo
   headers = { '\x55\x73\x65\x72\x2d\x61\x67\x65\x6e\x74' : 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:19.0)/Apollo Gecko/20100101 Firefox/19.0' , 'Apollo' : 'Direitos Reservados' , 'Referer' : 'https://deus-apollo.ml' , 'Ref' : 'copyright © 2017-2020' , 'DEUS' : 'Apollo' }
  ooO = urllib2 . Request ( url , None , headers )
  O00OOOOOoo0 = urllib2 . urlopen ( ooO )
  ii1 = O00OOOOOoo0 . read ( )
  O00OOOOOoo0 . close ( )
  return ii1
 except urllib2 . URLError , i111iIi1i1II1 :
  oo0oO0oOOoo ( 'URL: ' + url )
  if hasattr ( i111iIi1i1II1 , 'code' ) :
   oo0oO0oOOoo ( 'Falha com o código de erro - %s.' % i111iIi1i1II1 . code )
   if 5 - 5: iIii1I11I1II1 . OOooOOo
   if 2 - 2: iIii1I11I1II1 * oOooOoO0Oo0O % i1IIi % ii1IiI1i + OoooooooOO + oOooOoO0Oo0O
   xbmc . executebuiltin ( "XBMC.Notification(Falha, código de erro - " + str ( i111iIi1i1II1 . code ) + ",10000," + IIooooo + ")" )
  elif hasattr ( i111iIi1i1II1 , 'reason' ) :
   oo0oO0oOOoo ( 'Falha ao acessar um servidor.' )
   oo0oO0oOOoo ( 'Razão: %s' % i111iIi1i1II1 . reason )
   if 16 - 16: I11i
   xbmc . executebuiltin ( "XBMC.Notification(Falha, motivo - " + str ( i111iIi1i1II1 . reason ) + ",10000," + IIooooo + ")" )
   if 63 - 63: IiII
def OOO0O00Oo ( cookieJar ) :
 try :
  i1i1iIiI = ""
  for oooOooooO0oOO , I11iii in enumerate ( cookieJar ) :
   i1i1iIiI += I11iii . name + "=" + I11iii . value + ";"
 except : pass
 if 11 - 11: OOooOOo + ooOoO0o . I1Ii111 * OoooooooOO - ii1IiI1i - I11i
 return i1i1iIiI
 if 16 - 16: IiII / iIii1I11I1II1 + I11i * IiII * Ii1I
 if 8 - 8: ooOoO0o
def oO0Oo ( cookieJar , COOKIEFILE ) :
 try :
  iiIi111iI = os . path . join ( OOoOoo , COOKIEFILE )
  cookieJar . save ( iiIi111iI , ignore_discard = True )
 except : pass
 if 15 - 15: I11i11Ii / iII111i % O0 + ii1IiI1i
def O00o ( COOKIEFILE ) :
 if 96 - 96: o00O0oo . OoooooooOO
 i1I1I1I = None
 if COOKIEFILE :
  try :
   iiIi111iI = os . path . join ( OOoOoo , COOKIEFILE )
   i1I1I1I = cookielib . LWPCookieJar ( )
   i1I1I1I . load ( iiIi111iI , ignore_discard = True )
  except :
   i1I1I1I = None
   if 25 - 25: i1 + IiII - I11i11Ii
 if not i1I1I1I :
  i1I1I1I = cookielib . LWPCookieJar ( )
  if 59 - 59: I11i - Ii1I % i1IIi
 return i1I1I1I
 if 1 - 1: ii1IiI1i . ooOoO0o * oOooOoO0Oo0O . I1Ii111 * i11i % iIii1I11I1II1
def OooOoooo0000 ( fun_call , page_data , Cookie_Jar , m ) :
 Oo0oo00Oo0O0 = ''
 if 67 - 67: IiII
 if o0O0OOO0Ooo not in sys . path :
  sys . path . append ( o0O0OOO0Ooo )
  if 88 - 88: I11i11Ii
  if 8 - 8: ii1IiI1i
 try :
  o000i11ii1 = 'import ' + fun_call . split ( '.' ) [ 0 ]
  if 4 - 4: i11iIiiIii - I11i % ii1IiI1i * ooOoO0o % i1
  exec ( o000i11ii1 )
  if 71 - 71: o00O0oo . o00O0oo - iIii1I11I1II1
 except :
  if 22 - 22: OoooooooOO / ii1IiI1i % IiII * o0
  traceback . print_exc ( file = sys . stdout )
  if 32 - 32: OoooooooOO % OOooOOo % iIii1I11I1II1 / O0
 exec ( 'ret_val=' + fun_call )
 if 61 - 61: i11i . O0 - iII111i - ii1IiI1i / i11iIiiIii - i11i
 if 98 - 98: iII111i - oOooOoO0Oo0O . i11iIiiIii * I11i11Ii
 try :
  return str ( Oo0oo00Oo0O0 )
 except : return Oo0oo00Oo0O0
 if 29 - 29: iII111i / o00O0oo % Ii1I
 if 10 - 10: iIii1I11I1II1 % OoooooooOO % ii1IiI1i
def O0O000O ( fun_call , page_data , Cookie_Jar , m ) :
 if 39 - 39: i11i * o0 . O0 * Ii1I
 Oo0oo00Oo0O0 = ''
 if o0O0OOO0Ooo not in sys . path :
  sys . path . append ( o0O0OOO0Ooo )
 Oo000o = open ( o0O0OOO0Ooo + "/LSProdynamicCode.py" , "w" )
 Oo000o . write ( fun_call ) ;
 Oo000o . close ( )
 import LSProdynamicCode
 Oo0oo00Oo0O0 = LSProdynamicCode . GetLSProData ( page_data , Cookie_Jar , m )
 try :
  return str ( Oo0oo00Oo0O0 )
 except : return Oo0oo00Oo0O0
 if 89 - 89: iII111i - o00O0oo . Ii1I - ooOoO0o - oOooOoO0Oo0O
 if 79 - 79: I1Ii111 + I1Ii111 + iII111i
def iiiII1i1I ( captchakey , cj , type = 1 ) :
 if 97 - 97: O0 . ooOoO0o / i11i . O0 + OoooooooOO
 if 78 - 78: i11i + I1Ii111
 if 66 - 66: iIii1I11I1II1
 oO00oO00O0Oo = ""
 OO0o0o0oo = ""
 if 40 - 40: I11i11Ii
 if 47 - 47: o0
 if 65 - 65: O0 + ooOoO0o % iII111i * oOooOoO0Oo0O / o00O0oo / o0
 if 71 - 71: i11iIiiIii / o0 . OOooOOo
 if 33 - 33: OOooOOo
 IIIi11 = False
 oooOo00O0 = None
 OO0o0o0oo = None
 if len ( captchakey ) > 0 :
  I1IoOO0o0 = captchakey
  if not I1IoOO0o0 . startswith ( 'http' ) :
   I1IoOO0o0 = 'http://www.google.com/recaptcha/api/challenge?k=' + I1IoOO0o0 + '&ajax=1'
   if 36 - 36: i11iIiiIii + ii1IiI1i % I11i . oOooOoO0Oo0O - o00O0oo
  IIIi11 = True
  if 94 - 94: oOooOoO0Oo0O % o0 . I1Ii111 . o00O0oo . i1iIi11iIIi1I
  o0oO0oo = 'challenge.*?\'(.*?)\''
  ooOO00Oo = '\'(.*?)\''
  oO00OOOOOO0o = ii11II ( I1IoOO0o0 , cookieJar = cj )
  oO00oO00O0Oo = re . findall ( o0oO0oo , oO00OOOOOO0o ) [ 0 ]
  iIII = 'http://www.google.com/recaptcha/api/reload?c=' ;
  OoO0000 = I1IoOO0o0 . split ( 'k=' ) [ 1 ]
  iIII += oO00oO00O0Oo + '&k=' + OoO0000 + '&reason=i&type=image&lang=en'
  III11iIIi = ii11II ( iIII , cookieJar = cj )
  oooOo00O0 = re . findall ( ooOO00Oo , III11iIIi ) [ 0 ]
  iIIii1I111iIii1i1 = 'http://www.google.com/recaptcha/api/image?c=' + oooOo00O0
  if not iIIii1I111iIii1i1 . startswith ( "http" ) :
   iIIii1I111iIii1i1 = 'http://www.google.com/recaptcha/api/' + iIIii1I111iIii1i1
  import random
  o0o0OO0o00o0O = random . randrange ( 100 , 1000 , 5 )
  o0Oo = os . path . join ( OOoOoo , str ( o0o0OO0o00o0O ) + "captcha.img" )
  i1II11i1iI1 = open ( o0Oo , "wb" )
  i1II11i1iI1 . write ( ii11II ( iIIii1I111iIii1i1 , cookieJar = cj ) )
  i1II11i1iI1 . close ( )
  OO0 = IIi1II11 ( captcha = o0Oo )
  OO0o0o0oo = OO0 . get ( )
  os . remove ( o0Oo )
  if 63 - 63: ooOoO0o - i1IIi
 if oooOo00O0 :
  if type == 1 :
   return 'recaptcha_challenge_field=' + urllib . quote_plus ( oooOo00O0 ) + '&recaptcha_response_field=' + urllib . quote_plus ( OO0o0o0oo )
  elif type == 2 :
   return 'recaptcha_challenge_field:' + oooOo00O0 + ',recaptcha_response_field:' + OO0o0o0oo
  else :
   return 'recaptcha_challenge_field=' + urllib . quote_plus ( oooOo00O0 ) + '&recaptcha_response_field=' + urllib . quote_plus ( OO0o0o0oo )
 else :
  return ''
  if 10 - 10: ii1IiI1i - Ii1I . ooOoO0o
def iiIIIi1iIi ( url ) :
 OOo0OOOoOOo = ii11II ( url )
 oO00oO00O0Oo = ""
 OO0o0o0oo = ""
 IIIooo0o0O = "<script.*?src=\"(.*?recap.*?)\""
 IIIII1iii = re . findall ( IIIooo0o0O , OOo0OOOoOOo )
 IIIi11 = False
 oooOo00O0 = None
 OO0o0o0oo = None
 if 32 - 32: OoooooooOO % OoooooooOO . OOooOOo - o00O0oo . o0 * OOooOOo
 if IIIII1iii and len ( IIIII1iii ) > 0 :
  I1IoOO0o0 = IIIII1iii [ 0 ]
  IIIi11 = True
  if 55 - 55: Ii1I
  o0oO0oo = 'challenge.*?\'(.*?)\''
  ooOO00Oo = '\'(.*?)\''
  oO00OOOOOO0o = ii11II ( I1IoOO0o0 )
  oO00oO00O0Oo = re . findall ( o0oO0oo , oO00OOOOOO0o ) [ 0 ]
  iIII = 'http://www.google.com/recaptcha/api/reload?c=' ;
  OoO0000 = I1IoOO0o0 . split ( 'k=' ) [ 1 ]
  iIII += oO00oO00O0Oo + '&k=' + OoO0000 + '&captcha_k=1&type=image&lang=en-GB'
  III11iIIi = ii11II ( iIII )
  oooOo00O0 = re . findall ( ooOO00Oo , III11iIIi ) [ 0 ]
  iIIii1I111iIii1i1 = 'http://www.google.com/recaptcha/api/image?c=' + oooOo00O0
  if not iIIii1I111iIii1i1 . startswith ( "http" ) :
   iIIii1I111iIii1i1 = 'http://www.google.com/recaptcha/api/' + iIIii1I111iIii1i1
  import random
  o0o0OO0o00o0O = random . randrange ( 100 , 1000 , 5 )
  o0Oo = os . path . join ( OOoOoo , str ( o0o0OO0o00o0O ) + "captcha.img" )
  i1II11i1iI1 = open ( o0Oo , "wb" )
  i1II11i1iI1 . write ( ii11II ( iIIii1I111iIii1i1 ) )
  i1II11i1iI1 . close ( )
  OO0 = IIi1II11 ( captcha = o0Oo )
  OO0o0o0oo = OO0 . get ( )
  os . remove ( o0Oo )
 return oooOo00O0 , OO0o0o0oo
 if 93 - 93: i11iIiiIii . i1
def ii11II ( url , cookieJar = None , post = None , timeout = 20 , headers = None , noredir = False ) :
 if 16 - 16: i1IIi . i1IIi / ooOoO0o % o0 / oOooOoO0Oo0O * ii1IiI1i
 if 30 - 30: i1 + OoooooooOO + I11i / i11i * I11i11Ii
 o0O = urllib2 . HTTPCookieProcessor ( cookieJar )
 if 59 - 59: iII111i / o0 * i1iIi11iIIi1I * IiII % OOooOOo
 if noredir :
  II1 = urllib2 . build_opener ( Ii , o0O , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
 else :
  II1 = urllib2 . build_opener ( o0O , urllib2 . HTTPBasicAuthHandler ( ) , urllib2 . HTTPHandler ( ) )
  if 61 - 61: I11i11Ii - O0 - OoooooooOO
 ooO = urllib2 . Request ( url )
 ooO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36' )
 if headers :
  for oo0OoOOooO , Ii1I1Iiii in headers :
   ooO . add_header ( oo0OoOOooO , Ii1I1Iiii )
   if 80 - 80: I11i . iII111i + iIii1I11I1II1
 O00OOOOOoo0 = II1 . open ( ooO , post , timeout = timeout )
 OoOoO = O00OOOOOoo0 . read ( )
 O00OOOOOoo0 . close ( )
 return OoOoO ;
 if 32 - 32: oOooOoO0Oo0O
def IIIIIiiI11i1 ( str , reg = None ) :
 if reg :
  str = re . findall ( reg , str ) [ 0 ]
 Iii1I = urllib . unquote ( str [ 0 : len ( str ) - 1 ] ) ;
 oooII111 = '' ;
 for I11iiiii1II in range ( len ( Iii1I ) ) :
  oooII111 += chr ( ord ( Iii1I [ I11iiiii1II ] ) - Iii1I [ len ( Iii1I ) - 1 ] ) ;
 oooII111 = urllib . unquote ( oooII111 )
 if 29 - 29: I1Ii111 + i11iIiiIii * O0 - IiII . i11i % iII111i
 return oooII111
 if 41 - 41: OOooOOo / I11i + IiII + o00O0oo
def O0000oO0o00 ( str ) :
 iiiiii1Ii = re . findall ( 'unescape\(\'(.*?)\'' , str )
 if 20 - 20: ooOoO0o + ooOoO0o * i11i * iIii1I11I1II1 % O0 * oOooOoO0Oo0O
 if ( not iiiiii1Ii == None ) and len ( iiiiii1Ii ) > 0 :
  for OooOo in iiiiii1Ii :
   if 87 - 87: o00O0oo * i1iIi11iIIi1I + i1 . I11i - o00O0oo
   str = str . replace ( OooOo , urllib . unquote ( OooOo ) )
 return str
 if 33 - 33: i11i / O0 / I1Ii111 - Ii1I - i1IIi
IiIiiI = 0
if 53 - 53: oOooOoO0Oo0O % OoooooooOO + ooOoO0o - I11i11Ii / I1Ii111 * i1
def oooI11iI1I ( m , html_page , cookieJar ) :
 global IiIiiI
 IiIiiI += 1
 ooo0OIi1iiIIi1i = m [ 'expres' ]
 ooOOo00oo0 = m [ 'page' ]
 iIiiiI1I = re . compile ( '\$LiveStreamCaptcha\[([^\]]*)\]' ) . findall ( ooo0OIi1iiIIi1i ) [ 0 ]
 if 30 - 30: i1 - i1iIi11iIIi1I + I11i
 I1IoOO0o0 = re . compile ( iIiiiI1I ) . findall ( html_page ) [ 0 ]
 if 65 - 65: O0 / i11i . iIii1I11I1II1 . OOooOOo / I11i11Ii % iIii1I11I1II1
 if not I1IoOO0o0 . startswith ( "http" ) :
  Oo0Oo = 'http://' + "" . join ( ooOOo00oo0 . split ( '/' ) [ 2 : 3 ] )
  if I1IoOO0o0 . startswith ( "/" ) :
   I1IoOO0o0 = Oo0Oo + I1IoOO0o0
  else :
   I1IoOO0o0 = Oo0Oo + '/' + I1IoOO0o0
   if 60 - 60: i1 . o0 % ooOoO0o / oOooOoO0Oo0O / O0
 o0Oo = os . path . join ( OOoOoo , str ( IiIiiI ) + "captcha.jpg" )
 i1II11i1iI1 = open ( o0Oo , "wb" )
 if 19 - 19: i11iIiiIii . oOooOoO0Oo0O + i11i / I11i . ii1IiI1i * o00O0oo
 ooO = urllib2 . Request ( I1IoOO0o0 )
 ooO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
 if 'referer' in m :
  ooO . add_header ( 'Referer' , m [ 'referer' ] )
 if 'agent' in m :
  ooO . add_header ( 'User-agent' , m [ 'agent' ] )
 if 'setcookie' in m :
  if 59 - 59: iIii1I11I1II1 / ii1IiI1i % o00O0oo
  ooO . add_header ( 'Cookie' , m [ 'setcookie' ] )
  if 84 - 84: iIii1I11I1II1 / oOooOoO0Oo0O . o0 % Ii1I
  if 99 - 99: I11i11Ii + i11iIiiIii
  if 36 - 36: iII111i * ooOoO0o * iIii1I11I1II1 - Ii1I % i11iIiiIii
  if 98 - 98: iIii1I11I1II1 - i1IIi + o00O0oo % Ii1I + o00O0oo / OOooOOo
 urllib2 . urlopen ( ooO )
 O00OOOOOoo0 = urllib2 . urlopen ( ooO )
 if 97 - 97: I1Ii111 % o00O0oo + i11i - I1Ii111 % i1iIi11iIIi1I + o00O0oo
 i1II11i1iI1 . write ( O00OOOOOoo0 . read ( ) )
 O00OOOOOoo0 . close ( )
 i1II11i1iI1 . close ( )
 OO0 = IIi1II11 ( captcha = o0Oo )
 OO0o0o0oo = OO0 . get ( )
 return OO0o0o0oo
 if 31 - 31: i1
 if 35 - 35: o0 + iII111i * o00O0oo / o0
def o0Oo0ooo ( imageregex , html_page , cookieJar , m ) :
 global IiIiiI
 IiIiiI += 1
 if 60 - 60: oOooOoO0Oo0O
 if 44 - 44: i11i . i11i + I11i * iII111i
 if not imageregex == '' :
  if html_page . startswith ( "http" ) :
   Oo0Oo = ii11II ( html_page , cookieJar = cookieJar )
  else :
   Oo0Oo = html_page
  I1IoOO0o0 = re . compile ( imageregex ) . findall ( html_page ) [ 0 ]
 else :
  I1IoOO0o0 = html_page
  if 'oneplay.tv/embed' in html_page :
   import oneplay
   Oo0Oo = ii11II ( html_page , cookieJar = cookieJar )
   I1IoOO0o0 = oneplay . getCaptchaUrl ( Oo0Oo )
   if 16 - 16: i11i
 o0Oo = os . path . join ( OOoOoo , str ( IiIiiI ) + "captcha.jpg" )
 i1II11i1iI1 = open ( o0Oo , "wb" )
 if 100 - 100: O0 - i1IIi
 ooO = urllib2 . Request ( I1IoOO0o0 )
 ooO . add_header ( 'User-Agent' , 'Mozilla/5.0 (Windows NT 6.1; rv:14.0) Gecko/20100101 Firefox/14.0.1' )
 if 'referer' in m :
  ooO . add_header ( 'Referer' , m [ 'referer' ] )
 if 'agent' in m :
  ooO . add_header ( 'User-agent' , m [ 'agent' ] )
 if 'accept' in m :
  ooO . add_header ( 'Accept' , m [ 'accept' ] )
 if 'setcookie' in m :
  if 48 - 48: OOooOOo % o00O0oo + O0
  ooO . add_header ( 'Cookie' , m [ 'setcookie' ] )
  if 27 - 27: ii1IiI1i / I11i
  if 33 - 33: OoooooooOO % ii1IiI1i . O0 / ii1IiI1i
  if 63 - 63: I1Ii111 + iIii1I11I1II1 + oOooOoO0Oo0O + ooOoO0o
  if 72 - 72: i1iIi11iIIi1I + i11iIiiIii + ii1IiI1i
  if 96 - 96: OOooOOo % i1IIi / i1
 O00OOOOOoo0 = urllib2 . urlopen ( ooO )
 if 13 - 13: i11i - I11i11Ii % i11iIiiIii + IiII
 i1II11i1iI1 . write ( O00OOOOOoo0 . read ( ) )
 O00OOOOOoo0 . close ( )
 i1II11i1iI1 . close ( )
 OO0 = IIi1II11 ( captcha = o0Oo )
 OO0o0o0oo = OO0 . get ( )
 return OO0o0o0oo
 if 88 - 88: O0 . OOooOOo % oOooOoO0Oo0O
 if 10 - 10: oOooOoO0Oo0O + O0
 if 75 - 75: O0 % iIii1I11I1II1 / o0 % I11i / I1Ii111
 if 31 - 31: i11iIiiIii * o0
 if 69 - 69: i11iIiiIii
 if 61 - 61: O0
 if 21 - 21: i1iIi11iIIi1I % iIii1I11I1II1 . i1iIi11iIIi1I
 if 99 - 99: i1 * I11i % OOooOOo * OOooOOo + OoooooooOO
 if 82 - 82: Ii1I / o0 - I11i / o00O0oo
 if 50 - 50: I11i + i1iIi11iIIi1I . i11iIiiIii + ii1IiI1i + i11iIiiIii
 if 31 - 31: OOooOOo * ooOoO0o . o0 * Ii1I
 if 28 - 28: I1Ii111 + oOooOoO0Oo0O - I11i11Ii % I11i . Ii1I + oOooOoO0Oo0O
 if 72 - 72: iII111i / I11i11Ii / OOooOOo * o0 + I11i
 if 58 - 58: i1 % oOooOoO0Oo0O . oOooOoO0Oo0O * i1iIi11iIIi1I - I1Ii111 . OoooooooOO
 if 10 - 10: ooOoO0o
def I11i1i11IiIi1 ( name , headname ) :
 if 8 - 8: IiII - oOooOoO0Oo0O * I11i11Ii % ii1IiI1i * OoooooooOO
 if 26 - 26: i1IIi / IiII . IiII
 I1i11IIIi = xbmc . Keyboard ( 'default' , 'heading' , True )
 I1i11IIIi . setDefault ( name )
 I1i11IIIi . setHeading ( headname )
 I1i11IIIi . setHiddenInput ( False )
 return I1i11IIIi . getText ( )
 if 19 - 19: OOooOOo * IiII + o0 - OOooOOo + ii1IiI1i
 if 14 - 14: i1iIi11iIIi1I
 if 38 - 38: O0
 if 79 - 79: i1IIi . OOooOOo
class IIi1II11 ( xbmcgui . WindowDialog ) :
 def __init__ ( self , * args , ** kwargs ) :
  self . cptloc = kwargs . get ( 'captcha' )
  self . img = xbmcgui . ControlImage ( 335 , 30 , 624 , 60 , self . cptloc )
  self . addControl ( self . img )
  self . kbd = xbmc . Keyboard ( )
  if 34 - 34: ooOoO0o * i11i
 def get ( self ) :
  self . show ( )
  time . sleep ( 2 )
  self . kbd . doModal ( )
  if ( self . kbd . isConfirmed ( ) ) :
   o0oO00OOo0oO = self . kbd . getText ( )
   self . close ( )
   return o0oO00OOo0oO
  self . close ( )
  return False
  if 92 - 92: oOooOoO0Oo0O . i11i
def II11I ( ) :
 import time
 return str ( int ( time . time ( ) * 1000 ) )
 if 34 - 34: i1 . ooOoO0o % I1Ii111 - O0 / ooOoO0o
def i11iIIi ( ) :
 import time
 return str ( int ( time . time ( ) ) )
 if 91 - 91: i11iIiiIii % ooOoO0o * OOooOOo - ii1IiI1i . ooOoO0o
def iIo00oo ( ) :
 O000Oo00 = [ ]
 iI1oOoo = sys . argv [ 2 ]
 if len ( iI1oOoo ) >= 2 :
  o00O0o00oo = sys . argv [ 2 ]
  iIiiII = o00O0o00oo . replace ( '?' , '' )
  if ( o00O0o00oo [ len ( o00O0o00oo ) - 1 ] == '/' ) :
   o00O0o00oo = o00O0o00oo [ 0 : len ( o00O0o00oo ) - 2 ]
  iII1I = iIiiII . split ( '&' )
  O000Oo00 = { }
  for I11iiiii1II in range ( len ( iII1I ) ) :
   o00oOOo0Oo = { }
   o00oOOo0Oo = iII1I [ I11iiiii1II ] . split ( '=' )
   if ( len ( o00oOOo0Oo ) ) == 2 :
    O000Oo00 [ o00oOOo0Oo [ 0 ] ] = o00oOOo0Oo [ 1 ]
 return O000Oo00
 if 91 - 91: i11i - iIii1I11I1II1 / i1IIi * i1IIi % I11i11Ii
 if 82 - 82: o00O0oo
def OoOooO0 ( ) :
 iIIIi1i1I11i = json . loads ( open ( iiIi1IIiIi ) . read ( ) )
 IIiiii = len ( iIIIi1i1I11i )
 for I11iiiii1II in iIIIi1i1I11i :
  oO0o00oOOooO0 = I11iiiii1II [ 0 ]
  oOO0O00Oo0O0o = I11iiiii1II [ 1 ]
  iI1IiiiIi = I11iiiii1II [ 2 ]
  try :
   iii1 = I11iiiii1II [ 3 ]
   if iii1 == None :
    raise
  except :
   if o0o . getSetting ( 'use_thumb' ) == "true" :
    iii1 = iI1IiiiIi
   else :
    iii1 = Oo000ooOOO
  try : iIIIiI = I11iiiii1II [ 5 ]
  except : iIIIiI = None
  try : IiIIiIIIiIii = I11iiiii1II [ 6 ]
  except : IiIIiIIIiIii = None
  if 31 - 31: i11iIiiIii + I1Ii111 - ooOoO0o * IiII
  if I11iiiii1II [ 4 ] == 0 :
   oo ( oOO0O00Oo0O0o , oO0o00oOOooO0 , iI1IiiiIi , iii1 , '' , '' , '' , 'fav' , iIIIiI , IiIIiIIIiIii , IIiiii )
  else :
   oO0O0o0Oooo ( oO0o00oOOooO0 , oOO0O00Oo0O0o , I11iiiii1II [ 4 ] , iI1IiiiIi , Oo000ooOOO , '' , '' , '' , '' , 'fav' )
   if 60 - 60: IiII + i1iIi11iIIi1I + Ii1I % iIii1I11I1II1 . I11i11Ii
   if 73 - 73: ooOoO0o * ii1IiI1i + i1 - I11i11Ii . Ii1I
def o0oOOO ( name , url , iconimage , fanart , mode , playlist = None , regexs = None ) :
 o00OoOooo = [ ]
 if not os . path . exists ( iiIi1IIiIi + 'txt' ) :
  os . makedirs ( iiIi1IIiIi + 'txt' )
 if not os . path . exists ( oOO00Oo ) :
  os . makedirs ( oOO00Oo )
 try :
  if 47 - 47: o00O0oo + IiII + i1IIi
  name = name . encode ( 'utf-8' , 'ignore' )
 except :
  pass
 if os . path . exists ( iiIi1IIiIi ) == False :
  oo0oO0oOOoo ( 'Making Favorites File' )
  o00OoOooo . append ( ( name , url , iconimage , fanart , mode , playlist , regexs ) )
  I111I11I111 = open ( iiIi1IIiIi , "w" )
  I111I11I111 . write ( json . dumps ( o00OoOooo ) )
  I111I11I111 . close ( )
 else :
  oo0oO0oOOoo ( 'Appending Favorites' )
  I111I11I111 = open ( iiIi1IIiIi ) . read ( )
  ii1 = json . loads ( I111I11I111 )
  ii1 . append ( ( name , url , iconimage , fanart , mode ) )
  oO0Ooooooo = open ( iiIi1IIiIi , "w" )
  oO0Ooooooo . write ( json . dumps ( ii1 ) )
  oO0Ooooooo . close ( )
  if 6 - 6: OOooOOo / O0 / iII111i / I1Ii111 / OOooOOo . iIii1I11I1II1
  if 62 - 62: iIii1I11I1II1
def IIi1i1ii11I1 ( name ) :
 ii1 = json . loads ( open ( iiIi1IIiIi ) . read ( ) )
 for oooOooooO0oOO in range ( len ( ii1 ) ) :
  if ii1 [ oooOooooO0oOO ] [ 0 ] == name :
   del ii1 [ oooOooooO0oOO ]
   oO0Ooooooo = open ( iiIi1IIiIi , "w" )
   oO0Ooooooo . write ( json . dumps ( ii1 ) )
   oO0Ooooooo . close ( )
   break
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 61 - 61: i1iIi11iIIi1I . i1IIi - oOooOoO0Oo0O
def o0ooOo0OOOO0o ( url ) :
 if o0o . getSetting ( 'Updatecommonresolvers' ) == 'true' :
  I11II1i1 = os . path . join ( oO0000OOo00 , 'genesisresolvers.py' )
  if xbmcvfs . exists ( I11II1i1 ) :
   os . remove ( I11II1i1 )
   if 38 - 38: OOooOOo + iIii1I11I1II1 * iII111i / i1iIi11iIIi1I + I11i
  Iii11iI1I = 'https://raw.githubusercontent.com/KelTec-Maedia-Play/master/plugin.video.genesis/commonresolvers.py'
  OOo0o0O0 = urllib . urlretrieve ( Iii11iI1I , I11II1i1 )
  o0o . setSetting ( 'Updatecommonresolvers' , 'false' )
 try :
  import genesisresolvers
 except Exception :
  if 8 - 8: ooOoO0o
  if 23 - 23: i1 - Ii1I + i1 * O0
  xbmc . executebuiltin ( "XBMC.Notification(Por favor Ative Atualizar Resolvedores comuns para reproduzir em configurações. - ,10000)" )
  if 48 - 48: i11i + i11i * i1IIi / iII111i
 iii11III1I = genesisresolvers . get ( url ) . result
 if url == iii11III1I or iii11III1I is None :
  if 61 - 61: ii1IiI1i + iIii1I11I1II1 % i1
  if 78 - 78: iIii1I11I1II1 - i11i / oOooOoO0Oo0O
  xbmc . executebuiltin ( "XBMC.Notification(Using Urlresolver module.. - ,5000)" )
  import urlresolver
  iII111iiiI11i = urlresolver . HostedMediaFile ( url )
  if iII111iiiI11i :
   i11IiIIi11I = urlresolver . resolve ( url )
   iii11III1I = i11IiIIi11I
 if iii11III1I :
  if isinstance ( iii11III1I , list ) :
   for iiI1 in iii11III1I :
    i1i111III1 = o0o . getSetting ( 'quality' )
    if iiI1 [ 'quality' ] == 'HD' :
     i11IiIIi11I = iiI1 [ 'url' ]
     break
    elif iiI1 [ 'quality' ] == 'SD' :
     i11IiIIi11I = iiI1 [ 'url' ]
    elif iiI1 [ 'quality' ] == '1080p' and o0o . getSetting ( '1080pquality' ) == 'true' :
     i11IiIIi11I = iiI1 [ 'url' ]
     break
  else :
   i11IiIIi11I = iii11III1I
 return i11IiIIi11I
 if 12 - 12: ii1IiI1i * o00O0oo - Ii1I . i1iIi11iIIi1I + i1iIi11iIIi1I + IiII
def ii1O0O ( name , mu_playlist , queueVideo = None ) :
 iIIIiI = xbmc . PlayList ( xbmc . PLAYLIST_VIDEO )
 if 37 - 37: i1iIi11iIIi1I + ii1IiI1i - O0 * i11i
 if '$$LSPlayOnlyOne$$' in mu_playlist [ 0 ] :
  mu_playlist [ 0 ] = mu_playlist [ 0 ] . replace ( '$$LSPlayOnlyOne$$' , '' )
  import urlparse
  II1Iiiii111i = [ ]
  OooooO0o0 = 0
  Ii1IIi = xbmcgui . DialogProgress ( )
  Ii1IIi . create ( 'Progress' , 'Trying Multiple Links' )
  for I11iiiii1II in mu_playlist :
   if 99 - 99: I11i * i1IIi . iII111i * ooOoO0o . o00O0oo
   if 54 - 54: IiII . i1IIi . ii1IiI1i * i1 % IiII
   if 30 - 30: Ii1I
   if O0ooo0O0oo0 in I11iiiii1II :
    if 85 - 85: i11i + o00O0oo * Ii1I
    i1ooOO00o0 = I11iiiii1II . split ( O0ooo0O0oo0 ) [ 1 ] . split ( '&regexs' ) [ 0 ]
    II1Iiiii111i . append ( i1ooOO00o0 )
    if 44 - 44: oOooOoO0Oo0O % I11i * i11iIiiIii * i11iIiiIii - I11i11Ii . ooOoO0o
    mu_playlist [ OooooO0o0 ] = I11iiiii1II . split ( O0ooo0O0oo0 ) [ 0 ] + ( '&regexs' + I11iiiii1II . split ( '&regexs' ) [ 1 ] if '&regexs' in I11iiiii1II else '' )
   else :
    i1ooOO00o0 = urlparse . urlparse ( I11iiiii1II ) . netloc
    if i1ooOO00o0 == '' :
     II1Iiiii111i . append ( name )
    else :
     II1Iiiii111i . append ( i1ooOO00o0 )
   oooOooooO0oOO = OooooO0o0
   OooooO0o0 += 1
   if 68 - 68: IiII . Ii1I
   i111iiIiiIiI = II1Iiiii111i [ oooOooooO0oOO ]
   if Ii1IIi . iscanceled ( ) : return
   Ii1IIi . update ( OooooO0o0 / len ( mu_playlist ) * 100 , "" , "Link#%d" % ( OooooO0o0 ) , i111iiIiiIiI )
   print 'auto playnamexx' , i111iiIiiIiI
   if "&mode=19" in mu_playlist [ oooOooooO0oOO ] :
    if 59 - 59: I11i + oOooOoO0Oo0O / i11i / o0
    Ii1 = xbmcgui . ListItem ( i111iiIiiIiI , iconImage = iI1IiiiIi , thumbnailImage = iI1IiiiIi )
    Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : i111iiIiiIiI } )
    Ii1 . setProperty ( "IsPlayable" , "true" )
    oOoo00 = o0ooOo0OOOO0o ( mu_playlist [ oooOooooO0oOO ] . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    Ii1 . setPath ( oOoo00 )
    if 29 - 29: I11i / o0 . iIii1I11I1II1 / Ii1I % o0 % IiII
    if oOoo00 . startswith ( "plugin://plugin.video.f4mTester" ) :
     xbmc . executebuiltin ( 'RunPlugin(' + oOoo00 + ')' )
    else :
     iiI1oooOOO0o0O0 = tryplay ( oOoo00 , Ii1 )
   elif "$doregex" in mu_playlist [ oooOooooO0oOO ] :
    if 31 - 31: OoooooooOO - OOooOOo / ooOoO0o
    oo00o000O = mu_playlist [ oooOooooO0oOO ] . split ( '&regexs=' )
    if 66 - 66: OoooooooOO + i1 . i1IIi * IiII
    oOO0O00Oo0O0o , iII1ii1I1i = o0O0oo0o ( oo00o000O [ 1 ] , oo00o000O [ 0 ] )
    o00oIII = oOO0O00Oo0O0o . replace ( ';' , '' )
    Ii1 = xbmcgui . ListItem ( i111iiIiiIiI , iconImage = iI1IiiiIi , thumbnailImage = iI1IiiiIi )
    Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : i111iiIiiIiI } )
    Ii1 . setProperty ( "IsPlayable" , "true" )
    Ii1 . setPath ( o00oIII )
    if 16 - 16: iII111i / i1IIi
    if o00oIII . startswith ( "plugin://plugin.video.f4mTester" ) :
     xbmc . executebuiltin ( 'RunPlugin(' + o00oIII + ')' )
    else :
     iiI1oooOOO0o0O0 = tryplay ( o00oIII , Ii1 )
     if 28 - 28: iII111i
   else :
    oOO0O00Oo0O0o = mu_playlist [ oooOooooO0oOO ]
    oOO0O00Oo0O0o = oOO0O00Oo0O0o . split ( '&regexs=' ) [ 0 ]
    Ii1 = xbmcgui . ListItem ( i111iiIiiIiI , iconImage = iI1IiiiIi , thumbnailImage = iI1IiiiIi )
    Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : i111iiIiiIiI } )
    Ii1 . setProperty ( "IsPlayable" , "true" )
    Ii1 . setPath ( oOO0O00Oo0O0o )
    if 66 - 66: Ii1I
    if oOO0O00Oo0O0o . startswith ( "plugin://plugin.video.f4mTester" ) :
     xbmc . executebuiltin ( 'RunPlugin(' + oOO0O00Oo0O0o + ')' )
    else :
     iiI1oooOOO0o0O0 = tryplay ( oOO0O00Oo0O0o , Ii1 )
     print 'played' , iiI1oooOOO0o0O0
   print 'played' , iiI1oooOOO0o0O0
   if iiI1oooOOO0o0O0 : return
  return
 if o0o . getSetting ( 'ask_playlist_items' ) == 'true' and not queueVideo :
  import urlparse
  II1Iiiii111i = [ ]
  OooooO0o0 = 0
  for I11iiiii1II in mu_playlist :
   if 27 - 27: O0
   if O0ooo0O0oo0 in I11iiiii1II :
    if 73 - 73: i11iIiiIii + OOooOOo % Ii1I . OoooooooOO % OOooOOo
    i1ooOO00o0 = I11iiiii1II . split ( O0ooo0O0oo0 ) [ 1 ] . split ( '&regexs' ) [ 0 ]
    II1Iiiii111i . append ( i1ooOO00o0 )
    if 32 - 32: i11iIiiIii - i11i
    mu_playlist [ OooooO0o0 ] = I11iiiii1II . split ( O0ooo0O0oo0 ) [ 0 ] + ( '&regexs' + I11iiiii1II . split ( '&regexs' ) [ 1 ] if '&regexs' in I11iiiii1II else '' )
   else :
    i1ooOO00o0 = urlparse . urlparse ( I11iiiii1II ) . netloc
    if i1ooOO00o0 == '' :
     II1Iiiii111i . append ( name )
    else :
     II1Iiiii111i . append ( i1ooOO00o0 )
     if 21 - 21: o0 - i11i
   OooooO0o0 += 1
  OO = xbmcgui . Dialog ( )
  if 10 - 10: o0 - i1 * i11iIiiIii / I11i11Ii + i1 + iIii1I11I1II1
  oooOooooO0oOO = OO . select ( I1I , II1Iiiii111i )
  if oooOooooO0oOO >= 0 :
   i111iiIiiIiI = II1Iiiii111i [ oooOooooO0oOO ]
   print 'playnamexx' , i111iiIiiIiI
   if "&mode=19" in mu_playlist [ oooOooooO0oOO ] :
    if 23 - 23: i1IIi + ii1IiI1i + oOooOoO0Oo0O - o00O0oo % OoooooooOO . I1Ii111
    Ii1 = xbmcgui . ListItem ( i111iiIiiIiI , iconImage = iI1IiiiIi , thumbnailImage = iI1IiiiIi )
    Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : i111iiIiiIiI } )
    Ii1 . setProperty ( "IsPlayable" , "true" )
    oOoo00 = o0ooOo0OOOO0o ( mu_playlist [ oooOooooO0oOO ] . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    Ii1 . setPath ( oOoo00 )
    if oOoo00 . startswith ( "plugin://plugin.video.f4mTester" ) :
     xbmc . executebuiltin ( 'RunPlugin(' + oOoo00 + ')' )
    else :
     xbmc . Player ( ) . play ( oOoo00 , Ii1 )
   elif "$doregex" in mu_playlist [ oooOooooO0oOO ] :
    if 49 - 49: OOooOOo . o0
    oo00o000O = mu_playlist [ oooOooooO0oOO ] . split ( '&regexs=' )
    if 73 - 73: iII111i / oOooOoO0Oo0O / OoooooooOO + oOooOoO0Oo0O
    oOO0O00Oo0O0o , iII1ii1I1i = o0O0oo0o ( oo00o000O [ 1 ] , oo00o000O [ 0 ] )
    o00oIII = oOO0O00Oo0O0o . replace ( ';' , '' )
    Ii1 = xbmcgui . ListItem ( i111iiIiiIiI , iconImage = iI1IiiiIi , thumbnailImage = iI1IiiiIi )
    Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : i111iiIiiIiI } )
    Ii1 . setProperty ( "IsPlayable" , "true" )
    Ii1 . setPath ( o00oIII )
    if o00oIII . startswith ( "plugin://plugin.video.f4mTester" ) :
     xbmc . executebuiltin ( 'RunPlugin(' + o00oIII + ')' )
    else :
     xbmc . Player ( ) . play ( o00oIII , Ii1 )
     if 57 - 57: I11i . iII111i % i1
   else :
    oOO0O00Oo0O0o = mu_playlist [ oooOooooO0oOO ]
    oOO0O00Oo0O0o = oOO0O00Oo0O0o . split ( '&regexs=' ) [ 0 ]
    Ii1 = xbmcgui . ListItem ( i111iiIiiIiI , iconImage = iI1IiiiIi , thumbnailImage = iI1IiiiIi )
    Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : i111iiIiiIiI } )
    Ii1 . setProperty ( "IsPlayable" , "true" )
    Ii1 . setPath ( oOO0O00Oo0O0o )
    if oOO0O00Oo0O0o . startswith ( "plugin://plugin.video.f4mTester" ) :
     xbmc . executebuiltin ( 'RunPlugin(' + oOO0O00Oo0O0o + ')' )
    else :
     xbmc . Player ( ) . play ( oOO0O00Oo0O0o , Ii1 )
 elif not queueVideo :
  if 32 - 32: Ii1I / I1Ii111 - O0 * iIii1I11I1II1
  iIIIiI . clear ( )
  IiI1ii1Ii = 0
  for I11iiiii1II in mu_playlist :
   IiI1ii1Ii += 1
   oo0oO0oOo0O = xbmcgui . ListItem ( '%s) %s' % ( str ( IiI1ii1Ii ) , name ) )
   if 75 - 75: i11i + i11i + I11i * i1
   try :
    if "$doregex" in I11iiiii1II :
     oo00o000O = I11iiiii1II . split ( '&regexs=' )
     if 62 - 62: iIii1I11I1II1 - i1IIi - OOooOOo
     oOO0O00Oo0O0o , iII1ii1I1i = o0O0oo0o ( oo00o000O [ 1 ] , oo00o000O [ 0 ] )
    elif "&mode=19" in I11iiiii1II :
     oOO0O00Oo0O0o = o0ooOo0OOOO0o ( I11iiiii1II . replace ( '&mode=19' , '' ) . replace ( ';' , '' ) )
    if oOO0O00Oo0O0o :
     iIIIiI . add ( oOO0O00Oo0O0o , oo0oO0oOo0O )
    else :
     raise
   except Exception :
    iIIIiI . add ( I11iiiii1II , oo0oO0oOo0O )
    pass
    if 72 - 72: o0 / ooOoO0o * I1Ii111 % iIii1I11I1II1
  xbmc . executebuiltin ( 'playlist.playoffset(video,0)' )
 else :
  if 53 - 53: i1iIi11iIIi1I . O0 . oOooOoO0Oo0O * I11i / i1
  O0Oo00ooOoO = xbmcgui . ListItem ( name )
  iIIIiI . add ( mu_playlist , O0Oo00ooOoO )
  if 34 - 34: o0
def iiI1i11I ( name , url ) :
 if o0o . getSetting ( 'save_location' ) == "" :
  if 31 - 31: i11i + I11i - OoooooooOO . Ii1I
  xbmc . executebuiltin ( "XBMC.Notification('','Choose a location to save files.',15000," + IIooooo + ")" )
  o0o . openSettings ( )
 o00O0o00oo = { 'url' : url , 'download_path' : o0o . getSetting ( 'save_location' ) }
 downloader . download ( name , o00O0o00oo )
 OO = xbmcgui . Dialog ( )
 if 28 - 28: iII111i . ii1IiI1i
 OO0OOO00 = OO . yesno ( '' , 'Do you want to add this file as a source?' )
 if OO0OOO00 :
  oOIIi1iiii1iI ( os . path . join ( o0o . getSetting ( 'save_location' ) , name ) )
  if 77 - 77: ii1IiI1i % i11i
def OOo00o0oo0 ( name , url , mode , iconimage , fanart , description , genre , date , credits , showcontext = False , regexs = None , reg_url = None , allinfo = { } ) :
 if 33 - 33: i1 . I11i + i1 / ii1IiI1i . I11i11Ii + o0
 if mode == 1 :
  I1111111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 else :
  I1111111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 O0OoOOO00 = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 Ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if len ( allinfo ) < 1 :
  Ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 else :
  Ii1 . setInfo ( type = "Video" , infoLabels = allinfo )
 Ii1 . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  o0OOOoOO00o = [ ]
  if 56 - 56: I11i11Ii * Ii1I / i1iIi11iIIi1I . i11iIiiIii - O0 / I11i11Ii
  OoIiIiIi1I1 = ''
  OoIiIiIi1I1 = OoIiIiIi1I1 == "true"
  if 26 - 26: i11iIiiIii - o0 / I11i . OOooOOo / IiII * I1Ii111
  OOO000oo0 = ''
  if 16 - 16: iIii1I11I1II1 * IiII + OOooOOo . O0 . i1
  if len ( OOO000oo0 ) > 0 :
   if OoIiIiIi1I1 :
    o0OOOoOO00o . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   else :
    o0OOOoOO00o . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 99 - 99: i11iIiiIii - IiII
  if showcontext == 'source' :
   if 85 - 85: ooOoO0o % ii1IiI1i
   if name in str ( OoOO ) :
    o0OOOoOO00o . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 95 - 95: i1iIi11iIIi1I * I11i * IiII . i1
    if 73 - 73: i1iIi11iIIi1I
  elif showcontext == 'download' :
   o0OOOoOO00o . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   o0OOOoOO00o . append ( ( 'Remove from KelTec-Media-Play Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  if showcontext == '!!update' :
   ii11iiII = (
 '%s?url=%s&mode=17&regexs=%s'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( reg_url ) , regexs )
 )
   o0OOOoOO00o . append ( ( '[COLOR orange]!!update[/COLOR]' , 'XBMC.RunPlugin(%s)' % ii11iiII ) )
  if not name in i1I :
   OOoo0oO0 = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if iIIIiI :
    OOoo0oO0 += 'playlist=' + urllib . quote_plus ( str ( iIIIiI ) . replace ( ',' , '||' ) )
   if regexs :
    OOoo0oO0 += "&regexs=" + regexs
    if 77 - 77: I11i11Ii / Ii1I . IiII / ooOoO0o - OoooooooOO
    if 76 - 76: O0
  Ii1 . addContextMenuItems ( o0OOOoOO00o )
 O0OoOOO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111111 , listitem = Ii1 , isFolder = True )
 return O0OoOOO00
 if 71 - 71: oOooOoO0Oo0O . i1IIi
def oO0O0o0Oooo ( name , url , mode , iconimage , fanart , description , genre , date , credits , year , director , duration , premiered , studio , rate , originaltitle , country , rating , userrating , votes , aired , showcontext = False , reg_url = None , regexs = None , allinfo = { } ) :
 if 19 - 19: i11i / i11i % ii1IiI1i + OOooOOo + OOooOOo + IiII
 if mode == 1 :
  I1111111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 else :
  I1111111 = sys . argv [ 0 ] + "?url=" + urllib . quote_plus ( codecs . encode ( base64 . b32encode ( base64 . b16encode ( url ) ) , 'rot_13' ) ) + "&mode=" + str ( mode ) + "&name=" + urllib . quote_plus ( name ) + "&fanart=" + urllib . quote_plus ( fanart )
 O0OoOOO00 = True
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 Ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultFolder.png" , thumbnailImage = iconimage )
 if len ( allinfo ) < 1 :
  Ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "credits" : credits , "Year" : year , "Director" : director , "Duration" : duration , "Premiered" : premiered , "Studio" : studio , "Mpaa" : rate , "Originaltitle" : originaltitle , "Country" : country , "Rating" : rating , "Userrating" : userrating , "Votes" : votes , "Aired" : aired } )
 else :
  Ii1 . setInfo ( type = "Video" , infoLabels = allinfo )
 Ii1 . setProperty ( "Fanart_Image" , fanart )
 if showcontext :
  o0OOOoOO00o = [ ]
  if 4 - 4: i1 + Ii1I / IiII + i1IIi % i1 % IiII
  OoIiIiIi1I1 = ''
  OoIiIiIi1I1 = OoIiIiIi1I1 == "true"
  if 80 - 80: iII111i
  OOO000oo0 = ''
  if 26 - 26: iIii1I11I1II1 . OoooooooOO - iIii1I11I1II1
  if len ( OOO000oo0 ) > 0 :
   if OoIiIiIi1I1 :
    o0OOOoOO00o . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   else :
    o0OOOoOO00o . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 59 - 59: ii1IiI1i + Ii1I . OOooOOo
  if showcontext == 'source' :
   if 87 - 87: i1iIi11iIIi1I
   if name in str ( OoOO ) :
    o0OOOoOO00o . append ( ( 'Remove from Sources' , 'XBMC.RunPlugin(%s?mode=8&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
    if 34 - 34: ooOoO0o . o0 / i11iIiiIii / IiII
    if 46 - 46: I11i11Ii + i11i * oOooOoO0Oo0O + I11i
  elif showcontext == 'download' :
   o0OOOoOO00o . append ( ( 'Download' , 'XBMC.RunPlugin(%s?url=%s&mode=9&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  elif showcontext == 'fav' :
   o0OOOoOO00o . append ( ( 'Remove from KelTec-Maedia-Play Favorites' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  if showcontext == '!!update' :
   ii11iiII = (
 '%s?url=%s&mode=17&regexs=%s'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( reg_url ) , regexs )
 )
   o0OOOoOO00o . append ( ( '[COLOR orange]!!update[/COLOR]' , 'XBMC.RunPlugin(%s)' % ii11iiII ) )
  if not name in i1I :
   OOoo0oO0 = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   if iIIIiI :
    OOoo0oO0 += 'playlist=' + urllib . quote_plus ( str ( iIIIiI ) . replace ( ',' , '||' ) )
   if regexs :
    OOoo0oO0 += "&regexs=" + regexs
    if 31 - 31: iII111i * i1 * iII111i + i1iIi11iIIi1I * i1 . ooOoO0o
    if 89 - 89: OoooooooOO * iII111i * oOooOoO0Oo0O . o00O0oo * iII111i / IiII
  Ii1 . addContextMenuItems ( o0OOOoOO00o )
 O0OoOOO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111111 , listitem = Ii1 , isFolder = True )
 return O0OoOOO00
 if 46 - 46: i11iIiiIii
def Iiiii ( url , title , media_type = 'video' ) :
 if 25 - 25: I11i11Ii * oOooOoO0Oo0O + I11i + ooOoO0o % I11i
 if 84 - 84: O0 % iII111i . iII111i . IiII * Ii1I
 import youtubedl
 if not url == '' :
  if media_type == 'audio' :
   youtubedl . single_YD ( url , download = True , audio = True )
  else :
   youtubedl . single_YD ( url , download = True )
 elif xbmc . Player ( ) . isPlaying ( ) == True :
  import YDStreamExtractor
  if YDStreamExtractor . isDownloading ( ) == True :
   if 43 - 43: o0 . ii1IiI1i % i1IIi
   YDStreamExtractor . manageDownloads ( )
  else :
   OO0O00 = xbmc . Player ( ) . getPlayingFile ( )
   if 65 - 65: OoooooooOO
   OO0O00 = OO0O00 . split ( '|User-Agent=' ) [ 0 ]
   oo0oO0oOo0O = { 'url' : OO0O00 , 'title' : title , 'media_type' : media_type }
   youtubedl . single_YD ( '' , download = True , dl_info = oo0oO0oOo0O )
 else :
  xbmc . executebuiltin ( "XBMC.Notification(DOWNLOAD,First Play [COLOR yellow]WHILE playing download[/COLOR] ,10000)" )
  if 22 - 22: I11i + i11i + I11i11Ii
def oOo00Oo0o00oo ( site_name , search_term = None ) :
 ii1ii11 = ''
 if os . path . exists ( oOO00Oo ) == False or o0o . getSetting ( 'clearseachhistory' ) == 'true' :
  OoOOIIIIIiI11Ii ( oOO00Oo , '' )
  o0o . setSetting ( "clearseachhistory" , "false" )
 if site_name == 'history' :
  Iii = IIiiI ( oOO00Oo )
  IIIII1iii = re . compile ( '(.+?):(.*?)(?:\r|\n)' ) . findall ( Iii )
  if 58 - 58: o0 + i1iIi11iIIi1I * iII111i
  for oO0o00oOOooO0 , search_term in IIIII1iii :
   if 'plugin://' in search_term :
    oo ( search_term , oO0o00oOOooO0 , ii1ii11 , '' , '' , '' , '' , '' , None , '' , total = int ( len ( IIIII1iii ) ) )
   else :
    oO0O0o0Oooo ( oO0o00oOOooO0 + ':' + search_term , oO0o00oOOooO0 , 26 , IIooooo , IIIIiiIiI , '' , '' , '' , '' )
 if not search_term :
  i11iiI1111 = xbmc . Keyboard ( '' , 'Enter Search Term' )
  i11iiI1111 . doModal ( )
  if ( i11iiI1111 . isConfirmed ( ) == False ) :
   return
  search_term = i11iiI1111 . getText ( )
  if len ( search_term ) == 0 :
   return
 search_term = search_term . replace ( ' ' , '+' )
 search_term = search_term . encode ( 'utf-8' )
 if 'youtube' in site_name :
  if 31 - 31: OOooOOo - IiII
  import _ytplist
  if 46 - 46: oOooOoO0Oo0O + I11i11Ii - iII111i
  O0oO0O = { }
  O0oO0O = _ytplist . YoUTube ( 'searchYT' , youtube = search_term , max_page = 4 , nosave = 'nosave' )
  IIiiii = len ( O0oO0O )
  for IiI1ii1Ii in O0oO0O :
   try :
    oO0o00oOOooO0 = O0oO0O [ IiI1ii1Ii ] [ 'title' ]
    I11i1 = O0oO0O [ IiI1ii1Ii ] [ 'date' ]
    try :
     IIiiiII11i = O0oO0O [ IiI1ii1Ii ] [ 'desc' ]
    except Exception :
     IIiiiII11i = 'UNAVAIABLE'
     if 34 - 34: i1 % OoooooooOO
    oOO0O00Oo0O0o = 'plugin://plugin.video.youtube/play/?video_id=' + O0oO0O [ IiI1ii1Ii ] [ 'url' ]
    ii1ii11 = 'http://img.youtube.com/vi/' + O0oO0O [ IiI1ii1Ii ] [ 'url' ] + '/0.jpg'
    oo ( oOO0O00Oo0O0o , oO0o00oOOooO0 , ii1ii11 , '' , '' , '' , '' , '' , None , '' , IIiiii )
   except Exception :
    oo0oO0oOOoo ( 'This item is ignored::' )
  iIIIi = site_name + ':' + search_term + '\n'
  OoOOIIIIIiI11Ii ( os . path . join ( OOoOoo , 'history' ) , iIIIi , append = True )
 elif 'dmotion' in site_name :
  oo0o00o0 = "https://api.dailymotion.com"
  if 84 - 84: o0 - I11i11Ii . o00O0oo . I1Ii111 - I11i11Ii
  import _DMsearch
  o0Oo0oO00Oooo = str ( o0o . getSetting ( 'familyFilter' ) )
  _DMsearch . listVideos ( oo0o00o0 + "/videos?fields=description,duration,id,owner.username,taken_time,thumbnail_large_url,title,views_total&search=" + search_term + "&sort=relevance&limit=100&family_filter=" + o0Oo0oO00Oooo + "&localization=en_EN&page=1" )
  if 31 - 31: i1IIi * I11i11Ii % iII111i + i1iIi11iIIi1I
  iIIIi = site_name + ':' + search_term + '\n'
  OoOOIIIIIiI11Ii ( os . path . join ( OOoOoo , 'history' ) , iIIIi , append = True )
 elif 'IMDBidplay' in site_name :
  oo0o00o0 = "http://www.omdbapi.com/?t="
  oOO0O00Oo0O0o = oo0o00o0 + search_term
  if 75 - 75: I11i / ooOoO0o - i11i % i11iIiiIii + i1iIi11iIIi1I
  o0OO0oooo = dict ( { 'User-Agent' : 'Mozilla/5.0 (Windows NT 6.3; rv:33.0) Gecko/20100101 Firefox/33.0' , 'Referer' : 'http://joker.org/' , 'Accept-Encoding' : 'gzip, deflate' , 'Content-Type' : 'application/json;charset=utf-8' , 'Accept' : 'application/json, text/plain, */*' } )
  if 13 - 13: o00O0oo - oOooOoO0Oo0O
  iiIiI1ii = requests . get ( oOO0O00Oo0O0o , headers = o0OO0oooo )
  ii1 = iiIiI1ii . json ( )
  iii11OO0oO = ii1 [ 'Response' ]
  if iii11OO0oO == 'True' :
   i1i11ii = ii1 [ 'imdbID' ]
   oO0o00oOOooO0 = ii1 [ 'Title' ] + ii1 [ 'Released' ]
   OO = xbmcgui . Dialog ( )
   OO0OOO00 = OO . yesno ( 'Check Movie Title' , 'PLAY :: %s ?' % oO0o00oOOooO0 )
   if OO0OOO00 :
    oOO0O00Oo0O0o = 'plugin://plugin.video.pulsar/movie/' + i1i11ii + '/play'
    iIIIi = oO0o00oOOooO0 + ':' + oOO0O00Oo0O0o + '\n'
    OoOOIIIIIiI11Ii ( oOO00Oo , iIIIi , append = True )
    return oOO0O00Oo0O0o
  else :
   if 86 - 86: ii1IiI1i - i1IIi + I11i11Ii * oOooOoO0Oo0O / i11iIiiIii % OOooOOo
   xbmc . executebuiltin ( "XBMC.Notification(No IMDB match found ,7000," + IIooooo + ")" )
   if 17 - 17: o00O0oo + o00O0oo . ii1IiI1i
def iiI1ii1Iii11I ( string ) :
 if isinstance ( string , basestring ) :
  if isinstance ( string , unicode ) :
   string = string . encode ( 'ascii' , 'ignore' )
 return string
def IIiIi11 ( string , encoding = 'utf-8' ) :
 if isinstance ( string , basestring ) :
  if not isinstance ( string , unicode ) :
   string = unicode ( string , encoding , 'ignore' )
 return string
def oO0OO0O0 ( s ) : return "" . join ( filter ( lambda iIIi1II1 : ord ( iIIi1II1 ) < 128 , s ) )
if 42 - 42: iIii1I11I1II1 - o00O0oo - Ii1I - ooOoO0o
def iIiI11II ( command ) :
 ii1 = ''
 try :
  ii1 = xbmc . executeJSONRPC ( IIiIi11 ( command ) )
 except UnicodeEncodeError :
  ii1 = xbmc . executeJSONRPC ( iiI1ii1Iii11I ( command ) )
  if 87 - 87: I11i11Ii . OoooooooOO * ooOoO0o * i11i / i1IIi * o0
 return IIiIi11 ( ii1 )
 if 25 - 25: iII111i * i1 * OOooOOo . oOooOoO0Oo0O
 if 93 - 93: o0
def I11Ii11iI1 ( ) :
 o0OoOo0o0OOoO0 = xbmc . getSkinDir ( )
 if o0OoOo0o0OOoO0 == 'skin.confluence' :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
 elif o0OoOo0o0OOoO0 == 'skin.aeon.nox' :
  xbmc . executebuiltin ( 'Container.SetViewMode(511)' )
 else :
  xbmc . executebuiltin ( 'Container.SetViewMode(500)' )
  if 30 - 30: iII111i % Ii1I + i1
  if 65 - 65: iIii1I11I1II1 . IiII / iII111i
def iI11ii ( url ) :
 oOoooO00OO0o = IIiIi11 ( '{"jsonrpc":"2.0","method":"Files.GetDirectory","params":{"directory":"%s","media":"video","properties":["thumbnail","title","year","dateadded","fanart","rating","season","episode","studio"]},"id":1}' ) % url
 if 29 - 29: I11i11Ii + i11i
 oOOo00ooO = json . loads ( iIiI11II ( oOoooO00OO0o ) )
 for I11iiiii1II in oOOo00ooO [ 'result' ] [ 'files' ] :
  url = I11iiiii1II [ 'file' ]
  oO0o00oOOooO0 = oO0OO0O0 ( I11iiiii1II [ 'label' ] )
  ii1ii11 = oO0OO0O0 ( I11iiiii1II [ 'thumbnail' ] )
  try :
   Oo000ooOOO = oO0OO0O0 ( I11iiiii1II [ 'fanart' ] )
  except Exception :
   Oo000ooOOO = ''
  try :
   I11i1 = I11iiiii1II [ 'year' ]
  except Exception :
   I11i1 = ''
  try :
   ooOoOOOoOo0oO0OoO = I11iiiii1II [ 'episode' ]
   I1ii11 = I11iiiii1II [ 'season' ]
   if ooOoOOOoOo0oO0OoO == - 1 or I1ii11 == - 1 :
    IIiiiII11i = ''
   else :
    IIiiiII11i = '[COLOR yellow] S' + str ( I1ii11 ) + '[/COLOR][COLOR hotpink] E' + str ( ooOoOOOoOo0oO0OoO ) + '[/COLOR]'
  except Exception :
   IIiiiII11i = ''
  try :
   IIIII = I11iiiii1II [ 'studio' ]
   if IIIII :
    IIiiiII11i += '\n Studio:[COLOR steelblue] ' + IIIII [ 0 ] + '[/COLOR]'
  except Exception :
   IIIII = ''
   if 65 - 65: ooOoO0o + IiII * IiII
  if I11iiiii1II [ 'filetype' ] == 'file' :
   oOO0OO0O ( url , oO0o00oOOooO0 , ii1ii11 , Oo000ooOOO , IIiiiII11i , '' , I11i1 , '' , None , '' , total = len ( oOOo00ooO [ 'result' ] [ 'files' ] ) )
   if 79 - 79: i1IIi / I11i11Ii - oOooOoO0Oo0O . O0
   if 56 - 56: I1Ii111 % O0 * i1IIi - i11i
  else :
   OOo00o0oo0 ( oO0o00oOOooO0 , url , 53 , ii1ii11 , Oo000ooOOO , IIiiiII11i , '' , I11i1 , '' )
   if 74 - 74: i1IIi - o0 % OOooOOo . O0 - OoooooooOO
   if 84 - 84: ooOoO0o
def oOO0OO0O ( url , name , iconimage , fanart , description , genre , date , showcontext , playlist , regexs , total , setCookie = "" , allinfo = { } ) :
 if 53 - 53: i1IIi
 o0OOOoOO00o = [ ]
 OoIiIiIi1I1 = o0o . getSetting ( 'parentalblocked' )
 OoIiIiIi1I1 = OoIiIiIi1I1 == "true"
 OOO000oo0 = o0o . getSetting ( 'parentalblockedpin' )
 if 59 - 59: i1 + oOooOoO0Oo0O % OoooooooOO - iIii1I11I1II1
 if len ( OOO000oo0 ) > 0 :
  if OoIiIiIi1I1 :
   o0OOOoOO00o . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  else :
   o0OOOoOO00o . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 9 - 9: i1IIi - o0
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O0OoOOO00 = True
 Oo00o0OOo0OO = False
 if regexs :
  I1i1iiIi = '17'
  if 'listrepeat' in regexs :
   Oo00o0OOo0OO = True
   if 45 - 45: o0 * o00O0oo / OoooooooOO + i1iIi11iIIi1I . ooOoO0o / i1iIi11iIIi1I
   if 64 - 64: iII111i / i1IIi % oOooOoO0Oo0O - i1
  o0OOOoOO00o . append ( ( o0Oo0O0Oo00oO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif ( any ( x in url for x in Ii1i ) and url . startswith ( 'http' ) ) or url . endswith ( '&mode=19' ) :
  url = url . replace ( '&mode=19' , '' )
  I1i1iiIi = '19'
  if 11 - 11: ii1IiI1i - OoooooooOO
  o0OOOoOO00o . append ( ( o0Oo0O0Oo00oO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  I1i1iiIi = '18'
  o0OOOoOO00o . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if o0o . getSetting ( 'dlaudioonly' ) == 'true' :
   o0OOOoOO00o . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
   if 16 - 16: I1Ii111 % OoooooooOO - o00O0oo * iII111i - iII111i
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
   if 27 - 27: I1Ii111 + iIii1I11I1II1 / I11i11Ii + i1iIi11iIIi1I % I11i11Ii + i1iIi11iIIi1I
  url = 'plugin://plugin.video.elementum/play?uri=' + url
  I1i1iiIi = '12'
 else :
  I1i1iiIi = '12'
  if 77 - 77: I11i11Ii * o00O0oo % iII111i
  o0OOOoOO00o . append ( ( o0Oo0O0Oo00oO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 if 'plugin://plugin.video.youtube/play/?video_id=' in url :
  I1iI = url . replace ( 'plugin://plugin.video.youtube/play/?video_id=' , 'https://www.youtube.com/watch?v=' )
  o0OOOoOO00o . append ( ( '!!Download [COLOR blue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( I1iI ) , urllib . quote_plus ( name ) ) ) )
 I1111111 = sys . argv [ 0 ] + "?"
 IIiiIooO0 = False
 if playlist :
  if o0o . getSetting ( 'add_playlist' ) == "false" and '$$LSPlayOnlyOne$$' not in playlist [ 0 ] :
   I1111111 += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1i1iiIi
  else :
   I1111111 += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR orange] (' + str ( len ( playlist ) ) + ' itens)[/COLOR]'
   IIiiIooO0 = True
 else :
  I1111111 += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1i1iiIi
 if regexs :
  I1111111 += "&regexs=" + regexs
 if not setCookie == '' :
  I1111111 += "&setCookie=" + urllib . quote_plus ( setCookie )
 if iconimage and not iconimage == '' :
  I1111111 += "&iconimage=" + urllib . quote_plus ( iconimage )
  if 47 - 47: I11i . ooOoO0o % i11i + I11i11Ii - OOooOOo . i11i
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 Ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 if 37 - 37: iIii1I11I1II1 . oOooOoO0Oo0O % i1iIi11iIIi1I % OoooooooOO . OoooooooOO / O0
 if allinfo == None or len ( allinfo ) < 1 :
  Ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date } )
 else :
  Ii1 . setInfo ( type = "Video" , infoLabels = allinfo )
 Ii1 . setProperty ( "Fanart_Image" , fanart )
 if 25 - 25: i11i % i11i - iII111i . O0
 if ( not IIiiIooO0 ) and not any ( x in url for x in I1 ) and not '$PLAYERPROXY$=' in url :
  if regexs :
   if 79 - 79: I1Ii111 / i1iIi11iIIi1I * OoooooooOO * o0 + oOooOoO0Oo0O
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) and 'listrepeat' not in urllib . unquote_plus ( regexs ) :
    if 68 - 68: Ii1I / iIii1I11I1II1 . I11i11Ii + i11iIiiIii + i1
    Ii1 . setProperty ( 'IsPlayable' , 'true' )
  else :
   Ii1 . setProperty ( 'IsPlayable' , 'true' )
 else :
  oo0oO0oOOoo ( 'NOT setting isplayable' + url )
 if showcontext :
  if 92 - 92: i1iIi11iIIi1I . i1 . iII111i % o0
  if showcontext == 'fav' :
   o0OOOoOO00o . append (
 ( 'Remove CANAIS do Favoritos' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in i1I :
   try :
    OOoo0oO0 = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   except :
    OOoo0oO0 = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage . encode ( "utf-8" ) ) , urllib . quote_plus ( fanart . encode ( "utf-8" ) ) )
 )
   if playlist :
    OOoo0oO0 += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    OOoo0oO0 += "&regexs=" + regexs
    if 58 - 58: ii1IiI1i % iII111i * iII111i - IiII
  Ii1 . addContextMenuItems ( o0OOOoOO00o )
 try :
  if not playlist is None :
   if o0o . getSetting ( 'add_playlist' ) == "false" :
    I111IiI11 = name . split ( ') ' ) [ 1 ]
    oOO00OoOo = [
 ( 'Play ' + I111IiI11 + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( I111IiI11 ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
    Ii1 . addContextMenuItems ( oOO00OoOo )
 except : pass
 if 83 - 83: i1IIi
 O0OoOOO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111111 , listitem = Ii1 , totalItems = total , isFolder = Oo00o0OOo0OO )
 if 43 - 43: I11i / oOooOoO0Oo0O
 if 46 - 46: ii1IiI1i % I1Ii111 + OoooooooOO * iII111i
 return O0OoOOO00
 if 21 - 21: OOooOOo . IiII
def oo ( url , name , iconimage , fanart , description , genre , date , year , director , duration , premiered , studio , rate , originaltitle , country , rating , userrating , votes , aired , showcontext , playlist , regexs , total , setCookie = "" , allinfo = { } ) :
 if 78 - 78: oOooOoO0Oo0O * i1IIi / oOooOoO0Oo0O / i1iIi11iIIi1I
 o0OOOoOO00o = [ ]
 OoIiIiIi1I1 = o0o . getSetting ( 'parentalblocked' )
 OoIiIiIi1I1 = OoIiIiIi1I1 == "true"
 OOO000oo0 = o0o . getSetting ( 'parentalblockedpin' )
 if 28 - 28: I11i11Ii / I1Ii111 . IiII + i1iIi11iIIi1I + Ii1I % I11i11Ii
 if len ( OOO000oo0 ) > 0 :
  if OoIiIiIi1I1 :
   o0OOOoOO00o . append ( ( 'Disable Parental Block' , 'XBMC.RunPlugin(%s?mode=55&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
  else :
   o0OOOoOO00o . append ( ( 'Enable Parental Block' , 'XBMC.RunPlugin(%s?mode=56&name=%s)' % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) ) )
   if 45 - 45: I11i11Ii / O0 % OoooooooOO
 try :
  name = name . encode ( 'utf-8' )
 except : pass
 O0OoOOO00 = True
 Oo00o0OOo0OO = False
 if regexs :
  I1i1iiIi = '17'
  if 'listrepeat' in regexs :
   Oo00o0OOo0OO = True
   if 92 - 92: iII111i . o0 . Ii1I - OoooooooOO / o00O0oo
   if 80 - 80: iIii1I11I1II1 / i11iIiiIii + IiII
  o0OOOoOO00o . append ( ( o0Oo0O0Oo00oO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif ( any ( x in url for x in Ii1i ) and url . startswith ( 'http' ) ) or url . endswith ( '&mode=19' ) :
  url = url . replace ( '&mode=19' , '' )
  I1i1iiIi = '19'
  if 41 - 41: ooOoO0o + i1iIi11iIIi1I * oOooOoO0Oo0O * O0 * I11i11Ii - o0
  o0OOOoOO00o . append ( ( o0Oo0O0Oo00oO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 elif url . endswith ( '&mode=18' ) :
  url = url . replace ( '&mode=18' , '' )
  I1i1iiIi = '18'
  o0OOOoOO00o . append ( ( '[COLOR white]!!Download!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=23&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
  if o0o . getSetting ( 'dlaudioonly' ) == 'true' :
   o0OOOoOO00o . append ( ( '!!Download [COLOR seablue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
   if 96 - 96: oOooOoO0Oo0O - iIii1I11I1II1
 elif url . startswith ( 'magnet:?xt=' ) or '.torrent' in url :
  if '&' in url and not '&amp;' in url :
   url = url . replace ( '&' , '&amp;' )
   if 25 - 25: OoooooooOO . iII111i % IiII . I1Ii111
  url = 'plugin://plugin.video.elementum/play?uri=' + url
  I1i1iiIi = '12'
 else :
  I1i1iiIi = '12'
  if 67 - 67: OoooooooOO + ooOoO0o / o00O0oo
  o0OOOoOO00o . append ( ( o0Oo0O0Oo00oO , 'XBMC.RunPlugin(%s?url=%s&mode=21&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( url ) , urllib . quote_plus ( name ) ) ) )
 if 'plugin://plugin.video.youtube/play/?video_id=' in url :
  I1iI = url . replace ( 'plugin://plugin.video.youtube/play/?video_id=' , 'https://www.youtube.com/watch?v=' )
  o0OOOoOO00o . append ( ( '!!Download [COLOR blue]Audio!![/COLOR]' , 'XBMC.RunPlugin(%s?url=%s&mode=24&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( I1iI ) , urllib . quote_plus ( name ) ) ) )
 I1111111 = sys . argv [ 0 ] + "?"
 IIiiIooO0 = False
 if playlist :
  if o0o . getSetting ( 'add_playlist' ) == "false" and '$$LSPlayOnlyOne$$' not in playlist [ 0 ] :
   I1111111 += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1i1iiIi
  else :
   I1111111 += "mode=13&name=%s&playlist=%s" % ( urllib . quote_plus ( name ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) )
   name = name + '[COLOR ' + oo0oOo + '] (' + str ( len ( playlist ) ) + ' ' + o000O0o + ')[/COLOR]'
   IIiiIooO0 = True
 else :
  I1111111 += "url=" + urllib . quote_plus ( url ) + "&mode=" + I1i1iiIi
 if regexs :
  I1111111 += "&regexs=" + regexs
 if not setCookie == '' :
  I1111111 += "&setCookie=" + urllib . quote_plus ( setCookie )
 if iconimage and not iconimage == '' :
  I1111111 += "&iconimage=" + urllib . quote_plus ( iconimage )
  if 75 - 75: I1Ii111 / OoooooooOO . oOooOoO0Oo0O + ooOoO0o - i11i
 if date == '' :
  date = None
 else :
  description += '\n\nDate: %s' % date
 Ii1 = xbmcgui . ListItem ( name , iconImage = "DefaultVideo.png" , thumbnailImage = iconimage )
 if 33 - 33: I1Ii111 / I1Ii111 . i11iIiiIii * ii1IiI1i + i1
 if allinfo == None or len ( allinfo ) < 1 :
  Ii1 . setInfo ( type = "Video" , infoLabels = { "Title" : name , "Plot" : description , "Genre" : genre , "dateadded" : date , "Year" : year , "Director" : director , "Duration" : duration , "Premiered" : premiered , "Studio" : studio , "rate" : rate , "Originaltitle" : originaltitle , "Country" : country , "Rating" : rating , "Userrating" : userrating , "Votes" : votes , "Aired" : aired } )
 else :
  Ii1 . setInfo ( type = "Video" , infoLabels = allinfo )
 Ii1 . setProperty ( "Fanart_Image" , fanart )
 if 16 - 16: I1Ii111
 if ( not IIiiIooO0 ) and not any ( x in url for x in I1 ) and not '$PLAYERPROXY$=' in url :
  if regexs :
   if 10 - 10: o0 . I1Ii111 * iIii1I11I1II1 - OOooOOo - o0 / ooOoO0o
   if '$pyFunction:playmedia(' not in urllib . unquote_plus ( regexs ) and 'notplayable' not in urllib . unquote_plus ( regexs ) and 'listrepeat' not in urllib . unquote_plus ( regexs ) :
    if 13 - 13: OOooOOo + o0 % I1Ii111 % OoooooooOO
    Ii1 . setProperty ( 'IsPlayable' , 'true' )
  else :
   Ii1 . setProperty ( 'IsPlayable' , 'true' )
 else :
  oo0oO0oOOoo ( 'NOT setting isplayable' + url )
 if showcontext :
  if 22 - 22: ooOoO0o
  if showcontext == 'fav' :
   o0OOOoOO00o . append (
 ( 'Remove CANAIS do Favoritos' , 'XBMC.RunPlugin(%s?mode=6&name=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) ) )
 )
  elif not name in i1I :
   try :
    OOoo0oO0 = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage ) , urllib . quote_plus ( fanart ) )
 )
   except :
    OOoo0oO0 = (
 '%s?mode=5&name=%s&url=%s&iconimage=%s&fanart=%s&fav_mode=0'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( name ) , urllib . quote_plus ( url ) , urllib . quote_plus ( iconimage . encode ( "utf-8" ) ) , urllib . quote_plus ( fanart . encode ( "utf-8" ) ) )
 )
   if playlist :
    OOoo0oO0 += 'playlist=' + urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) )
   if regexs :
    OOoo0oO0 += "&regexs=" + regexs
    if 23 - 23: O0
  Ii1 . addContextMenuItems ( o0OOOoOO00o )
 try :
  if not playlist is None :
   if o0o . getSetting ( 'add_playlist' ) == "false" :
    I111IiI11 = name . split ( ') ' ) [ 1 ]
    oOO00OoOo = [
 ( 'Play ' + I111IiI11 + ' PlayList' , 'XBMC.RunPlugin(%s?mode=13&name=%s&playlist=%s)'
 % ( sys . argv [ 0 ] , urllib . quote_plus ( I111IiI11 ) , urllib . quote_plus ( str ( playlist ) . replace ( ',' , '||' ) ) ) )
 ]
    Ii1 . addContextMenuItems ( oOO00OoOo )
 except : pass
 if 41 - 41: i1IIi . I11i / o00O0oo / i1 % I1Ii111 - iII111i
 O0OoOOO00 = xbmcplugin . addDirectoryItem ( handle = int ( sys . argv [ 1 ] ) , url = I1111111 , listitem = Ii1 , totalItems = total , isFolder = Oo00o0OOo0OO )
 if 14 - 14: ii1IiI1i - i11iIiiIii * ooOoO0o
 if 39 - 39: OoooooooOO
 return O0OoOOO00
 if 19 - 19: i11iIiiIii
def oOOOO ( url , name , iconimage , setresolved = True ) :
 if setresolved :
  OoOOoo0 = True
  if '$$LSDirect$$' in url :
   url = url . replace ( '$$LSDirect$$' , '' )
   OoOOoo0 = False
   if 93 - 93: i11i * o0 % i1
  Ii1 = xbmcgui . ListItem ( name , iconImage = iconimage )
  Ii1 . setInfo ( type = 'Video' , infoLabels = { 'Title' : name } )
  Ii1 . setProperty ( "IsPlayable" , "true" )
  Ii1 . setPath ( url )
  if not OoOOoo0 :
   xbmc . Player ( ) . play ( url )
  else :
   xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , Ii1 )
   if 67 - 67: i1 + I11i11Ii . o00O0oo - i1IIi . o0
 else :
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + url + ')' )
  if 12 - 12: I1Ii111 / i1iIi11iIIi1I / O0 * I1Ii111
  if 51 - 51: o00O0oo * IiII / i1IIi
  if 2 - 2: OOooOOo + I1Ii111 . IiII - i1IIi + ooOoO0o
  if 54 - 54: OoooooooOO . OOooOOo - IiII
def O0OO0o0OO0OO ( link ) :
 oOO0O00Oo0O0o = urllib . urlopen ( link )
 oo0o = oOO0O00Oo0O0o . read ( )
 oOO0O00Oo0O0o . close ( )
 oO0o00o000Oo0 = oo0o . split ( "Jetzt" )
 ii1I1iIi = oO0o00o000Oo0 [ 1 ] . split ( 'programm/detail.php?const_id=' )
 O0o0OOo0o0o = ii1I1iIi [ 1 ] . split ( '<br /><a href="/' )
 o0oO00oooo = O0o0OOo0o0o [ 0 ] [ 40 : len ( O0o0OOo0o0o [ 0 ] ) ]
 ooo0Oo00O = ii1I1iIi [ 2 ] . split ( "</a></p></div>" )
 I1iII1 = ooo0Oo00O [ 0 ] [ 17 : len ( ooo0Oo00O [ 0 ] ) ]
 I1iII1 = I1iII1 . encode ( 'utf-8' )
 return "  - " + I1iII1 + " - " + o0oO00oooo
 if 70 - 70: i1IIi % o00O0oo . ii1IiI1i - I1Ii111 + I11i
 if 84 - 84: OOooOOo + i11i * i11i % i1 / IiII + o00O0oo
def I1IiIiIi1IiI1 ( url , regex ) :
 ii1 = i1II ( url )
 try :
  IiI1ii1Ii = re . findall ( regex , ii1 ) [ 0 ]
  return IiI1ii1Ii
 except :
  oo0oO0oOOoo ( 'regex failed' )
  oo0oO0oOOoo ( regex )
  return
  if 9 - 9: IiII
def iIi11I1II ( d , root = "root" , nested = 0 ) :
 if 93 - 93: ii1IiI1i - o00O0oo % ii1IiI1i
 I11II1 = lambda III11I11iIi1 : '<' + III11I11iIi1 + '>'
 I11i1I1iIiI = lambda III11I11iIi1 : '</' + III11I11iIi1 + '>\n'
 if 100 - 100: i1IIi % iII111i
 oO000O = lambda IIIIIIi1i , Oo0o0OoOoOo0 : Oo0o0OoOoOo0 + I11II1 ( I11iiI11I1II ) + str ( IIIIIIi1i ) + I11i1I1iIiI ( I11iiI11I1II )
 Oo0o0OoOoOo0 = I11II1 ( root ) + '\n' if root else ""
 if 70 - 70: ii1IiI1i . I1Ii111
 for I11iiI11I1II , iII1i111iI in d . iteritems ( ) :
  IiI1iI1 = type ( iII1i111iI )
  if nested == 0 : I11iiI11I1II = 'regex'
  if IiI1iI1 is list :
   for IIIIIIi1i in iII1i111iI :
    IIIIIIi1i = escape ( IIIIIIi1i )
    Oo0o0OoOoOo0 = oO000O ( IIIIIIi1i , Oo0o0OoOoOo0 )
    if 99 - 99: OOooOOo / i1IIi
  if IiI1iI1 is dict :
   Oo0o0OoOoOo0 = oO000O ( '\n' + iIi11I1II ( iII1i111iI , None , nested + 1 ) , Oo0o0OoOoOo0 )
  if IiI1iI1 is not list and IiI1iI1 is not dict :
   if not iII1i111iI is None : iII1i111iI = escape ( iII1i111iI )
   if 2 - 2: OOooOOo . IiII
   if iII1i111iI is None :
    Oo0o0OoOoOo0 = oO000O ( iII1i111iI , Oo0o0OoOoOo0 )
   else :
    if 42 - 42: i1iIi11iIIi1I - ii1IiI1i * I1Ii111 - o00O0oo
    Oo0o0OoOoOo0 = oO000O ( iII1i111iI . encode ( "utf-8" ) , Oo0o0OoOoOo0 )
    if 75 - 75: IiII * I11i11Ii / ooOoO0o * I11i11Ii / o00O0oo
 Oo0o0OoOoOo0 += I11i1I1iIiI ( root ) if root else ""
 if 14 - 14: i1IIi * iIii1I11I1II1 - iII111i * o0 - IiII / OOooOOo
 return Oo0o0OoOoOo0
 if 73 - 73: ii1IiI1i - o0 * O0 - o0 - i1iIi11iIIi1I
def oOoO0o0o ( ) :
 import ntpath
 ii1 = OOO ( 'https://elementumorg.github.io/' , '' )
 O00O000oOO0oO = re . compile ( '<div class="platform-asset"><a href="(.*?)" title="(.*?)".+?</a>' ) . findall ( ii1 )
 OO0i1Ii1II11 = [ ]
 for OoOoO , oO0o00oOOooO0 in O00O000oOO0oO :
  if '-' in OoOoO and not 'Client' in oO0o00oOOooO0 :
   IiiIIii1I1I = ntpath . basename ( OoOoO )
   IIi = IiiIIii1I1I . split ( '-' ) [ 0 ]
   IIiIi1II1IiI = oO0o00oOOooO0 . strip ( )
   if IIi == 'plugin.video.elementum' and IIiIi1II1IiI == 'Android x86' and xbmc . getCondVisibility ( 'system.platform.android' ) :
    oo0OoO = 'Elementum Android x86'
    I11iIiiI = 'special://home/addons/' + IIi
    OO0i1Ii1II11 . append ( ( oo0OoO , IIi , OoOoO , I11iIiiI ) )
   elif IIi == 'plugin.video.elementum' and IIiIi1II1IiI == 'Universal' :
    oo0OoO = 'Elementum Universal'
    I11iIiiI = 'special://home/addons/' + IIi
    OO0i1Ii1II11 . append ( ( oo0OoO , IIi , OoOoO , I11iIiiI ) )
 if len ( OO0i1Ii1II11 ) > 0 :
  OO000oo0o = OO0i1Ii1II11 [ 0 ] [ 0 ]
  I11iiIiI1II11 = OO0i1Ii1II11 [ 0 ] [ 1 ]
  OOOoOOOo = OO0i1Ii1II11 [ 0 ] [ 2 ]
  I11iIiiI = OO0i1Ii1II11 [ 0 ] [ 3 ]
  oO0000 = 'true'
 else :
  OO000oo0o = ''
  I11iiIiI1II11 = ''
  OOOoOOOo = ''
  I11iIiiI = ''
  oO0000 = 'false'
 return OO000oo0o , I11iiIiI1II11 , OOOoOOOo , I11iIiiI , oO0000
 if 71 - 71: i1 . oOooOoO0Oo0O - ii1IiI1i - I11i11Ii - i1IIi - oOooOoO0Oo0O
def iIIiiiIIi1111 ( ) :
 try :
  ooO0OO0Oooo0o = os . path . join ( oO0000OOo00 , 'check.txt' )
  if os . path . isfile ( ooO0OO0Oooo0o ) :
   OOoO00o000 = open ( ooO0OO0Oooo0o , 'r+' )
   if OOoO00o000 and OOoO00o000 . read ( ) == '1' :
    OOoO00o000 . close ( )
    OO000oo0o , I11iiIiI1II11 , OOOoOOOo , I11iIiiI , oO0000 = oOoO0o0o ( )
    if oO0000 == 'true' :
     if os . path . exists ( xbmc . translatePath ( I11iIiiI ) ) == False :
      if xbmcgui . Dialog ( ) . yesno ( __addonname__ , 'Deseja Instalar o Elementum?' ) :
       iIi1Iii11111I1iii ( OO000oo0o , I11iiIiI1II11 , OOOoOOOo )
  else :
   OOoO00o000 = open ( ooO0OO0Oooo0o , 'w' )
   OOoO00o000 . write ( '1' )
   OOoO00o000 . close ( )
   xbmcgui . Dialog ( ) . ok ( '[B][COLOR white]AVISO[/COLOR][/B]' , 'FECHE O KODI E ABRA NOVAMENTE PARA VERIFICAR COMPLEMENTOS' )
 except :
  pass
  if 67 - 67: ii1IiI1i + OOooOOo * I1Ii111 / i11i % i1iIi11iIIi1I % i1iIi11iIIi1I
def iIi1Iii11111I1iii ( name_addon , id_addon , link_addon ) :
 try :
  import downloader
  import database
  import ntpath
  IiiIIii1I1I = ntpath . basename ( link_addon )
  IIIII1IIiIi = xbmc . translatePath ( os . path . join ( 'special://' , 'home/' , 'addons' , 'packages' ) )
  oo0oOOoOoo = xbmc . translatePath ( os . path . join ( 'special://' , 'home/' , 'addons' ) )
  OOOo0Ooo0o00o = os . path . join ( IIIII1IIiIi , IiiIIii1I1I )
  downloader . download ( link_addon , name_addon , OOOo0Ooo0o00o )
  oOo = xbmcgui . DialogProgress ( )
  oOo . create ( "Install addons" , "Baixando " + name_addon + "...." , '' , '' )
  xbmc . executebuiltin ( "Extract(" + OOOo0Ooo0o00o + "," + oo0oOOoOoo + ")" )
  oOo . update ( 100 )
  oOo . close ( )
  xbmc . executebuiltin ( "XBMC.UpdateLocalAddons()" )
  database . enable_addon ( 0 , id_addon )
  database . check_database ( id_addon )
  xbmc . executebuiltin ( "XBMC.Container.Update()" )
  I1I1I ( '%s instalado com sucesso' % name_addon )
 except :
  I1I1I ( 'Erro ao baixar o complemento' )
  if 94 - 94: i1IIi / ii1IiI1i / oOooOoO0Oo0O * ooOoO0o * I11i11Ii
  if 21 - 21: OoooooooOO + O0 / OoooooooOO / I11i
xbmcplugin . setContent ( int ( sys . argv [ 1 ] ) , 'movies' )
if 44 - 44: i1IIi . ii1IiI1i - o00O0oo . I11i . i1 + OOooOOo
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_UNSORTED )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_LABEL )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_DATE )
except :
 pass
try :
 xbmcplugin . addSortMethod ( int ( sys . argv [ 1 ] ) , xbmcplugin . SORT_METHOD_GENRE )
except :
 pass
 if 17 - 17: iIii1I11I1II1 + i1IIi . ii1IiI1i + iII111i % i1IIi . OOooOOo
o00O0o00oo = iIo00oo ( )
if 57 - 57: OOooOOo
oOO0O00Oo0O0o = None
oO0o00oOOooO0 = None
I1i1iiIi = None
iIIIiI = None
iI1IiiiIi = None
Oo000ooOOO = IIIIiiIiI
iIIIiI = None
OoOO00OO0 = None
IiIIiIIIiIii = None
if 46 - 46: i1 . iIii1I11I1II1 + OoooooooOO - o00O0oo * I11i11Ii * i11iIiiIii
try :
 oOO0O00Oo0O0o = urllib . unquote_plus ( o00O0o00oo [ "url" ] ) . decode ( 'utf-8' )
except :
 pass
try :
 oO0o00oOOooO0 = urllib . unquote_plus ( o00O0o00oo [ "name" ] )
except :
 pass
try :
 iI1IiiiIi = urllib . unquote_plus ( o00O0o00oo [ "iconimage" ] )
except :
 pass
try :
 Oo000ooOOO = urllib . unquote_plus ( o00O0o00oo [ "fanart" ] )
except :
 pass
try :
 I1i1iiIi = int ( o00O0o00oo [ "mode" ] )
except :
 pass
try :
 iIIIiI = eval ( urllib . unquote_plus ( o00O0o00oo [ "playlist" ] ) . replace ( '||' , ',' ) )
except :
 pass
try :
 OoOO00OO0 = int ( o00O0o00oo [ "fav_mode" ] )
except :
 pass
try :
 IiIIiIIIiIii = o00O0o00oo [ "regexs" ]
except :
 pass
o0OoO0O = ''
try :
 o0OoO0O = urllib . unquote_plus ( o00O0o00oo [ "playitem" ] )
except :
 pass
 if 95 - 95: Ii1I + I11i11Ii + I11i11Ii
oo0oO0oOOoo ( "Mode: " + str ( I1i1iiIi ) )
if not oOO0O00Oo0O0o is None :
 oo0oO0oOOoo ( "URL: " + str ( oOO0O00Oo0O0o . encode ( 'utf-8' ) ) )
oo0oO0oOOoo ( "Name: " + str ( oO0o00oOOooO0 ) )
if 33 - 33: i1IIi % OoooooooOO / OoooooooOO
if not o0OoO0O == '' :
 I1111ii11IIII = oo00O00oO000o ( '' , data = o0OoO0O )
 oO0o00oOOooO0 , oOO0O00Oo0O0o , IiIIiIIIiIii = II1I1iiIII1I1 ( I1111ii11IIII , None , dontLink = True )
 I1i1iiIi = 117
 if 88 - 88: ooOoO0o - iII111i - OOooOOo + i1IIi
if I1i1iiIi == None :
 iIIiiiIIi1111 ( )
 oo0oO0oOOoo ( "Index" )
 oOOoo0000O0o0 ( True )
 if 15 - 15: I11i
elif I1i1iiIi == 1 :
 oo0oO0oOOoo ( "getData" )
 ii1 = None
 oOO0O00Oo0O0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( oOO0O00Oo0O0o , 'rot_13' ) ) )
 if IiIIiIIIiIii :
  ii1 = o0O0oo0o ( IiIIiIIIiIii , oOO0O00Oo0O0o )
  oOO0O00Oo0O0o = ''
  if 31 - 31: OOooOOo % i1IIi . OoooooooOO - i1 + OoooooooOO
 oo0o0000 ( oOO0O00Oo0O0o , Oo000ooOOO , ii1 )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 45 - 45: I11i + Ii1I / OoooooooOO - iII111i + OoooooooOO
elif I1i1iiIi == 2 :
 oo0oO0oOOoo ( "getChannelItems" )
 oOO0O00Oo0O0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( oOO0O00Oo0O0o , 'rot_13' ) ) )
 if IiIIiIIIiIii :
  ii1 = o0O0oo0o ( IiIIiIIIiIii , oOO0O00Oo0O0o )
  oOO0O00Oo0O0o = ''
  if 42 - 42: iIii1I11I1II1 * oOooOoO0Oo0O * ooOoO0o
 oO00OoOO ( oO0o00oOOooO0 , oOO0O00Oo0O0o , Oo000ooOOO )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 62 - 62: I11i * O0 % I1Ii111 . I1Ii111 . oOooOoO0Oo0O
elif I1i1iiIi == 3 :
 oo0oO0oOOoo ( "getSubChannelItems" )
 oOO0O00Oo0O0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( oOO0O00Oo0O0o , 'rot_13' ) ) )
 if IiIIiIIIiIii :
  ii1 = o0O0oo0o ( IiIIiIIIiIii , oOO0O00Oo0O0o )
  oOO0O00Oo0O0o = ''
  if 91 - 91: i1IIi . IiII
 i1iIiIi1I ( oO0o00oOOooO0 , oOO0O00Oo0O0o , Oo000ooOOO )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 37 - 37: IiII - Ii1I + iIii1I11I1II1 / ooOoO0o - i1iIi11iIIi1I . i1
elif I1i1iiIi == 4 :
 oo0oO0oOOoo ( "getFavorites" )
 OoOooO0 ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 62 - 62: ii1IiI1i
elif I1i1iiIi == 5 :
 oo0oO0oOOoo ( "addFavorite" )
 try :
  oO0o00oOOooO0 = oO0o00oOOooO0 . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  oO0o00oOOooO0 = oO0o00oOOooO0 . split ( '  - ' ) [ 0 ]
 except :
  pass
 o0oOOO ( oO0o00oOOooO0 , oOO0O00Oo0O0o , iI1IiiiIi , Oo000ooOOO , OoOO00OO0 )
 if 47 - 47: ooOoO0o % I11i * i1iIi11iIIi1I . iIii1I11I1II1 % I11i11Ii + OoooooooOO
elif I1i1iiIi == 6 :
 oo0oO0oOOoo ( "rmFavorite" )
 try :
  oO0o00oOOooO0 = oO0o00oOOooO0 . split ( '\\ ' ) [ 1 ]
 except :
  pass
 try :
  oO0o00oOOooO0 = oO0o00oOOooO0 . split ( '  - ' ) [ 0 ]
 except :
  pass
 IIi1i1ii11I1 ( oO0o00oOOooO0 )
 if 2 - 2: ooOoO0o % OoooooooOO - o00O0oo * ii1IiI1i * I1Ii111
elif I1i1iiIi == 7 :
 oo0oO0oOOoo ( "addSource" )
 oOIIi1iiii1iI ( oOO0O00Oo0O0o )
 if 99 - 99: iIii1I11I1II1 . I11i11Ii / o00O0oo . I11i % oOooOoO0Oo0O * Ii1I
elif I1i1iiIi == 8 :
 oo0oO0oOOoo ( "rmSource" )
 iI1iIIIi1i ( oO0o00oOOooO0 )
 if 95 - 95: OOooOOo
elif I1i1iiIi == 9 :
 oo0oO0oOOoo ( "download_file" )
 iiI1i11I ( oO0o00oOOooO0 , oOO0O00Oo0O0o )
 if 80 - 80: I1Ii111
elif I1i1iiIi == 10 :
 oo0oO0oOOoo ( "getCommunitySources" )
 ooO0o ( )
 if 42 - 42: OoooooooOO * i11i
elif I1i1iiIi == 11 :
 oo0oO0oOOoo ( "addSource" )
 oOIIi1iiii1iI ( oOO0O00Oo0O0o )
 if 53 - 53: ooOoO0o + i1IIi . i1iIi11iIIi1I / i11iIiiIii + iII111i % o0
elif I1i1iiIi == 12 :
 oo0oO0oOOoo ( "setResolvedUrl" )
 if not oOO0O00Oo0O0o . startswith ( "plugin://plugin" ) or not any ( x in oOO0O00Oo0O0o for x in I1 ) :
  IiI1ii1Ii = xbmcgui . ListItem ( path = oOO0O00Oo0O0o )
  xbmcplugin . setResolvedUrl ( int ( sys . argv [ 1 ] ) , True , IiI1ii1Ii )
 else :
  print 'Not setting setResolvedUrl'
  xbmc . executebuiltin ( 'XBMC.RunPlugin(' + oOO0O00Oo0O0o + ')' )
  if 9 - 9: o00O0oo . Ii1I - I11i11Ii . ooOoO0o
  if 39 - 39: I11i
elif I1i1iiIi == 13 :
 oo0oO0oOOoo ( "play_playlist" )
 ii1O0O ( oO0o00oOOooO0 , iIIIiI )
 if 70 - 70: I1Ii111 % i1iIi11iIIi1I % oOooOoO0Oo0O
elif I1i1iiIi == 14 :
 oo0oO0oOOoo ( "get_xml_database" )
 IiII1II11I ( oOO0O00Oo0O0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 95 - 95: o0 - ooOoO0o / O0 * oOooOoO0Oo0O - i1
elif I1i1iiIi == 15 :
 oo0oO0oOOoo ( "browse_xml_database" )
 IiII1II11I ( oOO0O00Oo0O0o , True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 12 - 12: iIii1I11I1II1 % I11i11Ii . IiII . I1Ii111 % i11iIiiIii
elif I1i1iiIi == 16 :
 oo0oO0oOOoo ( "browse_community" )
 ooO0o ( True )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 2 - 2: OOooOOo * OOooOOo . o0 * iII111i * iIii1I11I1II1
elif I1i1iiIi == 17 or I1i1iiIi == 117 :
 oo0oO0oOOoo ( "getRegexParsed" )
 if 13 - 13: Ii1I / O0 . i11iIiiIii * i1IIi % i11iIiiIii
 ii1 = None
 if IiIIiIIIiIii and 'listrepeat' in urllib . unquote_plus ( IiIIiIIIiIii ) :
  oo0OoOO0o0o , OO0OOO00 , iI1IiiiIiI1Ii , IiIIiIIIiIii = o0O0oo0o ( IiIIiIIIiIii , oOO0O00Oo0O0o )
  if 8 - 8: o0 - OoooooooOO
  Ooi1IIii11i1I1 = ''
  if 99 - 99: i11i / I1Ii111 % OoooooooOO . i11iIiiIii
  if 18 - 18: i1 . o00O0oo
  OoIII = iI1IiiiIiI1Ii [ 'name' ]
  OO00O = IiIIiIIIiIii . pop ( OoIII )
  if 66 - 66: iII111i / O0 . Ii1I + IiII - iII111i . Ii1I
  oOO0O00Oo0O0o = ''
  import copy
  II1Iii1I1II1i = ''
  ooOOO000O = 0
  for o0Oi1IIi in OO0OOO00 :
   try :
    ooOOO000O += 1
    OOoo = copy . deepcopy ( IiIIiIIIiIii )
    if 40 - 40: oOooOoO0Oo0O
    i1IiI = oo0OoOO0o0o
    I11iiiii1II = 0
    for I11iiiii1II in range ( len ( o0Oi1IIi ) ) :
     if 73 - 73: OoooooooOO * O0 * o00O0oo
     if len ( OOoo ) > 0 :
      for iii11Ii , i1Iiii111 in OOoo . iteritems ( ) :
       if i1Iiii111 is not None :
        for IIii1i1 , OOooooO0 in i1Iiii111 . iteritems ( ) :
         if OOooooO0 is not None :
          if 23 - 23: IiII / o0 + i1 . O0
          if 76 - 76: o0 . I1Ii111 - i11i * i1iIi11iIIi1I
          if 78 - 78: iIii1I11I1II1 / O0 * OOooOOo / IiII / o0
          if 15 - 15: o00O0oo / OOooOOo
          if type ( OOooooO0 ) is dict :
           for O0Oo00o0o , oooooO0oO0o in OOooooO0 . iteritems ( ) :
            if oooooO0oO0o is not None :
             OO0ooOoOO0OOo = None
             if isinstance ( o0Oi1IIi , tuple ) :
              try :
               OO0ooOoOO0OOo = o0Oi1IIi [ I11iiiii1II ] . decode ( 'utf-8' )
              except :
               OO0ooOoOO0OOo = o0Oi1IIi [ I11iiiii1II ]
             else :
              try :
               OO0ooOoOO0OOo = o0Oi1IIi . decode ( 'utf-8' )
              except :
               OO0ooOoOO0OOo = o0Oi1IIi
               if 63 - 63: iII111i - i11i . Ii1I / o0
             if '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + '][DE]' in oooooO0oO0o :
              oooooO0oO0o = oooooO0oO0o . replace ( '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + '][DE]' , unescape ( OO0ooOoOO0OOo ) )
             OOooooO0 [ O0Oo00o0o ] = oooooO0oO0o . replace ( '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + ']' , OO0ooOoOO0OOo )
             if 17 - 17: o00O0oo
             if 13 - 13: I11i11Ii - Ii1I / OOooOOo - I11i11Ii - IiII / i11iIiiIii
          else :
           OO0ooOoOO0OOo = None
           if isinstance ( o0Oi1IIi , tuple ) :
            try :
             OO0ooOoOO0OOo = o0Oi1IIi [ I11iiiii1II ] . decode ( 'utf-8' )
            except :
             OO0ooOoOO0OOo = o0Oi1IIi [ I11iiiii1II ]
           else :
            try :
             OO0ooOoOO0OOo = o0Oi1IIi . decode ( 'utf-8' )
            except :
             OO0ooOoOO0OOo = o0Oi1IIi
           if '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + '][DE]' in OOooooO0 :
            if 29 - 29: I1Ii111 - Ii1I . O0 . O0
            OOooooO0 = OOooooO0 . replace ( '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + '][DE]' , unescape ( OO0ooOoOO0OOo ) )
            if 16 - 16: i1IIi * o00O0oo % i1iIi11iIIi1I + iII111i
           i1Iiii111 [ IIii1i1 ] = OOooooO0 . replace ( '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + ']' , OO0ooOoOO0OOo )
           if 50 - 50: OOooOOo - OoooooooOO + IiII % i1iIi11iIIi1I
           if 12 - 12: i1IIi / ii1IiI1i - IiII . i11iIiiIii / i1IIi / OoooooooOO
     OO0ooOoOO0OOo = None
     if isinstance ( o0Oi1IIi , tuple ) :
      try :
       OO0ooOoOO0OOo = o0Oi1IIi [ I11iiiii1II ] . decode ( 'utf-8' )
      except :
       OO0ooOoOO0OOo = o0Oi1IIi [ I11iiiii1II ]
     else :
      try :
       OO0ooOoOO0OOo = o0Oi1IIi . decode ( 'utf-8' )
      except :
       OO0ooOoOO0OOo = o0Oi1IIi
     if '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + '][DE]' in i1IiI :
      i1IiI = i1IiI . replace ( '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + '][DE]' , OO0ooOoOO0OOo )
     i1IiI = i1IiI . replace ( '[' + OoIII + '.param' + str ( I11iiiii1II + 1 ) + ']' , escape ( OO0ooOoOO0OOo ) )
     if 88 - 88: iII111i / i11iIiiIii % o0 % I11i
    i1IiI = i1IiI . replace ( '[' + OoIII + '.param' + str ( 0 ) + ']' , str ( ooOOO000O ) )
    if 70 - 70: ii1IiI1i . ii1IiI1i / Ii1I . ii1IiI1i
    if 37 - 37: i1IIi . ooOoO0o - i11i % i1 - i1IIi . OOooOOo
    if 34 - 34: iIii1I11I1II1 / i11i
    if 3 - 3: i1 - OoooooooOO + IiII . Ii1I
    o00000Oo = ''
    if 63 - 63: i11i * oOooOoO0Oo0O - OoooooooOO / oOooOoO0Oo0O
    if len ( OOoo ) > 0 :
     o00000Oo = iIi11I1II ( OOoo , 'lsproroot' )
     o00000Oo = o00000Oo . split ( '<lsproroot>' ) [ 1 ] . split ( '</lsproroot' ) [ 0 ]
     if 50 - 50: o0 % iII111i + o0 * iII111i - I11i
     if 94 - 94: iIii1I11I1II1
    try :
     II1Iii1I1II1i += '\n<item>%s\n%s</item>' % ( i1IiI , o00000Oo )
    except : II1Iii1I1II1i += '\n<item>%s\n%s</item>' % ( i1IiI . encode ( "utf-8" ) , o00000Oo )
   except : traceback . print_exc ( file = sys . stdout )
   if 1 - 1: O0
   if 2 - 2: i1iIi11iIIi1I . Ii1I
   if 97 - 97: I11i11Ii
   if 65 - 65: I11i11Ii % I11i / i11iIiiIii / iIii1I11I1II1 . ooOoO0o + o00O0oo
   if 92 - 92: OOooOOo
  oo0oO0oOOoo ( repr ( II1Iii1I1II1i ) )
  oo0o0000 ( '' , '' , II1Iii1I1II1i )
  xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 else :
  oOO0O00Oo0O0o , iII1ii1I1i = o0O0oo0o ( IiIIiIIIiIii , oOO0O00Oo0O0o )
  if 96 - 96: ooOoO0o * iIii1I11I1II1 / o0 % I11i * i11i
  if oOO0O00Oo0O0o :
   if '$PLAYERPROXY$=' in oOO0O00Oo0O0o :
    oOO0O00Oo0O0o , Iiii1i11ii1Ii = oOO0O00Oo0O0o . split ( '$PLAYERPROXY$=' )
    print 'proxy' , Iiii1i11ii1Ii
    if 3 - 3: I11i . I11i11Ii / i11iIiiIii + i1iIi11iIIi1I
    i1O00oo00o000o = None
    O0000ooO = None
    if len ( Iiii1i11ii1Ii ) > 0 and '@' in Iiii1i11ii1Ii :
     Iiii1i11ii1Ii = Iiii1i11ii1Ii . split ( ':' )
     i1O00oo00o000o = Iiii1i11ii1Ii [ 0 ]
     O0000ooO = Iiii1i11ii1Ii [ 1 ] . split ( '@' ) [ 0 ]
     O00OoO = Iiii1i11ii1Ii [ 1 ] . split ( '@' ) [ 1 ]
     I11i11 = Iiii1i11ii1Ii [ 2 ]
    else :
     O00OoO , I11i11 = Iiii1i11ii1Ii . split ( ':' )
     if 68 - 68: O0 * iIii1I11I1II1 / ooOoO0o
    O0OOo0o ( oOO0O00Oo0O0o , oO0o00oOOooO0 , iI1IiiiIi , O00OoO , I11i11 , i1O00oo00o000o , O0000ooO )
   else :
    oOOOO ( oOO0O00Oo0O0o , oO0o00oOOooO0 , iI1IiiiIi , iII1ii1I1i )
  else :
   xbmc . executebuiltin ( "XBMC.Notification(Failed to extract regex. - " + "this" + ",4000," + IIooooo + ")" )
   if 65 - 65: I11i - oOooOoO0Oo0O * ooOoO0o
elif I1i1iiIi == 18 :
 oo0oO0oOOoo ( "youtubedl" )
 try :
  import youtubedl
 except Exception :
  if 99 - 99: oOooOoO0Oo0O
  xbmc . executebuiltin ( "XBMC.Notification(Please [COLOR yellow]install the Youtube Addon[/COLOR] module ,10000," ")" )
 o0OoO000O = youtubedl . single_YD ( oOO0O00Oo0O0o )
 oOOOO ( o0OoO000O , oO0o00oOOooO0 , iI1IiiiIi )
elif I1i1iiIi == 19 :
 oo0oO0oOOoo ( "Genesiscommonresolvers" )
 oOOOO ( o0ooOo0OOOO0o ( oOO0O00Oo0O0o ) , oO0o00oOOooO0 , iI1IiiiIi , True )
 if 64 - 64: ii1IiI1i * iII111i * I11i11Ii % I1Ii111 % o00O0oo
elif I1i1iiIi == 21 :
 oo0oO0oOOoo ( "download current file using youtube-dl service" )
 Iiiii ( '' , oO0o00oOOooO0 , 'video' )
elif I1i1iiIi == 23 :
 oo0oO0oOOoo ( "get info then download" )
 Iiiii ( oOO0O00Oo0O0o , oO0o00oOOooO0 , 'video' )
elif I1i1iiIi == 24 :
 oo0oO0oOOoo ( "Audio only youtube download" )
 Iiiii ( oOO0O00Oo0O0o , oO0o00oOOooO0 , 'audio' )
elif I1i1iiIi == 25 :
 oo0oO0oOOoo ( "YouTube/DMotion" )
 oOo00Oo0o00oo ( oOO0O00Oo0O0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif I1i1iiIi == 26 :
 oo0oO0oOOoo ( "YouTube/DMotion From Search History" )
 oO0o00oOOooO0 = oO0o00oOOooO0 . split ( ':' )
 oOo00Oo0o00oo ( oOO0O00Oo0O0o , search_term = oO0o00oOOooO0 [ 1 ] )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
elif I1i1iiIi == 27 :
 oo0oO0oOOoo ( "Using IMDB id to play in Pulsar" )
 OoO0000O = oOo00Oo0o00oo ( oOO0O00Oo0O0o )
 xbmc . Player ( ) . play ( OoO0000O )
elif I1i1iiIi == 30 :
 OO0O0ooOOO00 ( oO0o00oOOooO0 , oOO0O00Oo0O0o , iI1IiiiIi , Oo000ooOOO )
 if 33 - 33: ooOoO0o + IiII - I11i11Ii / iII111i + OOooOOo . o0
elif I1i1iiIi == 40 :
 II1Iii ( )
 I11Ii11iI1 ( )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 84 - 84: i11iIiiIii / i1 % iIii1I11I1II1 . o00O0oo . i1iIi11iIIi1I / IiII
elif I1i1iiIi == 41 :
 oo0oO0oOOoo ( "puxarconf" )
 xbmcaddon . Addon ( ) . openSettings ( )
 xbmcgui . Dialog ( ) . ok ( '[B][COLOR red]AVISO IMPORTANTE![/COLOR][/B]' , '[B]POR FAVOR SAIR DO ADD-ON E ENTRE NOVAMENTE PARA ATUALIZAR AS CONFIGURAÇÕES[/B]' )
 xbmc . executebuiltin ( "XBMC.Container.Refresh" )
 if 55 - 55: IiII
elif I1i1iiIi == 42 :
 oo0oO0oOOoo ( "infoTORRENT" )
 if 3 - 3: iIii1I11I1II1
 if 19 - 19: i11i . i1iIi11iIIi1I * i1iIi11iIIi1I + oOooOoO0Oo0O % I11i11Ii
 xbmcgui . Dialog ( ) . ok ( I1i1I , I1Ii1iI1 ( O0oo0OO0oOOOo ) )
 if 21 - 21: o0 - i11iIiiIii - o0
 if 4 - 4: Ii1I . I1Ii111
elif I1i1iiIi == 43 :
 I11Iiii1I ( True )
 if 39 - 39: I11i . I11i11Ii - o0 * i11iIiiIii
if I1i1iiIi == 44 :
 O0OO0O ( True )
 if 4 - 4: o0 * O0 - Ii1I
elif I1i1iiIi == 53 :
 oo0oO0oOOoo ( "Requesting JSON-RPC Items" )
 oOO0O00Oo0O0o = base64 . b16decode ( base64 . b32decode ( codecs . decode ( oOO0O00Oo0O0o , 'rot_13' ) ) )
 if IiIIiIIIiIii :
  ii1 = o0O0oo0o ( IiIIiIIIiIii , oOO0O00Oo0O0o )
  oOO0O00Oo0O0o = ''
  if 72 - 72: Ii1I + o00O0oo / oOooOoO0Oo0O . I1Ii111 % i1iIi11iIIi1I / i11iIiiIii
 iI11ii ( oOO0O00Oo0O0o )
 xbmcplugin . endOfDirectory ( int ( sys . argv [ 1 ] ) )
 if 13 - 13: ooOoO0o % i1 + I11i + ooOoO0o + i11iIiiIii - ii1IiI1i
elif I1i1iiIi == 54 :
 OoOooOoO ( True )
 if 70 - 70: i11i * i11i . oOooOoO0Oo0O
 if 11 - 11: IiII
#checkintegrity